var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: !0 });
const MODULE_ID = "turn-prep", FLAG_SCOPE = "turn-prep", FLAG_KEY_DATA = "turnPrepData", TAB_ID_MAIN = "turn-prep-main", TAB_ID_SIDEBAR_TURNS = "turn-prep-sidebar-turns", SETTINGS = {
  // History limit setting
  HISTORY_LIMIT: {
    key: "historyLimit",
    default: 10,
    scope: "world",
    type: Number,
    range: { min: 5, max: 50, step: 1 }
  },
  // DM visibility setting
  ALLOW_DM_VIEW: {
    key: "allowDmViewPlayerTurnPrep",
    default: !0,
    scope: "world",
    type: Boolean
  },
  // Enable Turn Prep tab
  ENABLE_TAB: {
    key: "enableTurnPrepTab",
    default: !0,
    scope: "world",
    type: Boolean
  }
}, LOG_PREFIX = `[${MODULE_ID}]`, AUTO_SAVE_DEBOUNCE_MS = 500, MIN_FOUNDRY_VERSION = "13.0.0", MIN_DND5E_VERSION = "5.0.0";
let debugMode = globalThis.TURN_PREP_DEBUG === !0;
function setDebugMode(enabled) {
  debugMode = enabled, console.log(`${LOG_PREFIX} Debug mode enabled`);
}
__name(setDebugMode, "setDebugMode");
function debug(message, ...args) {
  debugMode && console.debug(`${LOG_PREFIX} [DEBUG]`, message, ...args);
}
__name(debug, "debug");
function info(message, ...args) {
  console.info(`${LOG_PREFIX}`, message, ...args);
}
__name(info, "info");
function warn(message, ...args) {
  console.warn(`${LOG_PREFIX} [WARN]`, message, ...args);
}
__name(warn, "warn");
function error(message, error2, ...args) {
  console.error(`${LOG_PREFIX} [ERROR]`, message), error2 instanceof Error ? (console.error("Stack:", error2.stack), console.error("Details:", error2)) : error2 ? console.error("Details:", error2, ...args) : args.length > 0 && console.error("Details:", ...args);
}
__name(error, "error");
function notify(message, type = "info", duration = 5e3) {
  typeof ui < "u" && ui.notifications ? ui.notifications[type === "warning" ? "warn" : type](message, { permanent: duration === 0 }) : console.log(`${LOG_PREFIX} [NOTIFY:${type.toUpperCase()}]`, message);
}
__name(notify, "notify");
function notifyWarning(message) {
  notify(message, "warning", 5e3);
}
__name(notifyWarning, "notifyWarning");
function logSection(title) {
  console.log(`
${LOG_PREFIX} ========== ${title} ==========
`);
}
__name(logSection, "logSection");
class FoundryAdapter {
  static {
    __name(this, "FoundryAdapter");
  }
  /**
   * Check if Foundry is ready
   * @returns True if Foundry game is loaded and ready
   */
  static isReady() {
    return typeof game < "u" && game.ready === !0;
  }
  /**
   * Check if user is a GM/Dungeon Master
   * @returns True if current user is a GM
   */
  static isGM() {
    return this.isReady() && game.user?.isGM === !0;
  }
  /**
   * Get the current user
   * @returns The current user object
   */
  static getCurrentUser() {
    return this.isReady() ? game.user ?? null : null;
  }
  /**
   * Check version compatibility
   * @returns Object with compatibility status
   */
  static checkVersionCompatibility() {
    const foundryVersion = game.version || game.data?.version || "0.0.0", systemId = game.system?.id, systemVersion = game.system?.version || "0.0.0", foundryOk = this.compareVersions(foundryVersion, MIN_FOUNDRY_VERSION) >= 0, systemOk = systemId === "dnd5e" && this.compareVersions(systemVersion, MIN_DND5E_VERSION) >= 0;
    let message = "Compatibility check:";
    return foundryOk ? message += ` ✓ Foundry ${foundryVersion}` : message += ` ✗ Foundry ${foundryVersion} (requires ${MIN_FOUNDRY_VERSION}+)`, systemOk ? message += `, ✓ D&D 5e ${systemVersion}` : systemId === "dnd5e" ? message += `, ✗ D&D 5e ${systemVersion} (requires ${MIN_DND5E_VERSION}+)` : message += `, ✗ System is '${systemId}' (requires 'dnd5e')`, { foundryOk, systemOk, message };
  }
  /**
   * Compare two version strings
   * @param version1 - First version (e.g., "13.0.0")
   * @param version2 - Second version
   * @returns -1 if v1 < v2, 0 if equal, 1 if v1 > v2
   */
  static compareVersions(version1, version2) {
    const v1 = version1.split(".").map(Number), v2 = version2.split(".").map(Number);
    for (let i = 0; i < Math.max(v1.length, v2.length); i++) {
      const num1 = v1[i] || 0, num2 = v2[i] || 0;
      if (num1 < num2) return -1;
      if (num1 > num2) return 1;
    }
    return 0;
  }
  // ========================================================================
  // Localization
  // ========================================================================
  /**
   * Localize a string using Foundry's i18n system
   * @param key - The localization key (e.g., "TurnPrep.TabName")
   * @param data - Optional data for substitution {key: value}
   * @returns The localized string
   */
  static localize(key, data) {
    return this.isReady() ? game.i18n.localize(key) : key;
  }
  /**
   * Localize with data substitution
   * @param key - The localization key
   * @param data - Data to substitute in the string
   * @returns The localized string with data substituted
   */
  static localizeFormat(key, data) {
    return this.isReady() ? game.i18n.format(key, data) : key;
  }
  /**
   * Get all localizations for a prefix
   * Useful for getting multiple related strings at once
   * @param prefix - Prefix to search (e.g., "TurnPrep")
   * @returns Object with all localized strings for that prefix
   */
  static localizeAll(prefix) {
    return this.isReady() ? game.i18n.translations[prefix] || {} : {};
  }
  // ========================================================================
  // Text / HTML Helpers
  // ========================================================================
  /**
   * Enrich HTML content using Foundry's TextEditor so shortcodes render like tidy5e.
   * Falls back to the original string if enrichment fails.
   */
  static async enrichHtml(content, options = {}) {
    if (typeof content != "string" || !content.trim())
      return content ?? null;
    try {
      const TextEditorClass = foundry?.applications?.ux?.TextEditor?.implementation ?? globalThis?.TextEditor;
      if (typeof TextEditorClass?.enrichHTML != "function")
        return content;
      const enrichOptions = {
        async: !0,
        secrets: this.isGM(),
        rollData: options.rollData ?? {},
        ...options
      };
      return await TextEditorClass.enrichHTML(content, enrichOptions);
    } catch (err) {
      return warn("[FoundryAdapter] Failed to enrich HTML content", err), content;
    }
  }
  // ========================================================================
  // Actor Operations
  // ========================================================================
  /**
   * Get an actor by ID
   * @param actorId - The actor ID
   * @returns The actor object, or null if not found
   */
  static getActor(actorId) {
    return this.isReady() ? game.actors?.get(actorId) ?? null : null;
  }
  /**
   * Get all actors
   * @returns Array of all actors in the world
   */
  static getAllActors() {
    return this.isReady() ? Array.from(game.actors?.values() ?? []) : [];
  }
  /**
   * Get all owned actors (player characters)
   * @returns Array of owned actors
   */
  static getOwnedActors() {
    return this.isReady() ? this.getAllActors().filter((a) => a.isOwner === !0) : [];
  }
  /**
   * Update an actor with new data
   * @param actorId - The actor ID
   * @param updates - Object with properties to update
   * @returns Promise that resolves when update is complete
   */
  static async updateActor(actorId, updates) {
    const actor = this.getActor(actorId);
    if (!actor)
      throw new Error(`Actor not found: ${actorId}`);
    try {
      await actor.update(updates);
    } catch (err) {
      throw error(`Failed to update actor ${actorId}`, err), err;
    }
  }
  // ========================================================================
  // Actor Flags
  // ========================================================================
  /**
   * Get flag value from an actor
   * @param actor - The actor object
   * @param key - The flag key
   * @returns The flag value, or null if not set
   */
  static getFlag(actor, key) {
    return actor ? actor.getFlag(FLAG_SCOPE, key) ?? null : null;
  }
  /**
   * Get Turn Prep data from an actor
   * @param actor - The actor object
   * @returns The Turn Prep data, or null if not found
   */
  static getTurnPrepData(actor) {
    return actor ? this.getFlag(actor, FLAG_KEY_DATA) ?? null : null;
  }
  /**
   * Set a flag value on an actor
   * @param actor - The actor object
   * @param key - The flag key
   * @param value - The value to set
   * @returns Promise that resolves when flag is set
   */
  static async setFlag(actor, key, value, options = {}) {
    if (!actor)
      throw new Error("Cannot set flag on null actor");
    try {
      await actor.setFlag(FLAG_SCOPE, key, value, options);
    } catch (err) {
      throw error(`Failed to set flag ${key} on actor`, err), err;
    }
  }
  /**
   * Set Turn Prep data on an actor
   * @param actor - The actor object
   * @param data - The Turn Prep data
   * @returns Promise that resolves when data is saved
   */
  static async setTurnPrepData(actor, data, options = {}) {
    return this.setFlag(actor, FLAG_KEY_DATA, data, options);
  }
  /**
   * Delete a flag from an actor
   * @param actor - The actor object
   * @param key - The flag key
   * @returns Promise that resolves when flag is deleted
   */
  static async deleteFlag(actor, key) {
    if (!actor)
      throw new Error("Cannot delete flag on null actor");
    try {
      await actor.unsetFlag(FLAG_SCOPE, key);
    } catch (err) {
      throw error(`Failed to delete flag ${key} from actor`, err), err;
    }
  }
  // ========================================================================
  // Item Operations
  // ========================================================================
  /**
   * Get an item from an actor
   * @param actorId - The actor ID
   * @param itemId - The item ID
   * @returns The item object, or null if not found
   */
  static getItem(actorId, itemId) {
    const actor = this.getActor(actorId);
    return actor ? actor.items?.get(itemId) ?? null : null;
  }
  /**
   * Get an item directly from an actor instance.
   */
  static getItemFromActor(actor, itemId) {
    return !actor || !itemId ? null : actor.items?.get(itemId) ?? null;
  }
  /**
   * Get all items of specific types from an actor
   * @param actorId - The actor ID
   * @param types - Array of item types to include (e.g., ['spell', 'feat'])
   * @returns Array of matching items
   */
  static getItemsByType(actorId, types) {
    const actor = this.getActor(actorId);
    return actor ? Array.from(actor.items?.values() ?? []).filter(
      (item) => types.includes(item.type)
    ) : [];
  }
  /**
   * Get all items with a specific activation type
   * @param actorId - The actor ID
   * @param activationType - The activation type (e.g., 'action', 'bonus', 'reaction')
   * @returns Array of matching items
   */
  static getItemsByActivationType(actorId, activationType) {
    const actor = this.getActor(actorId);
    return actor ? Array.from(actor.items?.values() ?? []).filter((item) => this.getItemActivationType(item) === activationType) : [];
  }
  /**
   * Get all reaction features from an actor
   * @param actorId - The actor ID
   * @returns Array of items with reaction activation
   */
  static getReactionFeatures(actorId) {
    return this.getItemsByActivationType(actorId, "reaction");
  }
  /**
   * Get the activation type of an item
   * @param item - The item object
   * @returns The activation type string, or empty string if none
   */
  static getItemActivationType(item) {
    const system = item.system;
    if (!system) return "";
    const activation = system.activation;
    return activation && activation.type || "";
  }
  /**
   * Get the name of an item
   * @param item - The item object
   * @returns The item name
   */
  static getItemName(item) {
    return item.name || "Unknown Item";
  }
  /**
   * Get the type of an item
   * @param item - The item object
   * @returns The item type
   */
  static getItemType(item) {
    return item.type || "unknown";
  }
  /**
   * Check if an item is prepared (for spells)
   * @param item - The item object
   * @returns True if prepared, false otherwise
   */
  static isItemPrepared(item) {
    const system = item.system;
    return system ? system.preparation?.prepared !== !1 : !0;
  }
  /**
   * Resolve an activity document from an item by ID.
   */
  static getActivityFromItem(item, activityId) {
    if (!item || !activityId)
      return null;
    const activities = item.activities ?? null;
    if (!activities)
      return null;
    if (typeof activities.get == "function") {
      const doc = activities.get(activityId);
      if (doc)
        return doc;
    }
    const candidates = Array.isArray(activities) ? activities : Array.isArray(activities.contents) ? activities.contents : null;
    return candidates ? candidates.find?.((entry) => entry?.id === activityId || entry?._id === activityId) ?? null : null;
  }
  /**
   * Trigger the Foundry item usage workflow.
   */
  static async useItemDocument(item, options = {}) {
    if (!item || typeof item.use != "function")
      return warn("[FoundryAdapter] Cannot use item - invalid document provided"), null;
    const config = {
      legacy: !1,
      ...options
    };
    return item.use(config);
  }
  /**
   * Trigger the Foundry activity usage workflow.
   */
  static async useActivityDocument(activity, options = {}) {
    return !activity || typeof activity.use != "function" ? (warn("[FoundryAdapter] Cannot use activity - invalid document provided"), null) : activity.use({ ...options });
  }
  /**
   * Open an item's sheet with optional editable override.
   */
  static openItemSheet(item, options = {}) {
    if (!item) {
      warn("[FoundryAdapter] Cannot open sheet - item is missing");
      return;
    }
    const sheet = item.sheet ?? (typeof item.getSheet == "function" ? item.getSheet() : null);
    if (!sheet) {
      warn(`[FoundryAdapter] No sheet available for item ${item.name}`);
      return;
    }
    const renderOptions = typeof options.editable == "boolean" ? { editable: options.editable } : void 0;
    try {
      sheet.render(!0, renderOptions);
    } catch (err) {
      warn("[FoundryAdapter] Failed to render item sheet", err);
    }
  }
  /**
   * Display an item card in chat, falling back through legacy APIs if needed.
   */
  static async displayItemInChat(item, options = {}) {
    if (!item) {
      warn("[FoundryAdapter] Cannot display in chat - item is missing");
      return;
    }
    const rollMode = options.rollMode ?? game.settings?.get("core", "rollMode") ?? "publicroll";
    try {
      if (typeof item.displayCard == "function") {
        await item.displayCard({ rollMode });
        return;
      }
      if (typeof item.toMessage == "function") {
        await item.toMessage(void 0, { rollMode });
        return;
      }
      if (typeof item.toChat == "function") {
        await item.toChat({ rollMode });
        return;
      }
      warn("[FoundryAdapter] Item document does not support chat display");
    } catch (err) {
      warn("[FoundryAdapter] Failed to display item in chat", err);
    }
  }
  /**
   * Check if user can use an item
   * @param item - The item object
   * @returns True if user has permission to use it
   */
  static canUseItem(item) {
    const actor = item.actor;
    return actor ? actor.isOwner === !0 : !0;
  }
  // ========================================================================
  // Permission Checking
  // ========================================================================
  /**
   * Check if user can view an actor
   * @param actor - The actor to check
   * @returns True if user can view
   */
  static canViewActor(actor) {
    return actor.can?.(game.user, "view") ?? !0;
  }
  /**
   * Check if user can update an actor
   * @param actor - The actor to check
   * @returns True if user can update
   */
  static canUpdateActor(actor) {
    return actor.can?.(game.user, "update") ?? actor.isOwner === !0;
  }
  /**
   * Check if user owns an actor
   * @param actor - The actor to check
   * @returns True if user owns the actor
   */
  static isActorOwner(actor) {
    return actor.isOwner === !0;
  }
  // ========================================================================
  // Dialog & UI
  // ========================================================================
  /**
   * Show a confirmation dialog
   * @param title - Dialog title
   * @param message - Dialog message
   * @returns Promise that resolves to true if confirmed, false if cancelled
   */
  static async confirm(title, message) {
    return new Promise((resolve) => {
      new Dialog({
        title,
        content: message,
        buttons: {
          confirm: {
            icon: '<i class="fas fa-check"></i>',
            label: "Confirm",
            callback: /* @__PURE__ */ __name(() => resolve(!0), "callback")
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: "Cancel",
            callback: /* @__PURE__ */ __name(() => resolve(!1), "callback")
          }
        },
        default: "cancel"
      }).render(!0);
    });
  }
  /**
   * Show a notification toast in Foundry UI
   * @param message - The message to display
   * @param type - Type of notification (info, warning, error)
   * @param duration - Duration in milliseconds (0 = persistent)
   */
  static notify(message, type = "info", duration = 5e3) {
    !this.isReady() || !ui.notifications || (type === "warning" ? ui.notifications.warn(message, { permanent: duration === 0 }) : type === "error" ? ui.notifications.error(message, { permanent: duration === 0 }) : ui.notifications.info(message, { permanent: duration === 0 }));
  }
  // ========================================================================
  // Hooks
  // ========================================================================
  /**
   * Register a hook callback
   * @param hookName - The hook name
   * @param callback - The callback function
   * @returns The hook ID
   */
  static onHook(hookName, callback) {
    return Hooks.on(hookName, callback);
  }
  /**
   * Register a one-time hook callback
   * @param hookName - The hook name
   * @param callback - The callback function
   * @returns The hook ID
   */
  static onceHook(hookName, callback) {
    return Hooks.once(hookName, callback);
  }
  /**
   * Call a hook
   * @param hookName - The hook name
   * @param args - Arguments to pass to hook handlers
   * @returns Number of handlers called
   */
  static callHook(hookName, ...args) {
    return Hooks.callAll(hookName, ...args);
  }
  /**
   * Unregister a hook
   * @param hookName - The hook name
   * @param hookId - The hook ID returned from onHook
   */
  static offHook(hookName, hookId) {
    Hooks.off(hookName, hookId);
  }
  // ========================================================================
  // Settings
  // ========================================================================
  /**
   * Register a module setting
   * @param key - The setting key
   * @param options - Setting options
   */
  static registerSetting(key, options) {
    game.settings.register(MODULE_ID, key, options);
  }
  /**
   * Get a setting value
   * @param key - The setting key
   * @returns The setting value
   */
  static getSetting(key) {
    return this.isReady() ? game.settings.get(MODULE_ID, key) : null;
  }
  /**
   * Set a setting value
   * @param key - The setting key
   * @param value - The new value
   * @returns Promise that resolves when setting is saved
   */
  static async setSetting(key, value) {
    if (!this.isReady())
      throw new Error("Cannot set setting before Foundry is ready");
    try {
      await game.settings.set(MODULE_ID, key, value);
    } catch (err) {
      throw error(`Failed to set setting ${key}`, err), err;
    }
  }
  // ========================================================================
  // Module Management
  // ========================================================================
  /**
   * Check if a module is active
   * @param moduleId - The module ID
   * @returns True if module is active
   */
  static isModuleActive(moduleId) {
    return this.isReady() ? game.modules?.has(moduleId) === !0 : !1;
  }
  /**
   * Get a module
   * @param moduleId - The module ID
   * @returns The module object, or null if not found
   */
  static getModule(moduleId) {
    return this.isReady() ? game.modules?.get(moduleId) ?? null : null;
  }
  /**
   * Get the API of another module
   * @param moduleId - The module ID
   * @param apiPath - Path to the API (e.g., 'api' for module.api)
   * @returns The API object, or null if not found
   */
  static getModuleApi(moduleId, apiPath = "api") {
    const module = this.getModule(moduleId);
    if (!module) return null;
    const parts = apiPath.split(".");
    let result = module;
    for (const part of parts)
      if (result = result[part], !result) return null;
    return result;
  }
  // ========================================================================
  // Utilities
  // ========================================================================
  /**
   * Log a message with the module ID prefix
   * @param message - The message to log
   * @param args - Additional arguments
   */
  static log(message, ...args) {
    info(message, ...args);
  }
  /**
   * Open a link in a new tab
   * @param url - The URL to open
   */
  static openUrl(url) {
    window.open(url, "_blank");
  }
}
const byteToHex = [];
for (let i = 0; i < 256; ++i)
  byteToHex.push((i + 256).toString(16).slice(1));
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}
__name(unsafeStringify, "unsafeStringify");
let getRandomValues;
const rnds8 = new Uint8Array(16);
function rng() {
  if (!getRandomValues) {
    if (typeof crypto > "u" || !crypto.getRandomValues)
      throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
    getRandomValues = crypto.getRandomValues.bind(crypto);
  }
  return getRandomValues(rnds8);
}
__name(rng, "rng");
const randomUUID = typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto), native = { randomUUID };
function _v4(options, buf, offset) {
  options = options || {};
  const rnds = options.random ?? options.rng?.() ?? rng();
  if (rnds.length < 16)
    throw new Error("Random bytes length must be >= 16");
  return rnds[6] = rnds[6] & 15 | 64, rnds[8] = rnds[8] & 63 | 128, unsafeStringify(rnds);
}
__name(_v4, "_v4");
function v4(options, buf, offset) {
  return native.randomUUID && !options ? native.randomUUID() : _v4(options);
}
__name(v4, "v4");
function generateId() {
  return v4();
}
__name(generateId, "generateId");
function moveArrayItem$1(arr, fromIndex, toIndex) {
  if (fromIndex === toIndex) return arr;
  const newArr = [...arr], [item] = newArr.splice(fromIndex, 1);
  return newArr.splice(toIndex, 0, item), newArr;
}
__name(moveArrayItem$1, "moveArrayItem$1");
function createDMQuestion(text, tags = []) {
  return {
    id: generateId(),
    text,
    tags,
    createdTime: Date.now()
  };
}
__name(createDMQuestion, "createDMQuestion");
function createTurnPlan(name, trigger) {
  return {
    id: generateId(),
    name,
    trigger,
    actions: [],
    bonusActions: [],
    reactions: [],
    movement: "",
    roleplay: "",
    additionalFeatures: [],
    categories: []
  };
}
__name(createTurnPlan, "createTurnPlan");
function createReaction(name = "", trigger = "", initialFeatures = []) {
  return {
    id: generateId(),
    name: typeof name == "string" ? name : "",
    trigger: typeof trigger == "string" ? trigger : "",
    reactionFeatures: Array.isArray(initialFeatures) ? initialFeatures.map((feature) => ({
      itemId: feature.itemId,
      itemName: feature.itemName,
      itemType: feature.itemType,
      actionType: feature.actionType
    })) : [],
    additionalFeatures: [],
    notes: "",
    createdTime: Date.now(),
    isFavorite: !1
  };
}
__name(createReaction, "createReaction");
function createTurnSnapshot(plan) {
  return {
    id: generateId(),
    createdTime: Date.now(),
    planName: plan.name,
    actions: (plan.actions ?? []).map(snapshotFeature),
    bonusActions: (plan.bonusActions ?? []).map(snapshotFeature),
    reactions: (plan.reactions ?? []).map(snapshotFeature),
    movement: plan.movement,
    trigger: plan.trigger,
    additionalFeatures: (plan.additionalFeatures ?? []).map(snapshotFeature),
    categories: [...plan.categories ?? []],
    roleplay: plan.roleplay ?? ""
  };
}
__name(createTurnSnapshot, "createTurnSnapshot");
function createReactionFavoriteSnapshot(reaction) {
  const trigger = reaction.trigger || reaction.name || "";
  return {
    id: generateId(),
    createdTime: Date.now(),
    trigger,
    reactionFeatures: (reaction.reactionFeatures ?? []).map(snapshotFeature),
    additionalFeatures: (reaction.additionalFeatures ?? []).map(snapshotFeature),
    notes: reaction.notes ?? ""
  };
}
__name(createReactionFavoriteSnapshot, "createReactionFavoriteSnapshot");
function truncateWithEllipsis(value, maxLength = 18) {
  if (typeof value != "string") return "";
  const trimmed = value.trim();
  return trimmed.length <= maxLength ? trimmed : `${trimmed.slice(0, maxLength).trimEnd()}…`;
}
__name(truncateWithEllipsis, "truncateWithEllipsis");
function snapshotFeature(feature) {
  return {
    itemId: feature.itemId,
    itemName: truncateWithEllipsis(feature.itemName),
    itemType: feature.itemType,
    actionType: feature.actionType,
    isMissing: !1
  };
}
__name(snapshotFeature, "snapshotFeature");
function snapshotToPlan(snapshot) {
  const mapFeature = /* @__PURE__ */ __name((f) => ({
    itemId: f.itemId,
    itemName: f.itemName,
    itemType: f.itemType,
    actionType: f.actionType
  }), "mapFeature");
  return {
    id: snapshot.id || generateId(),
    name: snapshot.planName || "",
    trigger: snapshot.trigger || "",
    actions: (snapshot.actions ?? []).map(mapFeature),
    bonusActions: (snapshot.bonusActions ?? []).map(mapFeature),
    reactions: (snapshot.reactions ?? []).map(mapFeature),
    movement: snapshot.movement ?? "",
    roleplay: snapshot.roleplay ?? "",
    additionalFeatures: (snapshot.additionalFeatures ?? []).map(mapFeature),
    categories: snapshot.categories ?? []
  };
}
__name(snapshotToPlan, "snapshotToPlan");
function snapshotToReaction(snapshot) {
  const mapFeature = /* @__PURE__ */ __name((f) => ({
    itemId: f.itemId,
    itemName: f.itemName,
    itemType: f.itemType,
    actionType: f.actionType
  }), "mapFeature"), reactionFeatures = snapshot.reactionFeatures ?? snapshot.reactions ?? [];
  return {
    id: snapshot.id || generateId(),
    name: snapshot.planName || snapshot.trigger || "",
    trigger: snapshot.trigger || "",
    reactionFeatures: reactionFeatures.map(mapFeature),
    additionalFeatures: (snapshot.additionalFeatures ?? []).map(mapFeature),
    notes: snapshot.notes || snapshot.roleplay || "",
    isFavorite: !0
  };
}
__name(snapshotToReaction, "snapshotToReaction");
function createEmptyTurnPrepData() {
  return {
    version: 1,
    dmQuestions: [],
    turnPlans: [],
    activePlanIndex: -1,
    reactions: [],
    history: [],
    favoritesTurn: [],
    favoritesReaction: []
  };
}
__name(createEmptyTurnPrepData, "createEmptyTurnPrepData");
function limitArray(arr, maxLength) {
  return arr.length <= maxLength ? arr : arr.slice(arr.length - maxLength);
}
__name(limitArray, "limitArray");
function limitHistory(history, limit) {
  return limitArray(history, Math.max(5, Math.min(50, limit)));
}
__name(limitHistory, "limitHistory");
function validateAndCorrectTurnPrepData(data) {
  if (!data)
    return {
      version: 1,
      dmQuestions: [],
      turnPlans: [],
      activePlanIndex: -1,
      reactions: [],
      history: [],
      favoritesTurn: [],
      favoritesReaction: []
    };
  const legacyFavorites = Array.isArray(data.favorites) ? data.favorites : [];
  return {
    version: data.version ?? 1,
    dmQuestions: Array.isArray(data.dmQuestions) ? data.dmQuestions : [],
    turnPlans: Array.isArray(data.turnPlans) ? data.turnPlans.map((plan) => normalizeTurnPlan(plan)) : [],
    activePlanIndex: typeof data.activePlanIndex == "number" ? data.activePlanIndex : -1,
    reactions: Array.isArray(data.reactions) ? data.reactions.map((reaction) => normalizeReaction(reaction)) : [],
    history: Array.isArray(data.history) ? data.history : [],
    favoritesTurn: Array.isArray(data.favoritesTurn) ? data.favoritesTurn : legacyFavorites,
    favoritesReaction: Array.isArray(data.favoritesReaction) ? data.favoritesReaction : []
  };
}
__name(validateAndCorrectTurnPrepData, "validateAndCorrectTurnPrepData");
function normalizeTurnPlan(plan) {
  if (!plan || typeof plan != "object")
    return createTurnPlan("Turn Plan", "");
  const normalized = createTurnPlan(
    typeof plan.name == "string" ? plan.name : "Turn Plan",
    typeof plan.trigger == "string" ? plan.trigger : ""
  );
  return normalized.id = typeof plan.id == "string" ? plan.id : normalized.id, normalized.movement = typeof plan.movement == "string" ? plan.movement : "", normalized.roleplay = typeof plan.roleplay == "string" ? plan.roleplay : "", normalized.categories = Array.isArray(plan.categories) ? plan.categories.filter((cat) => typeof cat == "string" && cat.trim().length > 0) : [], normalized.actions = normalizeFeatureArray(plan.actions ?? plan.action), normalized.bonusActions = normalizeFeatureArray(plan.bonusActions ?? plan.bonusAction), normalized.reactions = normalizeFeatureArray(plan.reactions), normalized.additionalFeatures = normalizeFeatureArray(plan.additionalFeatures), normalized;
}
__name(normalizeTurnPlan, "normalizeTurnPlan");
function normalizeReaction(entry) {
  const name = typeof entry?.name == "string" ? entry.name : typeof entry?.feature?.itemName == "string" ? entry.feature.itemName : "Reaction", trigger = typeof entry?.trigger == "string" ? entry.trigger : "", normalized = createReaction(name, trigger);
  return normalized.id = typeof entry?.id == "string" ? entry.id : normalized.id, normalized.reactionFeatures = normalizeFeatureArray(entry?.reactionFeatures ?? entry?.feature), normalized.additionalFeatures = normalizeFeatureArray(entry?.additionalFeatures), normalized.notes = typeof entry?.notes == "string" ? entry.notes : "", normalized.createdTime = typeof entry?.createdTime == "number" ? entry.createdTime : normalized.createdTime, normalized.isFavorite = typeof entry?.isFavorite == "boolean" ? entry.isFavorite : !1, normalized;
}
__name(normalizeReaction, "normalizeReaction");
function normalizeFeatureArray(value) {
  return value ? (Array.isArray(value) ? value : [value]).map((entry) => normalizeSelectedFeature(entry)).filter((entry) => !!entry) : [];
}
__name(normalizeFeatureArray, "normalizeFeatureArray");
function normalizeSelectedFeature(feature) {
  if (!feature || typeof feature != "object")
    return null;
  const itemId = typeof feature.itemId == "string" ? feature.itemId : null, itemName = typeof feature.itemName == "string" ? feature.itemName : null, itemType = typeof feature.itemType == "string" ? feature.itemType : null, actionType = typeof feature.actionType == "string" ? feature.actionType : "other";
  return !itemId || !itemName || !itemType ? null : {
    itemId,
    itemName,
    itemType,
    actionType
  };
}
__name(normalizeSelectedFeature, "normalizeSelectedFeature");
class TurnPrepStorage {
  static {
    __name(this, "TurnPrepStorage");
  }
  /**
   * Load Turn Prep data for an actor
   * Returns empty data if none exists or if data is corrupted
   * 
   * @param actor - The actor to load data for
   * @returns The loaded TurnPrepData, or empty data if none exists
   */
  static async load(actor) {
    try {
      if (!actor)
        return warn("TurnPrepStorage.load(): Actor is undefined"), createEmptyTurnPrepData();
      debug(`TurnPrepStorage.load(): Loading data for actor ${actor.id}`);
      const rawData = FoundryAdapter.getFlag(actor, FLAG_KEY_DATA);
      if (!rawData)
        return debug(`TurnPrepStorage.load(): No existing data for actor ${actor.id}, returning empty`), createEmptyTurnPrepData();
      const validatedData = validateAndCorrectTurnPrepData(rawData);
      return rawData !== validatedData && debug(`TurnPrepStorage.load(): Data was corrected for actor ${actor.id}`), info(`TurnPrepStorage.load(): Successfully loaded data for actor ${actor.id}`), validatedData;
    } catch (err) {
      return error(
        `TurnPrepStorage.load(): Failed to load data for actor ${actor?.id}`,
        err
      ), createEmptyTurnPrepData();
    }
  }
  /**
   * Save Turn Prep data for an actor
   * Validates data before saving, performs atomic save operation
   * 
   * @param actor - The actor to save data for
   * @param data - The TurnPrepData to save
   * @throws Error if actor is invalid or save fails
   */
  static async save(actor, data) {
    try {
      if (!actor)
        throw new Error("Cannot save Turn Prep data: actor is undefined");
      if (!this.isFlagValid(data))
        throw new Error("Cannot save Turn Prep data: data validation failed");
      debug(`TurnPrepStorage.save(): Saving data for actor ${actor.id}`), await FoundryAdapter.setFlag(actor, FLAG_KEY_DATA, data, { render: !1 }), info(`TurnPrepStorage.save(): Successfully saved data for actor ${actor.id}`);
    } catch (err) {
      throw error(`TurnPrepStorage.save(): Failed to save data for actor ${actor?.id}`, err), err;
    }
  }
  /**
   * Clear all Turn Prep data for an actor
   * Removes the flag completely
   * 
   * @param actor - The actor to clear data for
   */
  static async clear(actor) {
    try {
      if (!actor) {
        warn("TurnPrepStorage.clear(): Actor is undefined");
        return;
      }
      debug(`TurnPrepStorage.clear(): Clearing data for actor ${actor.id}`), await FoundryAdapter.deleteFlag(actor, FLAG_KEY_DATA), info(`TurnPrepStorage.clear(): Successfully cleared data for actor ${actor.id}`);
    } catch (err) {
      throw error(
        `TurnPrepStorage.clear(): Failed to clear data for actor ${actor?.id}`,
        err
      ), err;
    }
  }
  /**
   * Validate a TurnPrepData object
   * Checks that all required fields exist and are the correct type
   * 
   * @param data - The data to validate
   * @returns True if data is valid, false otherwise
   */
  static isFlagValid(data) {
    if (!data || typeof data != "object" || typeof data.version != "number" || !Array.isArray(data.dmQuestions) || !Array.isArray(data.turnPlans) || typeof data.activePlanIndex != "number" || !Array.isArray(data.reactions) || !Array.isArray(data.history))
      return !1;
    const hasTurnFav = Array.isArray(data.favoritesTurn ?? data.favorites), hasReactionFav = Array.isArray(data.favoritesReaction ?? []);
    return !(!hasTurnFav || !hasReactionFav);
  }
  /**
   * Get all DM questions for an actor
   * Retrieves from the stored data structure
   * 
   * @param actor - The actor to get questions for
   * @returns Array of DM questions
   */
  async getDMQuestions(actor) {
    try {
      return (await TurnPrepStorage.load(actor)).dmQuestions || [];
    } catch (err) {
      return warn("Failed to get DM questions", err), [];
    }
  }
  /**
   * Save DM questions for an actor
   * Persists the questions to actor flags
   * 
   * @param actor - The actor to save questions for
   * @param questions - Array of questions to save
   */
  async saveDMQuestions(actor, questions) {
    try {
      const data = await TurnPrepStorage.load(actor);
      data.dmQuestions = questions, await TurnPrepStorage.save(actor, data), debug(`Saved ${questions.length} DM questions for actor ${actor.id}`);
    } catch (err) {
      throw error("Failed to save DM questions", err), err;
    }
  }
  /**
   * Get singleton instance for method chaining
   * @returns TurnPrepStorage instance
   */
  static getInstance() {
    return new TurnPrepStorage();
  }
  /**
   * Get the flag scope and key constants
   * Useful for debugging or direct flag access
   * 
   * @returns Object with scope and key
   */
  static getFlagInfo() {
    return {
      scope: FLAG_SCOPE,
      key: FLAG_KEY_DATA
    };
  }
}
const QUERYABLE_ITEM_TYPES = [
  "weapon",
  "spell",
  "feat",
  "classFeature",
  "item"
  // Generic items
], ACTIVATION_TYPES = {
  ACTION: "action",
  BONUS_ACTION: "bonus",
  REACTION: "reaction",
  LEGENDARY: "legendary",
  SPECIAL: "special"
};
class FeatureSelector {
  static {
    __name(this, "FeatureSelector");
  }
  /**
   * Get all selectable features for an actor
   * Includes spells, weapons, feats, class features, and items
   * Filters based on activity availability and item status
   * 
   * @param actor - The actor to query
   * @returns Array of selectable features
   */
  static getAllSelectableFeatures(actor) {
    try {
      if (!actor)
        return warn("FeatureSelector.getAllSelectableFeatures(): Actor is undefined"), [];
      debug(`FeatureSelector.getAllSelectableFeatures(): Querying features for ${actor.name}`);
      const features = [];
      if (actor.items) {
        const items = Array.from(actor.items);
        for (const item of items)
          if (this.isQueryableItem(item) && item.system?.activities) {
            const activities = Array.from(item.system.activities);
            for (const activity of activities)
              if (this.canUseActivity(actor, item, activity)) {
                const feature = this.formatFeatureForDisplay(item, activity);
                feature && features.push(feature);
              }
          }
      }
      return debug(
        `FeatureSelector.getAllSelectableFeatures(): Found ${features.length} features for ${actor.name}`
      ), features;
    } catch (err) {
      return warn("FeatureSelector.getAllSelectableFeatures(): Error querying features", err), [];
    }
  }
  /**
   * Get all available features for an actor (for additional features field)
   * Includes ALL spells, weapons, feats, class features, and items
   * Does NOT filter by activation cost - includes everything
   * 
   * @param actor - The actor to query
   * @returns Array of all available features
   */
  static getAllAvailableFeatures(actor) {
    try {
      if (!actor)
        return warn("FeatureSelector.getAllAvailableFeatures(): Actor is undefined"), [];
      debug(`FeatureSelector.getAllAvailableFeatures(): Querying all features for ${actor.name}`);
      const features = [];
      if (actor.items) {
        const items = Array.from(actor.items);
        for (const item of items)
          if (this.isQueryableItem(item))
            if (item.system?.activities) {
              const activities = Array.from(item.system.activities);
              for (const activity of activities) {
                const feature = this.formatFeatureForDisplay(item, activity);
                feature && features.push(feature);
              }
            } else {
              const feature = {
                itemId: item.id,
                itemName: item.name,
                itemType: item.type,
                actionType: "other"
                // Mark as "other" since no activation defined
              };
              features.push(feature);
            }
      }
      return debug(
        `FeatureSelector.getAllAvailableFeatures(): Found ${features.length} features for ${actor.name}`
      ), features;
    } catch (err) {
      return warn("FeatureSelector.getAllAvailableFeatures(): Error querying features", err), [];
    }
  }
  /**
   * Get features by activation type (action, bonus action, reaction)
   * 
   * @param actor - The actor to query
   * @param activationType - The activation type to filter by
   * @returns Array of features with the specified activation type
   */
  static getFeaturesByActivationType(actor, activationType) {
    try {
      const filtered = this.getAllSelectableFeatures(actor).filter((feature) => feature.actionType === activationType);
      return debug(
        `FeatureSelector.getFeaturesByActivationType(): Found ${filtered.length} ${activationType} features for ${actor.name}`
      ), filtered;
    } catch (err) {
      return warn(
        "FeatureSelector.getFeaturesByActivationType(): Error filtering by activation type",
        err
      ), [];
    }
  }
  /**
   * Get features by item type (spell, weapon, feat, etc.)
   * 
   * @param actor - The actor to query
   * @param itemType - The item type to filter by
   * @returns Array of features of the specified type
   */
  static getFeaturesByItemType(actor, itemType) {
    try {
      const filtered = this.getAllSelectableFeatures(actor).filter((feature) => feature.itemType === itemType);
      return debug(
        `FeatureSelector.getFeaturesByItemType(): Found ${filtered.length} ${itemType} features for ${actor.name}`
      ), filtered;
    } catch (err) {
      return warn(
        "FeatureSelector.getFeaturesByItemType(): Error filtering by item type",
        err
      ), [];
    }
  }
  /**
   * Get features that can be used as actions
   * 
   * @param actor - The actor to query
   * @returns Array of action features
   */
  static getActionFeatures(actor) {
    return this.getFeaturesByActivationType(actor, ACTIVATION_TYPES.ACTION);
  }
  /**
   * Get features that can be used as bonus actions
   * 
   * @param actor - The actor to query
   * @returns Array of bonus action features
   */
  static getBonusActionFeatures(actor) {
    return this.getFeaturesByActivationType(actor, ACTIVATION_TYPES.BONUS_ACTION);
  }
  /**
   * Get features that can be used as reactions
   * 
   * @param actor - The actor to query
   * @returns Array of reaction features
   */
  static getReactionFeatures(actor) {
    return this.getFeaturesByActivationType(actor, ACTIVATION_TYPES.REACTION);
  }
  /**
   * Check if an item type is queryable
   * 
   * @param item - The item to check
   * @returns True if item type should be queried
   */
  static isQueryableItem(item) {
    return !(!item || !QUERYABLE_ITEM_TYPES.includes(item.type) || item.type === "weapon" && item.system?.equipped === !1 || item.type === "spell" && item.system?.prepared === !1);
  }
  /**
   * Check if an activity can be used
   * Validates that activity exists and is usable
   * 
   * @param actor - The actor who would use the activity
   * @param item - The parent item
   * @param activity - The activity to check
   * @returns True if the activity can be used
   */
  static canUseActivity(actor, item, activity) {
    if (!activity || !activity.activation?.type)
      return !1;
    const uses = activity.uses;
    return !(uses && typeof uses.max == "number" && typeof uses.value == "number" && uses.max > 0 && uses.value <= 0);
  }
  /**
   * Format an item + activity for display as a SelectedFeature
   * Extracts relevant info and handles missing data gracefully
   * 
   * @param item - The parent item
   * @param activity - The activity to format
   * @returns SelectedFeature or null if invalid
   */
  static formatFeatureForDisplay(item, activity) {
    try {
      if (!item || !item.id || !item.name || !activity || !activity.activation?.type)
        return null;
      const actionType = activity.activation.type.toLowerCase();
      return {
        itemId: item.id,
        itemName: item.name,
        itemType: item.type,
        actionType
      };
    } catch (err) {
      return warn("FeatureSelector.formatFeatureForDisplay(): Error formatting feature", err), null;
    }
  }
  /**
   * Get metadata for a feature
   * Useful for displaying tooltips or additional info
   * 
   * @param item - The item to get metadata for
   * @param activity - The activity (optional)
   * @returns Object with feature metadata
   */
  static getFeatureMetadata(item, activity) {
    if (!item)
      return {};
    const activation = activity?.activation || item.system?.activation || {}, uses = activity?.uses || item.system?.uses || {}, range = activity?.range || item.system?.range || {};
    return {
      name: item.name,
      type: item.type,
      activation: {
        type: activation.type,
        value: activation.value
      },
      uses: {
        current: uses.value,
        max: uses.max
      },
      range: {
        value: range.value,
        units: range.units
      },
      equipped: item.system?.equipped,
      prepared: item.system?.prepared
    };
  }
  /**
   * Get all activities from an item
   * Used by context menu to determine if activity selection dialog is needed
   * 
   * @param item - The item to get activities from
   * @returns Array of activities for the item
   */
  static getActivitiesForItem(item) {
    if (!item || !item.system?.activities)
      return [];
    try {
      return Array.from(item.system.activities);
    } catch (err) {
      return warn("FeatureSelector.getActivitiesForItem(): Error getting activities", err), [];
    }
  }
  /**
   * Normalize activation type to standard values
   * Handles D&D 5e system variations
   * 
   * @param activationType - The raw activation type from activity data
   * @returns Normalized activation type
   */
  static getActivationType(activationType) {
    if (!activationType)
      return ACTIVATION_TYPES.ACTION;
    const normalized = activationType.toLowerCase().trim();
    return normalized.includes("bonus") ? ACTIVATION_TYPES.BONUS_ACTION : normalized.includes("reaction") ? ACTIVATION_TYPES.REACTION : normalized.includes("legendary") ? ACTIVATION_TYPES.LEGENDARY : normalized === "special" ? ACTIVATION_TYPES.SPECIAL : normalized === "other" ? "other" : ACTIVATION_TYPES.ACTION;
  }
}
class RollHandler {
  static {
    __name(this, "RollHandler");
  }
  /**
   * Register all roll-related hooks
   */
  static registerRollHooks() {
    info("Registering roll hooks...");
    try {
      RollHandler.registerChatMessageHook(), RollHandler.registerInitiativeHook(), RollHandler.registerTurnPrepUpdateHook(), info("Roll hooks registered successfully");
    } catch (error2) {
      warn(`Failed to register roll hooks: ${error2}`);
    }
  }
  /**
   * Register hook for chat message processing
   * Discovers rolls matching turn plan features
   */
  static registerChatMessageHook() {
    Hooks.on("chatMessage", (chatLog, message, chatData) => {
      debug(`Chat message received: ${message}`);
    });
  }
  /**
   * Register hook for initiative updates
   * Shows end-of-turn dialog when initiative advances
   */
  static registerInitiativeHook() {
    Hooks.on("combatRound", (combat, round, changed) => {
      debug(`Combat round changed to ${round}`), RollHandler.handleCombatRoundChange(combat, round);
    }), Hooks.on("combatTurn", (combat, turn, changed) => {
      debug("Combat turn changed"), RollHandler.handleCombatTurnChange(combat, turn);
    });
  }
  /**
   * Register hook for Turn Prep data updates
   * Note: We don't create edit checkpoints for current turn plan changes.
   * Edit checkpoints are only for history snapshots to prevent misuse as records.
   * The current turn plan is a working space where users can freely modify.
   */
  static registerTurnPrepUpdateHook() {
    Hooks.on("turnprepAddedFeature", (event2) => {
      debug(`Feature added to turn prep: ${event2.item?.name || "unknown"}`);
    }), Hooks.on("turnprepRemovedFeature", (event2) => {
      debug(`Feature removed from turn prep: ${event2.item?.name || "unknown"}`);
    });
  }
  /**
   * Handle combat round changes
   * Detect end of round and show dialog
   */
  static async handleCombatRoundChange(combat, round) {
    if (!combat?.combatant?.actor) return;
    const actor = combat.combatant.actor;
    debug(`Combat round change detected for ${actor.name}`), await RollHandler.showEndOfTurnDialog(actor);
  }
  /**
   * Handle combat turn changes
   * Detect when it's a new actor's turn
   */
  static async handleCombatTurnChange(combat, turn) {
    if (!combat?.combatant?.actor) return;
    const actor = combat.combatant.actor;
    debug(`Combat turn change detected for ${actor.name}`), await RollHandler.showEndOfTurnDialog(actor);
  }
  /**
   * Show end-of-turn dialog
   * Prompts to save current turn plan to history and clear it
   */
  static async showEndOfTurnDialog(actor) {
    try {
      const currentPlan = actor.getFlag(
        FLAG_SCOPE,
        "currentTurnPlan"
      );
      if (!currentPlan) {
        debug(`No current turn plan for ${actor.name}`), ui.notifications?.warn(`No active turn plan to save for ${actor.name}`);
        return;
      }
      if (!(currentPlan.actions.length > 0 || currentPlan.bonusActions.length > 0 || currentPlan.reactions.length > 0 || currentPlan.additionalFeatures.length > 0)) {
        debug(`Current turn plan is empty for ${actor.name}`), await Dialog.confirm({
          title: `End Turn - ${actor.name}`,
          content: "<p>Your current turn plan is empty. Clear it anyway?</p>"
        }) && (await actor.unsetFlag(FLAG_SCOPE, "currentTurnPlan"), ui.notifications?.info(`Turn plan cleared for ${actor.name}`));
        return;
      }
      if (!await Dialog.confirm({
        title: `End Turn - ${actor.name}`,
        content: `<p>Save your current turn plan to history and clear it?</p>
                  <p><strong>${currentPlan.name}</strong></p>
                  <ul>
                    <li>Actions: ${currentPlan.actions.length}</li>
                    <li>Bonus Actions: ${currentPlan.bonusActions.length}</li>
                    <li>Reactions: ${currentPlan.reactions.length}</li>
                    <li>Other: ${currentPlan.additionalFeatures.length}</li>
                  </ul>`
      })) {
        debug(`User cancelled end-of-turn for ${actor.name}`);
        return;
      }
      const snapshot = await RollHandler.createHistorySnapshot(actor, currentPlan), history = actor.getFlag(FLAG_SCOPE, "history") || [];
      history.push(snapshot), await actor.setFlag(FLAG_SCOPE, "history", history), await actor.unsetFlag(FLAG_SCOPE, "currentTurnPlan"), ui.notifications?.info(
        `Turn plan saved to history and cleared for ${actor.name}`
      ), debug(`Saved turn plan to history: ${snapshot.name}`);
    } catch (error2) {
      warn(`Failed to show end-of-turn dialog: ${error2}`);
    }
  }
  /**
   * Discover rolls in chat history matching a turn plan
   * Searches for rolls from items in the plan
   */
  static async discoverRollsForPlan(actor, plan) {
    const rolls = [];
    try {
      debug(`Discovering rolls for plan "${plan.name}"`);
      const features = [
        ...plan.actions,
        ...plan.bonusActions,
        ...plan.reactions,
        ...plan.additionalFeatures
      ];
      if (features.length === 0)
        return debug("No features in plan, no rolls to discover"), rolls;
      const chatMessages = Array.from(game.messages || []).filter((msg) => msg.speaker?.actor === actor.id).sort((a, b) => b.timestamp - a.timestamp).slice(0, 50);
      for (const msg of chatMessages) {
        const discoveredRolls = RollHandler.parseRollsFromChatMessage(msg, features);
        rolls.push(...discoveredRolls);
      }
      return debug(`Found ${rolls.length} rolls for plan "${plan.name}"`), rolls;
    } catch (error2) {
      return warn(`Failed to discover rolls: ${error2}`), rolls;
    }
  }
  /**
   * Discover saving throws in chat history
   * Looks for saving throw messages in chat
   */
  static async discoverSavingThrowsForActor(actor) {
    const saves = [];
    try {
      debug(`Discovering saving throws for ${actor.name}`);
      const chatMessages = Array.from(game.messages || []).filter((msg) => msg.actor?.id === actor.id).sort((a, b) => b.timestamp - a.timestamp).slice(0, 50);
      for (const msg of chatMessages) {
        const save = RollHandler.parseSavingThrowFromMessage(msg);
        save && saves.push(save);
      }
      return debug(`Found ${saves.length} saving throws for ${actor.name}`), saves;
    } catch (error2) {
      return warn(`Failed to discover saving throws: ${error2}`), saves;
    }
  }
  /**
   * Parse rolls from a chat message
   * Returns multiple rolls if message contains attack + damage
   */
  static parseRollsFromChatMessage(message, features) {
    const discoveredRolls = [];
    try {
      if (!message.rolls || message.rolls.length === 0) return discoveredRolls;
      const dnd5eFlags = message.flags?.dnd5e;
      if (!dnd5eFlags?.activity && !dnd5eFlags?.item) return discoveredRolls;
      if (!features.find(
        (f) => dnd5eFlags.activity?.id && f.activityId === dnd5eFlags.activity.id || dnd5eFlags.item?.id && f.sourceItemId === dnd5eFlags.item.id
      ))
        return debug(`Message for ${dnd5eFlags.item?.id} not in turn plan`), discoveredRolls;
      const itemName = dnd5eFlags.item?.uuid ? fromUuidSync(dnd5eFlags.item.uuid)?.name || message.flavor || "Unknown" : message.flavor || "Unknown", actorName = message.speaker?.alias || "Unknown", activityName = dnd5eFlags.activity?.uuid ? fromUuidSync(dnd5eFlags.activity.uuid)?.name : null;
      return message.rolls.forEach((roll, index2) => {
        const rollType = roll.constructor.name, rollLabel = rollType === "D20Roll" ? "Attack" : rollType === "DamageRoll" ? "Damage" : rollType, displayName = activityName ? `${itemName}: ${activityName}` : itemName;
        discoveredRolls.push({
          id: generateId(),
          actorName,
          itemName: `${displayName} (${rollLabel})`,
          rollFormula: roll.formula,
          result: roll.total,
          timestamp: message.timestamp || Date.now(),
          chatMessageId: message.id
        });
      }), discoveredRolls;
    } catch (error2) {
      return debug(`Failed to parse rolls from message: ${error2}`), discoveredRolls;
    }
  }
  /**
   * Parse a saving throw from a chat message
   */
  static parseSavingThrowFromMessage(message) {
    try {
      if (!message.flavor?.includes("Save")) return null;
      const flavor = message.flavor || "", savingThrowMatch = flavor.match(/(str|dex|con|int|wis|cha)/i);
      if (!savingThrowMatch) return null;
      const savingThrowType = savingThrowMatch[1].toLowerCase(), dcMatch = flavor.match(/DC\s*(\d+)/i), dc = dcMatch ? parseInt(dcMatch[1]) : 0;
      return {
        id: generateId(),
        actorName: message.actor?.name || "Unknown",
        savingThrowType,
        dc,
        result: message.roll?.total || 0,
        success: (message.roll?.total || 0) >= dc,
        timestamp: message.timestamp || Date.now(),
        chatMessageId: message.id
      };
    } catch (error2) {
      return debug(`Failed to parse saving throw: ${error2}`), null;
    }
  }
  /**
   * Create a history snapshot for current turn plan
   * Includes discovered rolls and saving throws
   */
  static async createHistorySnapshot(actor, plan) {
    try {
      debug(`Creating history snapshot for "${plan.name}"`);
      const editHistory = actor.getFlag(
        FLAG_SCOPE,
        `editHistory_${plan.name}`
      ), rolls = await RollHandler.discoverRollsForPlan(actor, plan), savingThrows = await RollHandler.discoverSavingThrowsForActor(actor);
      return {
        id: generateId(),
        name: plan.name,
        actions: plan.actions,
        bonusActions: plan.bonusActions,
        movement: plan.movement,
        reactions: plan.reactions,
        trigger: plan.trigger,
        roleplay: plan.roleplay,
        additionalFeatures: plan.additionalFeatures,
        notes: plan.notes,
        timestamp: Date.now(),
        rolls,
        savingThrows,
        editHistory: editHistory || [],
        lastEditedAt: plan.timestamp || Date.now()
      };
    } catch (error2) {
      return warn(`Failed to create history snapshot: ${error2}`), {
        id: generateId(),
        name: plan.name,
        actions: plan.actions,
        bonusActions: plan.bonusActions,
        movement: plan.movement,
        reactions: plan.reactions,
        trigger: plan.trigger,
        roleplay: plan.roleplay,
        additionalFeatures: plan.additionalFeatures,
        notes: plan.notes,
        timestamp: Date.now(),
        rolls: [],
        savingThrows: [],
        editHistory: [],
        lastEditedAt: plan.timestamp || Date.now()
      };
    }
  }
  /**
   * Create an edit checkpoint for the turn plan
   * Stores a snapshot of the plan at a point in time
   */
  static async createEditCheckpoint(actor, plan, description) {
    try {
      const checkpointLimit = FoundryAdapter.getSetting("editHistoryCheckpoints");
      let checkpoints = actor.getFlag(
        FLAG_SCOPE,
        `editHistory_${plan.name}`
      ) || [];
      const checkpoint = {
        id: generateId(),
        timestamp: Date.now(),
        snapshot: JSON.parse(JSON.stringify(plan)),
        // Deep copy
        description
      };
      checkpoints.push(checkpoint), checkpoints.length > checkpointLimit && (checkpoints = checkpoints.slice(-checkpointLimit)), await actor.setFlag(
        FLAG_SCOPE,
        `editHistory_${plan.name}`,
        checkpoints
      ), debug(`Created edit checkpoint for "${plan.name}": ${description}`);
    } catch (error2) {
      warn(`Failed to create edit checkpoint: ${error2}`);
    }
  }
  /**
   * Restore a turn plan from a previous edit checkpoint
   */
  static async restorePlanFromCheckpoint(actor, planName, checkpointId) {
    try {
      const checkpoints = actor.getFlag(
        FLAG_SCOPE,
        `editHistory_${planName}`
      );
      if (!checkpoints) return null;
      const checkpoint = checkpoints.find((cp) => cp.id === checkpointId);
      if (!checkpoint) return null;
      const restoredPlan = checkpoint.snapshot;
      return await actor.setFlag(FLAG_SCOPE, "currentTurnPlan", restoredPlan), ui.notifications?.info(`Restored turn plan to: ${checkpoint.description}`), restoredPlan;
    } catch (error2) {
      return warn(`Failed to restore checkpoint: ${error2}`), null;
    }
  }
  /**
   * Check if a feature still exists on an actor
   * Used to detect missing features and auto-remove them
   */
  static doesFeatureExist(actor, feature) {
    try {
      return !!actor.items.get(feature.sourceItemId);
    } catch (error2) {
      return warn(`Failed to check feature existence: ${error2}`), !1;
    }
  }
  /**
   * Remove missing features from a turn plan
   * Mirrors Tidy5E behavior
   */
  static async removeMissingFeaturesFromPlan(actor, plan) {
    const cleaned = {
      ...plan,
      actions: plan.actions.filter((f) => RollHandler.doesFeatureExist(actor, f)),
      bonusActions: plan.bonusActions.filter((f) => RollHandler.doesFeatureExist(actor, f)),
      reactions: plan.reactions.filter((f) => RollHandler.doesFeatureExist(actor, f)),
      additionalFeatures: plan.additionalFeatures.filter(
        (f) => RollHandler.doesFeatureExist(actor, f)
      )
    }, removed = plan.actions.length - cleaned.actions.length + plan.bonusActions.length - cleaned.bonusActions.length + plan.reactions.length - cleaned.reactions.length + plan.additionalFeatures.length - cleaned.additionalFeatures.length;
    return removed > 0 && (debug(`Removed ${removed} missing features from turn plan`), await actor.setFlag(FLAG_SCOPE, "currentTurnPlan", cleaned)), cleaned;
  }
}
Hooks.once("ready", () => {
  RollHandler.registerRollHooks();
});
const SETTING_KEYS = {
  HISTORY_LIMIT: "historyLimit",
  // World setting: default history limit
  EDIT_HISTORY_CHECKPOINTS: "editHistoryCheckpoints",
  // World setting: checkpoint limit
  ALLOW_PLAYER_EDIT_HISTORY: "allowPlayerEditHistory"
  // World setting: player edit permission
}, ACTOR_FLAG_KEYS = {
  HISTORY_LIMIT: "historyLimit",
  // Per-actor override of history limit
  EDIT_HISTORY_ENABLED: "editHistoryEnabled"
  // Per-actor edit history enabled
};
function getDefaultHistoryLimit() {
  try {
    const limit = FoundryAdapter.getSetting(SETTING_KEYS.HISTORY_LIMIT);
    return typeof limit == "number" && limit > 0 ? limit : SETTINGS.HISTORY_LIMIT.default;
  } catch (error2) {
    return warn("Error retrieving history limit setting", { error: error2 }), SETTINGS.HISTORY_LIMIT.default;
  }
}
__name(getDefaultHistoryLimit, "getDefaultHistoryLimit");
function getEditHistoryCheckpointLimit() {
  try {
    const limit = FoundryAdapter.getSetting(SETTING_KEYS.EDIT_HISTORY_CHECKPOINTS);
    return typeof limit == "number" && limit > 0 ? limit : (warn("Invalid edit history checkpoint setting, falling back to default", { limit }), 5);
  } catch (error2) {
    return warn("Error retrieving edit history checkpoint setting", { error: error2 }), 5;
  }
}
__name(getEditHistoryCheckpointLimit, "getEditHistoryCheckpointLimit");
function canPlayersEditHistory() {
  try {
    const allowed = FoundryAdapter.getSetting(SETTING_KEYS.ALLOW_PLAYER_EDIT_HISTORY);
    return typeof allowed == "boolean" ? allowed : !0;
  } catch (error2) {
    return warn("Error retrieving player edit history setting", { error: error2 }), !0;
  }
}
__name(canPlayersEditHistory, "canPlayersEditHistory");
function isTurnPrepTabEnabled() {
  try {
    return !0;
  } catch (error2) {
    return warn("Error retrieving Turn Prep tab enabled setting", { error: error2 }), !0;
  }
}
__name(isTurnPrepTabEnabled, "isTurnPrepTabEnabled");
function getHistoryLimitForActor(actor) {
  if (!actor || !actor.id)
    return debug("Actor not provided, using default history limit"), getDefaultHistoryLimit();
  try {
    const actorLimit = FoundryAdapter.getFlag(actor, ACTOR_FLAG_KEYS.HISTORY_LIMIT);
    if (typeof actorLimit == "number" && actorLimit > 0)
      return debug("Using per-actor history limit", { actorId: actor.id, limit: actorLimit }), actorLimit;
    const defaultLimit = getDefaultHistoryLimit();
    return debug("Using default history limit for actor", { actorId: actor.id, limit: defaultLimit }), defaultLimit;
  } catch (error2) {
    return warn("Error retrieving history limit for actor", { actorId: actor?.id, error: error2 }), getDefaultHistoryLimit();
  }
}
__name(getHistoryLimitForActor, "getHistoryLimitForActor");
async function setHistoryLimitForActor(actor, limit) {
  if (!actor || !actor.id)
    throw new Error("Actor with valid ID required to set history limit");
  if (!Number.isInteger(limit) || limit < 1)
    throw new Error("History limit must be a positive integer");
  try {
    await FoundryAdapter.setFlag(actor, ACTOR_FLAG_KEYS.HISTORY_LIMIT, limit), debug("Set history limit for actor", { actorId: actor.id, limit });
  } catch (error2) {
    throw warn("Error setting history limit for actor", { actorId: actor.id, limit, error: error2 }), error2;
  }
}
__name(setHistoryLimitForActor, "setHistoryLimitForActor");
async function clearHistoryLimitOverride(actor) {
  if (!actor || !actor.id)
    throw new Error("Actor with valid ID required to clear history limit override");
  try {
    await FoundryAdapter.deleteFlag(actor, ACTOR_FLAG_KEYS.HISTORY_LIMIT), debug("Cleared history limit override for actor", { actorId: actor.id });
  } catch (error2) {
    throw warn("Error clearing history limit override", { actorId: actor.id, error: error2 }), error2;
  }
}
__name(clearHistoryLimitOverride, "clearHistoryLimitOverride");
function isEditHistoryEnabledForActor(actor) {
  if (!actor)
    return canPlayersEditHistory();
  try {
    const actorSetting = FoundryAdapter.getFlag(actor, ACTOR_FLAG_KEYS.EDIT_HISTORY_ENABLED);
    return typeof actorSetting == "boolean" ? actorSetting : canPlayersEditHistory();
  } catch (error2) {
    return warn("Error retrieving edit history setting for actor", { actorId: actor?.id, error: error2 }), canPlayersEditHistory();
  }
}
__name(isEditHistoryEnabledForActor, "isEditHistoryEnabledForActor");
class TurnPrepApi {
  static {
    __name(this, "TurnPrepApi");
  }
  // Settings namespace for accessing configuration
  settings = {
    getDefaultHistoryLimit: /* @__PURE__ */ __name(() => getDefaultHistoryLimit(), "getDefaultHistoryLimit"),
    getHistoryLimitForActor: /* @__PURE__ */ __name((actor) => getHistoryLimitForActor(actor), "getHistoryLimitForActor"),
    setHistoryLimitForActor: /* @__PURE__ */ __name((actor, limit) => setHistoryLimitForActor(actor, limit), "setHistoryLimitForActor"),
    clearHistoryLimitOverride: /* @__PURE__ */ __name((actor) => clearHistoryLimitOverride(actor), "clearHistoryLimitOverride"),
    getEditHistoryCheckpointLimit: /* @__PURE__ */ __name(() => getEditHistoryCheckpointLimit(), "getEditHistoryCheckpointLimit"),
    canPlayersEditHistory: /* @__PURE__ */ __name(() => canPlayersEditHistory(), "canPlayersEditHistory"),
    isTurnPrepTabEnabled: /* @__PURE__ */ __name(() => isTurnPrepTabEnabled(), "isTurnPrepTabEnabled"),
    isEditHistoryEnabledForActor: /* @__PURE__ */ __name((actor) => isEditHistoryEnabledForActor(actor), "isEditHistoryEnabledForActor")
  };
  // Roll integration namespace for managing history and rolls
  rolls = {
    createHistorySnapshot: /* @__PURE__ */ __name((actor, plan) => RollHandler.createHistorySnapshot(actor, plan), "createHistorySnapshot"),
    discoverRollsForPlan: /* @__PURE__ */ __name((actor, plan) => RollHandler.discoverRollsForPlan(actor, plan), "discoverRollsForPlan"),
    discoverSavingThrowsForActor: /* @__PURE__ */ __name((actor) => RollHandler.discoverSavingThrowsForActor(actor), "discoverSavingThrowsForActor"),
    createEditCheckpoint: /* @__PURE__ */ __name((actor, plan, description) => RollHandler.createEditCheckpoint(actor, plan, description), "createEditCheckpoint"),
    restorePlanFromCheckpoint: /* @__PURE__ */ __name((actor, planName, checkpointId) => RollHandler.restorePlanFromCheckpoint(actor, planName, checkpointId), "restorePlanFromCheckpoint"),
    removeMissingFeaturesFromPlan: /* @__PURE__ */ __name((actor, plan) => RollHandler.removeMissingFeaturesFromPlan(actor, plan), "removeMissingFeaturesFromPlan"),
    showEndOfTurnDialog: /* @__PURE__ */ __name((actor) => RollHandler.showEndOfTurnDialog(actor), "showEndOfTurnDialog")
  };
  // Debug namespace for troubleshooting context menu and other integration issues
  debug = {
    /**
     * Get an item by ID from any actor's owned items
     * Searches through all actors to find the item
     */
    getItemById: /* @__PURE__ */ __name((itemId) => {
      console.log(`[Turn Prep Debug] Searching for item with ID: ${itemId}`);
      const actors = game.actors?.contents || [];
      for (const actor of actors) {
        const item = actor.items.get(itemId);
        if (item)
          return console.log(`[Turn Prep Debug] Found item: "${item.name}" (ID: ${itemId}) on actor "${actor.name}"`), item;
      }
      for (const window2 of Object.values(ui.windows)) {
        const w = window2;
        if (w.object && w.object.items) {
          const item = w.object.items.get(itemId);
          if (item)
            return console.log(`[Turn Prep Debug] Found item: "${item.name}" (ID: ${itemId}) on actor "${w.object.name}"`), item;
        }
      }
      return console.warn(`[Turn Prep Debug] Item not found with ID: ${itemId}`), console.warn("[Turn Prep Debug] Tip: Use game.TurnPrepAPI.debug.listAllItems() to see available items"), null;
    }, "getItemById"),
    /**
     * List all items from all actors (helpful for finding IDs)
     */
    listAllItems: /* @__PURE__ */ __name(() => {
      console.log("[Turn Prep Debug] Listing all items from all actors:");
      const actors = game.actors?.contents || [];
      for (const actor of actors) {
        console.log(`
  Actor: "${actor.name}" (ID: ${actor.id})`);
        const items = actor.items.contents || [];
        for (const item of items)
          console.log(`    - "${item.name}" (ID: ${item.id}, Type: ${item.type})`);
      }
    }, "listAllItems"),
    /**
     * Test if activities can be found for an item
     * Accepts either an Item object or an item ID string
     */
    testActivitiesForItem: /* @__PURE__ */ __name((itemOrId) => {
      let item = null;
      if (typeof itemOrId == "string") {
        if (item = window.TurnPrepAPI?.debug?.getItemById(itemOrId) || null, !item)
          return console.warn(`[Turn Prep Debug] Could not find item with ID: ${itemOrId}`), [];
      } else
        item = itemOrId;
      if (!item)
        return console.warn("[Turn Prep Debug] No item provided"), [];
      const activities = FeatureSelector.getActivitiesForItem(item);
      return console.log(`[Turn Prep Debug] Found ${activities.length} activities for item "${item.name}":`, activities), activities;
    }, "testActivitiesForItem"),
    /**
     * Test the context menu handler on a specific item
     * Accepts either Item/Actor objects or ID strings
     */
    testContextMenuForItem: /* @__PURE__ */ __name((actorOrId, itemOrId) => {
      let actor = null, item = null;
      if (typeof actorOrId == "string") {
        if (actor = game.actors?.get(actorOrId) || null, !actor) {
          console.warn(`[Turn Prep Debug] Could not find actor with ID: ${actorOrId}`);
          return;
        }
      } else
        actor = actorOrId;
      if (typeof itemOrId == "string") {
        if (item = actor?.items?.get(itemOrId) || null, !item) {
          console.warn(`[Turn Prep Debug] Could not find item with ID: ${itemOrId}`);
          return;
        }
      } else
        item = itemOrId;
      if (!actor || !item) {
        console.warn("[Turn Prep Debug] Actor and item required");
        return;
      }
      const activities = FeatureSelector.getActivitiesForItem(item);
      console.log(`[Turn Prep Debug] Testing context menu for "${item.name}" on actor "${actor.name}"`), console.log("[Turn Prep Debug] Activities found:", activities), activities.length > 0 ? console.log("[Turn Prep Debug] Context menu item would be added") : console.log("[Turn Prep Debug] Context menu item would NOT be added (no activities)");
    }, "testContextMenuForItem"),
    /**
     * Inspect the DOM structure of items in currently open sheets
     */
    inspectSheetItemDom: /* @__PURE__ */ __name(() => {
      console.log("[Turn Prep Debug] Inspecting open sheet items:");
      for (const window2 of Object.values(ui.windows)) {
        const w = window2;
        if (w.object && w.object.items) {
          console.log(`Sheet: ${w.constructor.name} for actor "${w.object.name}"`);
          const itemElements = w.element?.find("[data-item-id]");
          console.log(`Found ${itemElements?.length ?? 0} elements with [data-item-id] attribute`), itemElements?.each((i, el) => {
            const itemId = el.getAttribute("data-item-id"), item = w.object.items.get(itemId);
            console.log(`  - ${item?.name} (${itemId})`);
          });
        }
      }
    }, "inspectSheetItemDom"),
    /**
     * Check module integration status
     */
    checkIntegration: /* @__PURE__ */ __name(() => {
      console.log("[Turn Prep Debug] Module Integration Status:");
      const api = window.TurnPrepAPI || TurnPrepApiInstance;
      console.log(`Tidy 5E integrated: ${api.isTidyIntegrated()}`), console.log(`MidiQOL available: ${api.isMidiQOLAvailable()}`), console.log(`Module version: ${api.getModuleVersion()}`), console.log("Available features:", api.getAvailableFeatures());
    }, "checkIntegration"),
    /**
     * Comprehensive hook detection - logs ALL hooks that fire
     */
    detectAllHooks: /* @__PURE__ */ __name(() => {
      console.log("[Turn Prep Debug] Starting comprehensive hook detection"), console.log("[Turn Prep Debug] Right-click an item and watch for hook names below..."), Hooks.on.bind(Hooks);
      const contextMenuHooks = [
        "dnd5e.getItemContextOptions",
        "getItemContextOptions",
        "getContextOptions",
        "contextMenu",
        "dnd5e.contextMenu",
        "tidy5e.contextMenu",
        "tidy5e.itemContextMenu",
        "renderContextMenu",
        "preRenderContextMenu"
      ];
      contextMenuHooks.forEach((hookName) => {
        Hooks.on(hookName, (...args) => {
          console.log(`[Turn Prep Debug] ✓✓✓ HOOK FIRED: ${hookName}`, args);
        });
      }), console.log("[Turn Prep Debug] Listening for hooks:", contextMenuHooks), console.log("[Turn Prep Debug] Now right-click an item in the sheet...");
    }, "detectAllHooks"),
    /**
     * List all registered hooks
     */
    listRegisteredHooks: /* @__PURE__ */ __name(() => {
      console.log("[Turn Prep Debug] Registered hooks:");
      const hooksObj = Hooks._hooks;
      if (hooksObj) {
        const hookNames = Object.keys(hooksObj).sort();
        console.log(`[Turn Prep Debug] Total hooks: ${hookNames.length}`), hookNames.forEach((name) => {
          const callbacks = hooksObj[name];
          Array.isArray(callbacks) && callbacks.length > 0 && console.log(`  - ${name}: ${callbacks.length} callback(s)`);
        });
      } else
        console.warn("[Turn Prep Debug] Could not access Hooks object");
    }, "listRegisteredHooks")
  };
  constructor() {
    info("Turn Prep API initialized");
  }
  // ========================================================================
  // Actor Data Methods
  // ========================================================================
  /**
   * Get Turn Prep data for an actor
   * @param actor - The actor object
   * @returns The Turn Prep data, or null if not found
   */
  getTurnPrepData(actor) {
    return FoundryAdapter.getTurnPrepData(actor);
  }
  /**
   * Save Turn Prep data to an actor
   * @param actor - The actor object
   * @param data - The data to save
   * @returns Promise that resolves when data is saved
   */
  async saveTurnPrepData(actor, data, options = {}) {
    return FoundryAdapter.setTurnPrepData(actor, data, options);
  }
  /**
   * Clear all Turn Prep data from an actor
   * @param actor - The actor object
   * @returns Promise that resolves when data is cleared
   */
  async clearTurnPrepData(actor) {
    return FoundryAdapter.deleteFlag(actor, "turnPrepData");
  }
  // ========================================================================
  // Info Methods
  // ========================================================================
  // ========================================================================
  // DM Questions Management
  // ========================================================================
  /**
   * Get all DM questions for an actor
   * @param actor - The actor to get questions for
   * @returns Array of DM questions
   */
  async getDMQuestions(actor) {
    return TurnPrepStorage.getInstance().getDMQuestions(actor);
  }
  /**
   * Save DM questions for an actor
   * @param actor - The actor to save questions for
   * @param questions - Array of questions to save
   */
  async saveDMQuestions(actor, questions) {
    return TurnPrepStorage.getInstance().saveDMQuestions(actor, questions);
  }
  /**
   * Send a question to the DM as a whisper
   * @param actor - The actor sending the question
   * @param questionText - The question text
   */
  async sendQuestionToDm(actor, questionText) {
    const dmUsers = game.users?.filter((u) => u.isGM) || [];
    if (dmUsers.length === 0)
      throw new Error("No GM users found");
    const message = `${actor.name} asks: ${questionText}`, dmUserIds = dmUsers.map((u) => u.id);
    await ChatMessage.create({
      content: message,
      whisper: dmUserIds,
      speaker: ChatMessage.getSpeaker({ actor })
    });
  }
  /**
   * Send a question to public chat
   * @param actor - The actor sending the question
   * @param questionText - The question text
   */
  async sendQuestionPublic(actor, questionText) {
    const message = `${actor.name} asks: ${questionText}`;
    await ChatMessage.create({
      content: message,
      speaker: ChatMessage.getSpeaker({ actor })
    });
  }
  // ========================================================================
  // Module Information
  // ========================================================================
  /**
   * Get the module ID
   * @returns The module ID string
   */
  getModuleId() {
    return MODULE_ID;
  }
  /**
   * Get module version
   * @returns The module version string
   */
  getModuleVersion() {
    return FoundryAdapter.getModule(MODULE_ID)?.version ?? "0.0.0";
  }
  /**
   * Check if a specific feature is available
   * @param featureName - The feature name to check
   * @returns True if feature is available
   */
  isFeatureAvailable(featureName) {
    return [
      "dmQuestions",
      "turnPlans",
      "reactions",
      "history",
      "favorites",
      "contextMenu"
    ].includes(featureName);
  }
  /**
   * Get list of all available features
   * @returns Array of feature names
   */
  getAvailableFeatures() {
    return [
      "dmQuestions",
      "turnPlans",
      "reactions",
      "history",
      "favorites",
      "contextMenu"
    ];
  }
  /**
   * Check if Tidy 5E is integrated
   * @returns True if Tidy 5E integration is active
   */
  isTidyIntegrated() {
    return FoundryAdapter.isModuleActive("tidy5e-sheet");
  }
  /**
   * Check if MidiQOL is available
   * @returns True if MidiQOL is active
   */
  isMidiQOLAvailable() {
    return FoundryAdapter.isModuleActive("midi-qol");
  }
  // ========================================================================
  // Phase 2: Data Layer Methods
  // ========================================================================
  /**
   * Load Turn Prep data from actor flags
   * Returns empty data if none exists
   * @param actor - The actor to load data for
   * @returns Promise resolving to TurnPrepData
   */
  async loadTurnPrepData(actor) {
    return TurnPrepStorage.load(actor);
  }
  /**
   * Save Turn Prep data to actor flags
   * @param actor - The actor to save data for
   * @param data - The TurnPrepData to save
   * @returns Promise that resolves when saved
   */
  async saveTurnPrepDataToFlags(actor, data) {
    return TurnPrepStorage.save(actor, data);
  }
  /**
   * Get all selectable features for an actor
   * @param actor - The actor to query
   * @returns Array of selectable features
   */
  getAllActorFeatures(actor) {
    return FeatureSelector.getAllSelectableFeatures(actor);
  }
  /**
   * Get features by activation type (action, bonus, reaction)
   * @param actor - The actor to query
   * @param activationType - The activation type
   * @returns Array of matching features
   */
  getFeaturesByActivationType(actor, activationType) {
    return FeatureSelector.getFeaturesByActivationType(actor, activationType);
  }
  /**
   * Get features by item type (spell, weapon, feat, etc.)
   * @param actor - The actor to query
   * @param itemType - The item type
   * @returns Array of matching features
   */
  getFeaturesByItemType(actor, itemType) {
    return FeatureSelector.getFeaturesByItemType(actor, itemType);
  }
  // ========================================================================
  // Hook Registration (for external modules)
  // ========================================================================
  /**
   * Register a callback for when Turn Prep data changes
   * @param callback - Function to call when data changes
   * @returns Hook ID for later unregistration
   */
  onTurnPrepDataChanged(callback) {
    return FoundryAdapter.onHook("turnPrep.dataChanged", callback);
  }
  /**
   * Register a callback for when a feature is selected
   * @param callback - Function to call when feature is selected
   * @returns Hook ID for later unregistration
   */
  onFeatureSelected(callback) {
    return FoundryAdapter.onHook("turnPrep.featureSelected", callback);
  }
  /**
   * Unregister a hook
   * @param hookName - The hook name
   * @param hookId - The hook ID to unregister
   */
  offHook(hookName, hookId) {
    FoundryAdapter.offHook(hookName, hookId);
  }
  // ========================================================================
  // Utility Methods
  // ========================================================================
  /**
   * Log a message from external modules
   * @param message - The message to log
   * @param data - Optional data to log
   */
  log(message, data) {
    info(`[External Module] ${message}`, data);
  }
  /**
   * Log a warning from external modules
   * @param message - The warning message
   * @param data - Optional data to log
   */
  warn(message, data) {
    warn(`[External Module] ${message}`, data);
  }
  // ========================================================================
  // Version Check
  // ========================================================================
  /**
   * Check if the API version matches requirements
   * @param majorVersion - Required major version
   * @returns True if compatible
   */
  isApiVersionCompatible(majorVersion) {
    const currentVersion = this.getModuleVersion();
    return parseInt(currentVersion.split(".")[0]) >= majorVersion;
  }
}
const TurnPrepApiInstance = new TurnPrepApi();
class FeatureFilter {
  static {
    __name(this, "FeatureFilter");
  }
  /**
   * Filter features by activation type (action, bonus action, reaction)
   * 
   * @param features - Array of features to filter
   * @param activationType - The activation type to match
   * @returns Filtered array of features
   */
  static filterByActionType(features, activationType) {
    return debug(
      `FeatureFilter.filterByActionType(): Filtering ${features.length} features by ${activationType}`
    ), features.filter((feature) => feature.actionType === activationType);
  }
  /**
   * Filter features by item type (spell, weapon, feat, etc.)
   * 
   * @param features - Array of features to filter
   * @param itemType - The item type to match
   * @returns Filtered array of features
   */
  static filterByItemType(features, itemType) {
    return debug(`FeatureFilter.filterByItemType(): Filtering ${features.length} features by ${itemType}`), features.filter((feature) => feature.itemType === itemType);
  }
  /**
   * Filter features by search text
   * Performs fuzzy matching on item name
   * 
   * @param features - Array of features to filter
   * @param searchText - Text to search for
   * @returns Filtered array of matching features
   */
  static filterBySearch(features, searchText) {
    if (!searchText || searchText.trim().length === 0)
      return features;
    const search = searchText.toLowerCase().trim();
    return debug(`FeatureFilter.filterBySearch(): Searching ${features.length} features for "${search}"`), features.filter((feature) => feature.itemName.toLowerCase().includes(search));
  }
  /**
   * Group features by activation type
   * Returns object with keys: 'action', 'bonus', 'reaction', etc.
   * 
   * @param features - Array of features to group
   * @returns Object with features grouped by activation type
   */
  static groupByActionType(features) {
    debug(`FeatureFilter.groupByActionType(): Grouping ${features.length} features by action type`);
    const grouped = {};
    for (const feature of features)
      grouped[feature.actionType] || (grouped[feature.actionType] = []), grouped[feature.actionType].push(feature);
    return grouped;
  }
  /**
   * Group features by item type
   * Returns object with keys: 'spell', 'weapon', 'feat', etc.
   * 
   * @param features - Array of features to group
   * @returns Object with features grouped by item type
   */
  static groupByItemType(features) {
    debug(`FeatureFilter.groupByItemType(): Grouping ${features.length} features by item type`);
    const grouped = {};
    for (const feature of features)
      grouped[feature.itemType] || (grouped[feature.itemType] = []), grouped[feature.itemType].push(feature);
    return grouped;
  }
  /**
   * Sort features alphabetically by name
   * Modifies the original array
   * 
   * @param features - Array of features to sort
   * @returns Sorted array
   */
  static sortByName(features) {
    return debug(`FeatureFilter.sortByName(): Sorting ${features.length} features`), [...features].sort((a, b) => a.itemName.localeCompare(b.itemName));
  }
  /**
   * Deduplicate features by item ID
   * Keeps first occurrence of each unique ID
   * 
   * @param features - Array of features to deduplicate
   * @returns Deduplicated array
   */
  static deduplicate(features) {
    debug(`FeatureFilter.deduplicate(): Deduplicating ${features.length} features`);
    const seen = /* @__PURE__ */ new Set(), unique = [];
    for (const feature of features)
      seen.has(feature.itemId) || (seen.add(feature.itemId), unique.push(feature));
    return unique;
  }
  /**
   * Limit array to specified number of items
   * Useful for pagination or limiting results
   * 
   * @param features - Array of features to limit
   * @param limit - Maximum number of items to return
   * @returns Limited array
   */
  static limit(features, limit) {
    return limit <= 0 ? [] : features.slice(0, limit);
  }
  /**
   * Build organized feature list for UI display
   * Groups by activation type, sorts alphabetically within groups
   * 
   * @param features - Array of features to organize
   * @returns Object with organized features ready for display
   */
  static organizeForDisplay(features) {
    debug(`FeatureFilter.organizeForDisplay(): Organizing ${features.length} features for display`);
    const grouped = this.groupByActionType(features);
    for (const actionType in grouped)
      grouped[actionType] = this.sortByName(grouped[actionType]);
    return grouped;
  }
  /**
   * Search features with multiple filters applied
   * Filters by search text, activation type, and item type
   * 
   * @param features - Array of features to search
   * @param searchText - Text to search for (optional)
   * @param activationType - Activation type filter (optional)
   * @param itemType - Item type filter (optional)
   * @returns Filtered and sorted array
   */
  static search(features, searchText, activationType, itemType) {
    let results = features;
    return searchText && (results = this.filterBySearch(results, searchText)), activationType && (results = this.filterByActionType(results, activationType)), itemType && (results = this.filterByItemType(results, itemType)), this.sortByName(results);
  }
}
async function initializeModule() {
  logSection("TURN PREP INITIALIZATION");
  try {
    validateEnvironment(), globalThis.TURN_PREP_DEBUG && (setDebugMode(!0), info("Debug mode enabled")), registerModuleSettings(), setupErrorHandling(), setupPublicAPI(), info("Module initialization complete");
  } catch (err) {
    throw error("Failed to initialize module", err), err;
  }
}
__name(initializeModule, "initializeModule");
function validateEnvironment() {
  info("Checking environment...");
  const { foundryOk, systemOk, message } = FoundryAdapter.checkVersionCompatibility();
  if (info(message), !foundryOk || !systemOk) {
    const warnings = [];
    foundryOk || warnings.push("Foundry version V13+ is required"), systemOk || warnings.push("D&D 5e system v5.0+ is required");
    const fullMessage = `${LOG_PREFIX} Warning: ${warnings.join(", ")}`;
    warn(fullMessage);
  }
}
__name(validateEnvironment, "validateEnvironment");
function registerModuleSettings() {
  info("Registering module settings..."), FoundryAdapter.registerSetting(SETTINGS.HISTORY_LIMIT.key, {
    name: "TurnPrep.Settings.HistoryLimit",
    hint: "TurnPrep.Settings.HistoryLimitHint",
    scope: SETTINGS.HISTORY_LIMIT.scope,
    config: !0,
    type: Number,
    default: SETTINGS.HISTORY_LIMIT.default,
    range: SETTINGS.HISTORY_LIMIT.range,
    onChange: /* @__PURE__ */ __name((value) => {
      info(`History limit changed to: ${value}`);
    }, "onChange")
  }), FoundryAdapter.registerSetting(SETTINGS.ALLOW_DM_VIEW.key, {
    name: "TurnPrep.Settings.AllowDmView",
    hint: "TurnPrep.Settings.AllowDmViewHint",
    scope: SETTINGS.ALLOW_DM_VIEW.scope,
    config: !0,
    type: Boolean,
    default: SETTINGS.ALLOW_DM_VIEW.default,
    onChange: /* @__PURE__ */ __name((value) => {
      info(`DM view setting changed to: ${value}`);
    }, "onChange")
  }), FoundryAdapter.registerSetting(SETTINGS.ENABLE_TAB.key, {
    name: "TurnPrep.Settings.EnableTab",
    hint: "TurnPrep.Settings.EnableTabHint",
    scope: SETTINGS.ENABLE_TAB.scope,
    config: !0,
    type: Boolean,
    default: SETTINGS.ENABLE_TAB.default,
    onChange: /* @__PURE__ */ __name((value) => {
      info(`Turn Prep tab setting changed to: ${value}`);
    }, "onChange")
  }), FoundryAdapter.registerSetting("editHistoryCheckpoints", {
    name: "TurnPrep.Settings.EditHistoryCheckpoints",
    hint: "TurnPrep.Settings.EditHistoryCheckpointsHint",
    scope: "world",
    config: !0,
    type: Number,
    default: 5,
    range: {
      min: 1,
      max: 20,
      step: 1
    },
    onChange: /* @__PURE__ */ __name((value) => {
      info(`Edit history checkpoint limit changed to: ${value}`);
    }, "onChange")
  }), FoundryAdapter.registerSetting("allowPlayerEditHistory", {
    name: "TurnPrep.Settings.AllowPlayerEditHistory",
    hint: "TurnPrep.Settings.AllowPlayerEditHistoryHint",
    scope: "world",
    config: !0,
    type: Boolean,
    default: !0,
    onChange: /* @__PURE__ */ __name((value) => {
      info(`Player edit history setting changed to: ${value}`);
    }, "onChange")
  }), info("Settings registered");
}
__name(registerModuleSettings, "registerModuleSettings");
class TurnPrepError extends Error {
  static {
    __name(this, "TurnPrepError");
  }
  constructor(message, operation = "unknown", context) {
    super(`${operation}: ${message}`), this.operation = operation, this.context = context, this.name = "TurnPrepError";
  }
}
class DataValidationError extends TurnPrepError {
  static {
    __name(this, "DataValidationError");
  }
  constructor(message, context) {
    super(message, "DataValidation", context), this.name = "DataValidationError";
  }
}
class FoundryError extends TurnPrepError {
  static {
    __name(this, "FoundryError");
  }
  constructor(message, operation = "FoundryAPI", context) {
    super(message, operation, context), this.name = "FoundryError";
  }
}
function setupErrorHandling() {
  info("Setting up error handling..."), globalThis.TurnPrepError = TurnPrepError, globalThis.DataValidationError = DataValidationError, globalThis.FoundryError = FoundryError, window.addEventListener("unhandledrejection", (event2) => {
    event2.reason?.name?.includes("TurnPrep") && (error("Unhandled Turn Prep error", event2.reason), event2.preventDefault());
  }), info("Error handling initialized");
}
__name(setupErrorHandling, "setupErrorHandling");
function setupPublicAPI() {
  info("Setting up public API...");
  const api = new TurnPrepApi(), module = FoundryAdapter.getModule(MODULE_ID);
  module && (module.api = api), globalThis.TurnPrepAPI = api, globalThis.TurnPrepStorage = TurnPrepStorage, globalThis.FeatureSelector = FeatureSelector, globalThis.FeatureFilter = FeatureFilter, globalThis.createDMQuestion = createDMQuestion, globalThis.createTurnPlan = createTurnPlan, globalThis.createEmptyTurnPrepData = createEmptyTurnPrepData, globalThis.createTurnSnapshot = createTurnSnapshot, globalThis.snapshotFeature = snapshotFeature, globalThis.validateAndCorrectTurnPrepData = validateAndCorrectTurnPrepData, globalThis.generateId = generateId, info("Public API initialized and available as window.TurnPrepAPI"), info("Phase 2 utilities available: TurnPrepStorage, FeatureSelector, FeatureFilter");
}
__name(setupPublicAPI, "setupPublicAPI");
const DEV = !1;
var is_array = Array.isArray, index_of = Array.prototype.indexOf, array_from = Array.from, define_property = Object.defineProperty, get_descriptor = Object.getOwnPropertyDescriptor, get_descriptors = Object.getOwnPropertyDescriptors, object_prototype = Object.prototype, array_prototype = Array.prototype, get_prototype_of = Object.getPrototypeOf, is_extensible = Object.isExtensible;
const noop = /* @__PURE__ */ __name(() => {
}, "noop");
function run_all(arr) {
  for (var i = 0; i < arr.length; i++)
    arr[i]();
}
__name(run_all, "run_all");
function deferred() {
  var resolve, reject, promise = new Promise((res, rej) => {
    resolve = res, reject = rej;
  });
  return { promise, resolve, reject };
}
__name(deferred, "deferred");
const DERIVED = 2, EFFECT = 4, RENDER_EFFECT = 8, MANAGED_EFFECT = 1 << 24, BLOCK_EFFECT = 16, BRANCH_EFFECT = 32, ROOT_EFFECT = 64, BOUNDARY_EFFECT = 128, CONNECTED = 512, CLEAN = 1024, DIRTY = 2048, MAYBE_DIRTY = 4096, INERT = 8192, DESTROYED = 16384, EFFECT_RAN = 32768, EFFECT_TRANSPARENT = 65536, EAGER_EFFECT = 1 << 17, HEAD_EFFECT = 1 << 18, EFFECT_PRESERVED = 1 << 19, USER_EFFECT = 1 << 20, EFFECT_OFFSCREEN = 1 << 25, WAS_MARKED = 32768, REACTION_IS_UPDATING = 1 << 21, ASYNC = 1 << 22, ERROR_VALUE = 1 << 23, STATE_SYMBOL = /* @__PURE__ */ Symbol("$state"), LEGACY_PROPS = /* @__PURE__ */ Symbol("legacy props"), LOADING_ATTR_SYMBOL = /* @__PURE__ */ Symbol(""), STALE_REACTION = new class extends Error {
  static {
    __name(this, "StaleReactionError");
  }
  name = "StaleReactionError";
  message = "The reaction that called `getAbortSignal()` was re-run or destroyed";
}();
function equals(value) {
  return value === this.v;
}
__name(equals, "equals");
function safe_not_equal(a, b) {
  return a != a ? b == b : a !== b || a !== null && typeof a == "object" || typeof a == "function";
}
__name(safe_not_equal, "safe_not_equal");
function safe_equals(value) {
  return !safe_not_equal(value, this.v);
}
__name(safe_equals, "safe_equals");
function lifecycle_outside_component(name) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
__name(lifecycle_outside_component, "lifecycle_outside_component");
function async_derived_orphan() {
  throw new Error("https://svelte.dev/e/async_derived_orphan");
}
__name(async_derived_orphan, "async_derived_orphan");
function effect_in_teardown(rune) {
  throw new Error("https://svelte.dev/e/effect_in_teardown");
}
__name(effect_in_teardown, "effect_in_teardown");
function effect_in_unowned_derived() {
  throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
}
__name(effect_in_unowned_derived, "effect_in_unowned_derived");
function effect_orphan(rune) {
  throw new Error("https://svelte.dev/e/effect_orphan");
}
__name(effect_orphan, "effect_orphan");
function effect_update_depth_exceeded() {
  throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
}
__name(effect_update_depth_exceeded, "effect_update_depth_exceeded");
function props_invalid_value(key) {
  throw new Error("https://svelte.dev/e/props_invalid_value");
}
__name(props_invalid_value, "props_invalid_value");
function state_descriptors_fixed() {
  throw new Error("https://svelte.dev/e/state_descriptors_fixed");
}
__name(state_descriptors_fixed, "state_descriptors_fixed");
function state_prototype_fixed() {
  throw new Error("https://svelte.dev/e/state_prototype_fixed");
}
__name(state_prototype_fixed, "state_prototype_fixed");
function state_unsafe_mutation() {
  throw new Error("https://svelte.dev/e/state_unsafe_mutation");
}
__name(state_unsafe_mutation, "state_unsafe_mutation");
function svelte_boundary_reset_onerror() {
  throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror");
}
__name(svelte_boundary_reset_onerror, "svelte_boundary_reset_onerror");
let tracing_mode_flag = !1;
const EACH_ITEM_REACTIVE = 1, EACH_INDEX_REACTIVE = 2, EACH_IS_CONTROLLED = 4, EACH_IS_ANIMATED = 8, EACH_ITEM_IMMUTABLE = 16, PROPS_IS_IMMUTABLE = 1, PROPS_IS_UPDATED = 4, PROPS_IS_BINDABLE = 8, PROPS_IS_LAZY_INITIAL = 16, TEMPLATE_FRAGMENT = 1, TEMPLATE_USE_IMPORT_NODE = 2, UNINITIALIZED = /* @__PURE__ */ Symbol(), NAMESPACE_HTML = "http://www.w3.org/1999/xhtml";
let component_context = null;
function set_component_context(context) {
  component_context = context;
}
__name(set_component_context, "set_component_context");
function push(props, runes = !1, fn) {
  component_context = {
    p: component_context,
    i: !1,
    c: null,
    e: null,
    s: props,
    x: null,
    l: null
  };
}
__name(push, "push");
function pop(component) {
  var context = (
    /** @type {ComponentContext} */
    component_context
  ), effects = context.e;
  if (effects !== null) {
    context.e = null;
    for (var fn of effects)
      create_user_effect(fn);
  }
  return context.i = !0, component_context = context.p, /** @type {T} */
  {};
}
__name(pop, "pop");
function is_runes() {
  return !0;
}
__name(is_runes, "is_runes");
let micro_tasks = [];
function run_micro_tasks() {
  var tasks = micro_tasks;
  micro_tasks = [], run_all(tasks);
}
__name(run_micro_tasks, "run_micro_tasks");
function queue_micro_task(fn) {
  if (micro_tasks.length === 0 && !is_flushing_sync) {
    var tasks = micro_tasks;
    queueMicrotask(() => {
      tasks === micro_tasks && run_micro_tasks();
    });
  }
  micro_tasks.push(fn);
}
__name(queue_micro_task, "queue_micro_task");
function flush_tasks() {
  for (; micro_tasks.length > 0; )
    run_micro_tasks();
}
__name(flush_tasks, "flush_tasks");
function svelte_boundary_reset_noop() {
  console.warn("https://svelte.dev/e/svelte_boundary_reset_noop");
}
__name(svelte_boundary_reset_noop, "svelte_boundary_reset_noop");
function proxy(value) {
  if (typeof value != "object" || value === null || STATE_SYMBOL in value)
    return value;
  const prototype = get_prototype_of(value);
  if (prototype !== object_prototype && prototype !== array_prototype)
    return value;
  var sources = /* @__PURE__ */ new Map(), is_proxied_array = is_array(value), version = /* @__PURE__ */ state(0), parent_version = update_version, with_parent = /* @__PURE__ */ __name((fn) => {
    if (update_version === parent_version)
      return fn();
    var reaction = active_reaction, version2 = update_version;
    set_active_reaction(null), set_update_version(parent_version);
    var result = fn();
    return set_active_reaction(reaction), set_update_version(version2), result;
  }, "with_parent");
  return is_proxied_array && sources.set("length", /* @__PURE__ */ state(
    /** @type {any[]} */
    value.length
  )), new Proxy(
    /** @type {any} */
    value,
    {
      defineProperty(_, prop2, descriptor) {
        (!("value" in descriptor) || descriptor.configurable === !1 || descriptor.enumerable === !1 || descriptor.writable === !1) && state_descriptors_fixed();
        var s = sources.get(prop2);
        return s === void 0 ? s = with_parent(() => {
          var s2 = /* @__PURE__ */ state(descriptor.value);
          return sources.set(prop2, s2), s2;
        }) : set(s, descriptor.value, !0), !0;
      },
      deleteProperty(target, prop2) {
        var s = sources.get(prop2);
        if (s === void 0) {
          if (prop2 in target) {
            const s2 = with_parent(() => /* @__PURE__ */ state(UNINITIALIZED));
            sources.set(prop2, s2), increment(version);
          }
        } else
          set(s, UNINITIALIZED), increment(version);
        return !0;
      },
      get(target, prop2, receiver) {
        if (prop2 === STATE_SYMBOL)
          return value;
        var s = sources.get(prop2), exists = prop2 in target;
        if (s === void 0 && (!exists || get_descriptor(target, prop2)?.writable) && (s = with_parent(() => {
          var p = proxy(exists ? target[prop2] : UNINITIALIZED), s2 = /* @__PURE__ */ state(p);
          return s2;
        }), sources.set(prop2, s)), s !== void 0) {
          var v = get$1(s);
          return v === UNINITIALIZED ? void 0 : v;
        }
        return Reflect.get(target, prop2, receiver);
      },
      getOwnPropertyDescriptor(target, prop2) {
        var descriptor = Reflect.getOwnPropertyDescriptor(target, prop2);
        if (descriptor && "value" in descriptor) {
          var s = sources.get(prop2);
          s && (descriptor.value = get$1(s));
        } else if (descriptor === void 0) {
          var source2 = sources.get(prop2), value2 = source2?.v;
          if (source2 !== void 0 && value2 !== UNINITIALIZED)
            return {
              enumerable: !0,
              configurable: !0,
              value: value2,
              writable: !0
            };
        }
        return descriptor;
      },
      has(target, prop2) {
        if (prop2 === STATE_SYMBOL)
          return !0;
        var s = sources.get(prop2), has = s !== void 0 && s.v !== UNINITIALIZED || Reflect.has(target, prop2);
        if (s !== void 0 || active_effect !== null && (!has || get_descriptor(target, prop2)?.writable)) {
          s === void 0 && (s = with_parent(() => {
            var p = has ? proxy(target[prop2]) : UNINITIALIZED, s2 = /* @__PURE__ */ state(p);
            return s2;
          }), sources.set(prop2, s));
          var value2 = get$1(s);
          if (value2 === UNINITIALIZED)
            return !1;
        }
        return has;
      },
      set(target, prop2, value2, receiver) {
        var s = sources.get(prop2), has = prop2 in target;
        if (is_proxied_array && prop2 === "length")
          for (var i = value2; i < /** @type {Source<number>} */
          s.v; i += 1) {
            var other_s = sources.get(i + "");
            other_s !== void 0 ? set(other_s, UNINITIALIZED) : i in target && (other_s = with_parent(() => /* @__PURE__ */ state(UNINITIALIZED)), sources.set(i + "", other_s));
          }
        if (s === void 0)
          (!has || get_descriptor(target, prop2)?.writable) && (s = with_parent(() => /* @__PURE__ */ state(void 0)), set(s, proxy(value2)), sources.set(prop2, s));
        else {
          has = s.v !== UNINITIALIZED;
          var p = with_parent(() => proxy(value2));
          set(s, p);
        }
        var descriptor = Reflect.getOwnPropertyDescriptor(target, prop2);
        if (descriptor?.set && descriptor.set.call(receiver, value2), !has) {
          if (is_proxied_array && typeof prop2 == "string") {
            var ls = (
              /** @type {Source<number>} */
              sources.get("length")
            ), n = Number(prop2);
            Number.isInteger(n) && n >= ls.v && set(ls, n + 1);
          }
          increment(version);
        }
        return !0;
      },
      ownKeys(target) {
        get$1(version);
        var own_keys = Reflect.ownKeys(target).filter((key2) => {
          var source3 = sources.get(key2);
          return source3 === void 0 || source3.v !== UNINITIALIZED;
        });
        for (var [key, source2] of sources)
          source2.v !== UNINITIALIZED && !(key in target) && own_keys.push(key);
        return own_keys;
      },
      setPrototypeOf() {
        state_prototype_fixed();
      }
    }
  );
}
__name(proxy, "proxy");
var $window, is_firefox, first_child_getter, next_sibling_getter;
function init_operations() {
  if ($window === void 0) {
    $window = window, is_firefox = /Firefox/.test(navigator.userAgent);
    var element_prototype = Element.prototype, node_prototype = Node.prototype, text_prototype = Text.prototype;
    first_child_getter = get_descriptor(node_prototype, "firstChild").get, next_sibling_getter = get_descriptor(node_prototype, "nextSibling").get, is_extensible(element_prototype) && (element_prototype.__click = void 0, element_prototype.__className = void 0, element_prototype.__attributes = null, element_prototype.__style = void 0, element_prototype.__e = void 0), is_extensible(text_prototype) && (text_prototype.__t = void 0);
  }
}
__name(init_operations, "init_operations");
function create_text(value = "") {
  return document.createTextNode(value);
}
__name(create_text, "create_text");
// @__NO_SIDE_EFFECTS__
function get_first_child(node) {
  return (
    /** @type {TemplateNode | null} */
    first_child_getter.call(node)
  );
}
__name(get_first_child, "get_first_child");
// @__NO_SIDE_EFFECTS__
function get_next_sibling(node) {
  return (
    /** @type {TemplateNode | null} */
    next_sibling_getter.call(node)
  );
}
__name(get_next_sibling, "get_next_sibling");
function child(node, is_text) {
  return /* @__PURE__ */ get_first_child(node);
}
__name(child, "child");
function first_child(node, is_text = !1) {
  {
    var first = /* @__PURE__ */ get_first_child(node);
    return first instanceof Comment && first.data === "" ? /* @__PURE__ */ get_next_sibling(first) : first;
  }
}
__name(first_child, "first_child");
function sibling(node, count = 1, is_text = !1) {
  let next_sibling = node;
  for (; count--; )
    next_sibling = /** @type {TemplateNode} */
    /* @__PURE__ */ get_next_sibling(next_sibling);
  return next_sibling;
}
__name(sibling, "sibling");
function clear_text_content(node) {
  node.textContent = "";
}
__name(clear_text_content, "clear_text_content");
function should_defer_append() {
  return !1;
}
__name(should_defer_append, "should_defer_append");
function handle_error(error2) {
  var effect2 = active_effect;
  if (effect2 === null)
    return active_reaction.f |= ERROR_VALUE, error2;
  if ((effect2.f & EFFECT_RAN) === 0) {
    if ((effect2.f & BOUNDARY_EFFECT) === 0)
      throw error2;
    effect2.b.error(error2);
  } else
    invoke_error_boundary(error2, effect2);
}
__name(handle_error, "handle_error");
function invoke_error_boundary(error2, effect2) {
  for (; effect2 !== null; ) {
    if ((effect2.f & BOUNDARY_EFFECT) !== 0)
      try {
        effect2.b.error(error2);
        return;
      } catch (e) {
        error2 = e;
      }
    effect2 = effect2.parent;
  }
  throw error2;
}
__name(invoke_error_boundary, "invoke_error_boundary");
const STATUS_MASK = -7169;
function set_signal_status(signal, status) {
  signal.f = signal.f & STATUS_MASK | status;
}
__name(set_signal_status, "set_signal_status");
function update_derived_status(derived2) {
  (derived2.f & CONNECTED) !== 0 || derived2.deps === null ? set_signal_status(derived2, CLEAN) : set_signal_status(derived2, MAYBE_DIRTY);
}
__name(update_derived_status, "update_derived_status");
function clear_marked(deps) {
  if (deps !== null)
    for (const dep of deps)
      (dep.f & DERIVED) === 0 || (dep.f & WAS_MARKED) === 0 || (dep.f ^= WAS_MARKED, clear_marked(
        /** @type {Derived} */
        dep.deps
      ));
}
__name(clear_marked, "clear_marked");
function defer_effect(effect2, dirty_effects, maybe_dirty_effects) {
  (effect2.f & DIRTY) !== 0 ? dirty_effects.add(effect2) : (effect2.f & MAYBE_DIRTY) !== 0 && maybe_dirty_effects.add(effect2), clear_marked(effect2.deps), set_signal_status(effect2, CLEAN);
}
__name(defer_effect, "defer_effect");
const batches = /* @__PURE__ */ new Set();
let current_batch = null, previous_batch = null, batch_values = null, queued_root_effects = [], last_scheduled_effect = null, is_flushing = !1, is_flushing_sync = !1;
class Batch {
  static {
    __name(this, "Batch");
  }
  committed = !1;
  /**
   * The current values of any sources that are updated in this batch
   * They keys of this map are identical to `this.#previous`
   * @type {Map<Source, any>}
   */
  current = /* @__PURE__ */ new Map();
  /**
   * The values of any sources that are updated in this batch _before_ those updates took place.
   * They keys of this map are identical to `this.#current`
   * @type {Map<Source, any>}
   */
  previous = /* @__PURE__ */ new Map();
  /**
   * When the batch is committed (and the DOM is updated), we need to remove old branches
   * and append new ones by calling the functions added inside (if/each/key/etc) blocks
   * @type {Set<() => void>}
   */
  #commit_callbacks = /* @__PURE__ */ new Set();
  /**
   * If a fork is discarded, we need to destroy any effects that are no longer needed
   * @type {Set<(batch: Batch) => void>}
   */
  #discard_callbacks = /* @__PURE__ */ new Set();
  /**
   * The number of async effects that are currently in flight
   */
  #pending = 0;
  /**
   * The number of async effects that are currently in flight, _not_ inside a pending boundary
   */
  #blocking_pending = 0;
  /**
   * A deferred that resolves when the batch is committed, used with `settled()`
   * TODO replace with Promise.withResolvers once supported widely enough
   * @type {{ promise: Promise<void>, resolve: (value?: any) => void, reject: (reason: unknown) => void } | null}
   */
  #deferred = null;
  /**
   * Deferred effects (which run after async work has completed) that are DIRTY
   * @type {Set<Effect>}
   */
  #dirty_effects = /* @__PURE__ */ new Set();
  /**
   * Deferred effects that are MAYBE_DIRTY
   * @type {Set<Effect>}
   */
  #maybe_dirty_effects = /* @__PURE__ */ new Set();
  /**
   * A set of branches that still exist, but will be destroyed when this batch
   * is committed — we skip over these during `process`
   * @type {Set<Effect>}
   */
  skipped_effects = /* @__PURE__ */ new Set();
  is_fork = !1;
  is_deferred() {
    return this.is_fork || this.#blocking_pending > 0;
  }
  /**
   *
   * @param {Effect[]} root_effects
   */
  process(root_effects) {
    queued_root_effects = [], previous_batch = null, this.apply();
    var effects = [], render_effects = [];
    for (const root2 of root_effects)
      this.#traverse_effect_tree(root2, effects, render_effects);
    this.is_fork || this.#resolve(), this.is_deferred() ? (this.#defer_effects(render_effects), this.#defer_effects(effects)) : (previous_batch = this, current_batch = null, flush_queued_effects(render_effects), flush_queued_effects(effects), previous_batch = null, this.#deferred?.resolve()), batch_values = null;
  }
  /**
   * Traverse the effect tree, executing effects or stashing
   * them for later execution as appropriate
   * @param {Effect} root
   * @param {Effect[]} effects
   * @param {Effect[]} render_effects
   */
  #traverse_effect_tree(root2, effects, render_effects) {
    root2.f ^= CLEAN;
    for (var effect2 = root2.first, pending_boundary = null; effect2 !== null; ) {
      var flags2 = effect2.f, is_branch = (flags2 & (BRANCH_EFFECT | ROOT_EFFECT)) !== 0, is_skippable_branch = is_branch && (flags2 & CLEAN) !== 0, skip = is_skippable_branch || (flags2 & INERT) !== 0 || this.skipped_effects.has(effect2);
      if (!skip && effect2.fn !== null) {
        is_branch ? effect2.f ^= CLEAN : pending_boundary !== null && (flags2 & (EFFECT | RENDER_EFFECT | MANAGED_EFFECT)) !== 0 ? pending_boundary.b.defer_effect(effect2) : (flags2 & EFFECT) !== 0 ? effects.push(effect2) : is_dirty(effect2) && ((flags2 & BLOCK_EFFECT) !== 0 && this.#dirty_effects.add(effect2), update_effect(effect2));
        var child2 = effect2.first;
        if (child2 !== null) {
          effect2 = child2;
          continue;
        }
      }
      var parent = effect2.parent;
      for (effect2 = effect2.next; effect2 === null && parent !== null; )
        parent === pending_boundary && (pending_boundary = null), effect2 = parent.next, parent = parent.parent;
    }
  }
  /**
   * @param {Effect[]} effects
   */
  #defer_effects(effects) {
    for (var i = 0; i < effects.length; i += 1)
      defer_effect(effects[i], this.#dirty_effects, this.#maybe_dirty_effects);
  }
  /**
   * Associate a change to a given source with the current
   * batch, noting its previous and current values
   * @param {Source} source
   * @param {any} value
   */
  capture(source2, value) {
    value !== UNINITIALIZED && !this.previous.has(source2) && this.previous.set(source2, value), (source2.f & ERROR_VALUE) === 0 && (this.current.set(source2, source2.v), batch_values?.set(source2, source2.v));
  }
  activate() {
    current_batch = this, this.apply();
  }
  deactivate() {
    current_batch === this && (current_batch = null, batch_values = null);
  }
  flush() {
    if (this.activate(), queued_root_effects.length > 0) {
      if (flush_effects(), current_batch !== null && current_batch !== this)
        return;
    } else this.#pending === 0 && this.process([]);
    this.deactivate();
  }
  discard() {
    for (const fn of this.#discard_callbacks) fn(this);
    this.#discard_callbacks.clear();
  }
  #resolve() {
    if (this.#blocking_pending === 0) {
      for (const fn of this.#commit_callbacks) fn();
      this.#commit_callbacks.clear();
    }
    this.#pending === 0 && this.#commit();
  }
  #commit() {
    if (batches.size > 1) {
      this.previous.clear();
      var previous_batch_values = batch_values, is_earlier = !0;
      for (const batch of batches) {
        if (batch === this) {
          is_earlier = !1;
          continue;
        }
        const sources = [];
        for (const [source2, value] of this.current) {
          if (batch.current.has(source2))
            if (is_earlier && value !== batch.current.get(source2))
              batch.current.set(source2, value);
            else
              continue;
          sources.push(source2);
        }
        if (sources.length === 0)
          continue;
        const others = [...batch.current.keys()].filter((s) => !this.current.has(s));
        if (others.length > 0) {
          var prev_queued_root_effects = queued_root_effects;
          queued_root_effects = [];
          const marked = /* @__PURE__ */ new Set(), checked = /* @__PURE__ */ new Map();
          for (const source2 of sources)
            mark_effects(source2, others, marked, checked);
          if (queued_root_effects.length > 0) {
            current_batch = batch, batch.apply();
            for (const root2 of queued_root_effects)
              batch.#traverse_effect_tree(root2, [], []);
            batch.deactivate();
          }
          queued_root_effects = prev_queued_root_effects;
        }
      }
      current_batch = null, batch_values = previous_batch_values;
    }
    this.committed = !0, batches.delete(this);
  }
  /**
   *
   * @param {boolean} blocking
   */
  increment(blocking) {
    this.#pending += 1, blocking && (this.#blocking_pending += 1);
  }
  /**
   *
   * @param {boolean} blocking
   */
  decrement(blocking) {
    this.#pending -= 1, blocking && (this.#blocking_pending -= 1), this.revive();
  }
  revive() {
    for (const e of this.#dirty_effects)
      this.#maybe_dirty_effects.delete(e), set_signal_status(e, DIRTY), schedule_effect(e);
    for (const e of this.#maybe_dirty_effects)
      set_signal_status(e, MAYBE_DIRTY), schedule_effect(e);
    this.flush();
  }
  /** @param {() => void} fn */
  oncommit(fn) {
    this.#commit_callbacks.add(fn);
  }
  /** @param {(batch: Batch) => void} fn */
  ondiscard(fn) {
    this.#discard_callbacks.add(fn);
  }
  settled() {
    return (this.#deferred ??= deferred()).promise;
  }
  static ensure() {
    if (current_batch === null) {
      const batch = current_batch = new Batch();
      batches.add(current_batch), is_flushing_sync || Batch.enqueue(() => {
        current_batch === batch && batch.flush();
      });
    }
    return current_batch;
  }
  /** @param {() => void} task */
  static enqueue(task) {
    queue_micro_task(task);
  }
  apply() {
  }
}
function flushSync(fn) {
  var was_flushing_sync = is_flushing_sync;
  is_flushing_sync = !0;
  try {
    for (var result; ; ) {
      if (flush_tasks(), queued_root_effects.length === 0 && (current_batch?.flush(), queued_root_effects.length === 0))
        return last_scheduled_effect = null, /** @type {T} */
        result;
      flush_effects();
    }
  } finally {
    is_flushing_sync = was_flushing_sync;
  }
}
__name(flushSync, "flushSync");
function flush_effects() {
  var was_updating_effect = is_updating_effect;
  is_flushing = !0;
  var source_stacks = null;
  try {
    var flush_count = 0;
    for (set_is_updating_effect(!0); queued_root_effects.length > 0; ) {
      var batch = Batch.ensure();
      if (flush_count++ > 1e3) {
        var updates, entry;
        infinite_loop_guard();
      }
      batch.process(queued_root_effects), old_values.clear();
    }
  } finally {
    is_flushing = !1, set_is_updating_effect(was_updating_effect), last_scheduled_effect = null;
  }
}
__name(flush_effects, "flush_effects");
function infinite_loop_guard() {
  try {
    effect_update_depth_exceeded();
  } catch (error2) {
    invoke_error_boundary(error2, last_scheduled_effect);
  }
}
__name(infinite_loop_guard, "infinite_loop_guard");
let eager_block_effects = null;
function flush_queued_effects(effects) {
  var length = effects.length;
  if (length !== 0) {
    for (var i = 0; i < length; ) {
      var effect2 = effects[i++];
      if ((effect2.f & (DESTROYED | INERT)) === 0 && is_dirty(effect2) && (eager_block_effects = /* @__PURE__ */ new Set(), update_effect(effect2), effect2.deps === null && effect2.first === null && effect2.nodes === null && (effect2.teardown === null && effect2.ac === null ? unlink_effect(effect2) : effect2.fn = null), eager_block_effects?.size > 0)) {
        old_values.clear();
        for (const e of eager_block_effects) {
          if ((e.f & (DESTROYED | INERT)) !== 0) continue;
          const ordered_effects = [e];
          let ancestor = e.parent;
          for (; ancestor !== null; )
            eager_block_effects.has(ancestor) && (eager_block_effects.delete(ancestor), ordered_effects.push(ancestor)), ancestor = ancestor.parent;
          for (let j = ordered_effects.length - 1; j >= 0; j--) {
            const e2 = ordered_effects[j];
            (e2.f & (DESTROYED | INERT)) === 0 && update_effect(e2);
          }
        }
        eager_block_effects.clear();
      }
    }
    eager_block_effects = null;
  }
}
__name(flush_queued_effects, "flush_queued_effects");
function mark_effects(value, sources, marked, checked) {
  if (!marked.has(value) && (marked.add(value), value.reactions !== null))
    for (const reaction of value.reactions) {
      const flags2 = reaction.f;
      (flags2 & DERIVED) !== 0 ? mark_effects(
        /** @type {Derived} */
        reaction,
        sources,
        marked,
        checked
      ) : (flags2 & (ASYNC | BLOCK_EFFECT)) !== 0 && (flags2 & DIRTY) === 0 && depends_on(reaction, sources, checked) && (set_signal_status(reaction, DIRTY), schedule_effect(
        /** @type {Effect} */
        reaction
      ));
    }
}
__name(mark_effects, "mark_effects");
function depends_on(reaction, sources, checked) {
  const depends = checked.get(reaction);
  if (depends !== void 0) return depends;
  if (reaction.deps !== null)
    for (const dep of reaction.deps) {
      if (sources.includes(dep))
        return !0;
      if ((dep.f & DERIVED) !== 0 && depends_on(
        /** @type {Derived} */
        dep,
        sources,
        checked
      ))
        return checked.set(
          /** @type {Derived} */
          dep,
          !0
        ), !0;
    }
  return checked.set(reaction, !1), !1;
}
__name(depends_on, "depends_on");
function schedule_effect(signal) {
  for (var effect2 = last_scheduled_effect = signal; effect2.parent !== null; ) {
    effect2 = effect2.parent;
    var flags2 = effect2.f;
    if (is_flushing && effect2 === active_effect && (flags2 & BLOCK_EFFECT) !== 0 && (flags2 & HEAD_EFFECT) === 0)
      return;
    if ((flags2 & (ROOT_EFFECT | BRANCH_EFFECT)) !== 0) {
      if ((flags2 & CLEAN) === 0) return;
      effect2.f ^= CLEAN;
    }
  }
  queued_root_effects.push(effect2);
}
__name(schedule_effect, "schedule_effect");
function createSubscriber(start) {
  let subscribers = 0, version = source(0), stop;
  return () => {
    effect_tracking() && (get$1(version), render_effect(() => (subscribers === 0 && (stop = untrack(() => start(() => increment(version)))), subscribers += 1, () => {
      queue_micro_task(() => {
        subscribers -= 1, subscribers === 0 && (stop?.(), stop = void 0, increment(version));
      });
    })));
  };
}
__name(createSubscriber, "createSubscriber");
var flags = EFFECT_TRANSPARENT | EFFECT_PRESERVED | BOUNDARY_EFFECT;
function boundary(node, props, children) {
  new Boundary(node, props, children);
}
__name(boundary, "boundary");
class Boundary {
  static {
    __name(this, "Boundary");
  }
  /** @type {Boundary | null} */
  parent;
  is_pending = !1;
  /** @type {TemplateNode} */
  #anchor;
  /** @type {TemplateNode | null} */
  #hydrate_open = null;
  /** @type {BoundaryProps} */
  #props;
  /** @type {((anchor: Node) => void)} */
  #children;
  /** @type {Effect} */
  #effect;
  /** @type {Effect | null} */
  #main_effect = null;
  /** @type {Effect | null} */
  #pending_effect = null;
  /** @type {Effect | null} */
  #failed_effect = null;
  /** @type {DocumentFragment | null} */
  #offscreen_fragment = null;
  /** @type {TemplateNode | null} */
  #pending_anchor = null;
  #local_pending_count = 0;
  #pending_count = 0;
  #is_creating_fallback = !1;
  /** @type {Set<Effect>} */
  #dirty_effects = /* @__PURE__ */ new Set();
  /** @type {Set<Effect>} */
  #maybe_dirty_effects = /* @__PURE__ */ new Set();
  /**
   * A source containing the number of pending async deriveds/expressions.
   * Only created if `$effect.pending()` is used inside the boundary,
   * otherwise updating the source results in needless `Batch.ensure()`
   * calls followed by no-op flushes
   * @type {Source<number> | null}
   */
  #effect_pending = null;
  #effect_pending_subscriber = createSubscriber(() => (this.#effect_pending = source(this.#local_pending_count), () => {
    this.#effect_pending = null;
  }));
  /**
   * @param {TemplateNode} node
   * @param {BoundaryProps} props
   * @param {((anchor: Node) => void)} children
   */
  constructor(node, props, children) {
    this.#anchor = node, this.#props = props, this.#children = children, this.parent = /** @type {Effect} */
    active_effect.b, this.is_pending = !!this.#props.pending, this.#effect = block(() => {
      active_effect.b = this;
      {
        var anchor = this.#get_anchor();
        try {
          this.#main_effect = branch(() => children(anchor));
        } catch (error2) {
          this.error(error2);
        }
        this.#pending_count > 0 ? this.#show_pending_snippet() : this.is_pending = !1;
      }
      return () => {
        this.#pending_anchor?.remove();
      };
    }, flags);
  }
  #hydrate_resolved_content() {
    try {
      this.#main_effect = branch(() => this.#children(this.#anchor));
    } catch (error2) {
      this.error(error2);
    }
  }
  #hydrate_pending_content() {
    const pending = this.#props.pending;
    pending && (this.#pending_effect = branch(() => pending(this.#anchor)), Batch.enqueue(() => {
      var anchor = this.#get_anchor();
      this.#main_effect = this.#run(() => (Batch.ensure(), branch(() => this.#children(anchor)))), this.#pending_count > 0 ? this.#show_pending_snippet() : (pause_effect(
        /** @type {Effect} */
        this.#pending_effect,
        () => {
          this.#pending_effect = null;
        }
      ), this.is_pending = !1);
    }));
  }
  #get_anchor() {
    var anchor = this.#anchor;
    return this.is_pending && (this.#pending_anchor = create_text(), this.#anchor.before(this.#pending_anchor), anchor = this.#pending_anchor), anchor;
  }
  /**
   * Defer an effect inside a pending boundary until the boundary resolves
   * @param {Effect} effect
   */
  defer_effect(effect2) {
    defer_effect(effect2, this.#dirty_effects, this.#maybe_dirty_effects);
  }
  /**
   * Returns `false` if the effect exists inside a boundary whose pending snippet is shown
   * @returns {boolean}
   */
  is_rendered() {
    return !this.is_pending && (!this.parent || this.parent.is_rendered());
  }
  has_pending_snippet() {
    return !!this.#props.pending;
  }
  /**
   * @param {() => Effect | null} fn
   */
  #run(fn) {
    var previous_effect = active_effect, previous_reaction = active_reaction, previous_ctx = component_context;
    set_active_effect(this.#effect), set_active_reaction(this.#effect), set_component_context(this.#effect.ctx);
    try {
      return fn();
    } catch (e) {
      return handle_error(e), null;
    } finally {
      set_active_effect(previous_effect), set_active_reaction(previous_reaction), set_component_context(previous_ctx);
    }
  }
  #show_pending_snippet() {
    const pending = (
      /** @type {(anchor: Node) => void} */
      this.#props.pending
    );
    this.#main_effect !== null && (this.#offscreen_fragment = document.createDocumentFragment(), this.#offscreen_fragment.append(
      /** @type {TemplateNode} */
      this.#pending_anchor
    ), move_effect(this.#main_effect, this.#offscreen_fragment)), this.#pending_effect === null && (this.#pending_effect = branch(() => pending(this.#anchor)));
  }
  /**
   * Updates the pending count associated with the currently visible pending snippet,
   * if any, such that we can replace the snippet with content once work is done
   * @param {1 | -1} d
   */
  #update_pending_count(d) {
    if (!this.has_pending_snippet()) {
      this.parent && this.parent.#update_pending_count(d);
      return;
    }
    if (this.#pending_count += d, this.#pending_count === 0) {
      this.is_pending = !1;
      for (const e of this.#dirty_effects)
        set_signal_status(e, DIRTY), schedule_effect(e);
      for (const e of this.#maybe_dirty_effects)
        set_signal_status(e, MAYBE_DIRTY), schedule_effect(e);
      this.#dirty_effects.clear(), this.#maybe_dirty_effects.clear(), this.#pending_effect && pause_effect(this.#pending_effect, () => {
        this.#pending_effect = null;
      }), this.#offscreen_fragment && (this.#anchor.before(this.#offscreen_fragment), this.#offscreen_fragment = null);
    }
  }
  /**
   * Update the source that powers `$effect.pending()` inside this boundary,
   * and controls when the current `pending` snippet (if any) is removed.
   * Do not call from inside the class
   * @param {1 | -1} d
   */
  update_pending_count(d) {
    this.#update_pending_count(d), this.#local_pending_count += d, this.#effect_pending && internal_set(this.#effect_pending, this.#local_pending_count);
  }
  get_effect_pending() {
    return this.#effect_pending_subscriber(), get$1(
      /** @type {Source<number>} */
      this.#effect_pending
    );
  }
  /** @param {unknown} error */
  error(error2) {
    var onerror = this.#props.onerror;
    let failed = this.#props.failed;
    if (this.#is_creating_fallback || !onerror && !failed)
      throw error2;
    this.#main_effect && (destroy_effect(this.#main_effect), this.#main_effect = null), this.#pending_effect && (destroy_effect(this.#pending_effect), this.#pending_effect = null), this.#failed_effect && (destroy_effect(this.#failed_effect), this.#failed_effect = null);
    var did_reset = !1, calling_on_error = !1;
    const reset = /* @__PURE__ */ __name(() => {
      if (did_reset) {
        svelte_boundary_reset_noop();
        return;
      }
      did_reset = !0, calling_on_error && svelte_boundary_reset_onerror(), Batch.ensure(), this.#local_pending_count = 0, this.#failed_effect !== null && pause_effect(this.#failed_effect, () => {
        this.#failed_effect = null;
      }), this.is_pending = this.has_pending_snippet(), this.#main_effect = this.#run(() => (this.#is_creating_fallback = !1, branch(() => this.#children(this.#anchor)))), this.#pending_count > 0 ? this.#show_pending_snippet() : this.is_pending = !1;
    }, "reset");
    var previous_reaction = active_reaction;
    try {
      set_active_reaction(null), calling_on_error = !0, onerror?.(error2, reset), calling_on_error = !1;
    } catch (error3) {
      invoke_error_boundary(error3, this.#effect && this.#effect.parent);
    } finally {
      set_active_reaction(previous_reaction);
    }
    failed && queue_micro_task(() => {
      this.#failed_effect = this.#run(() => {
        Batch.ensure(), this.#is_creating_fallback = !0;
        try {
          return branch(() => {
            failed(
              this.#anchor,
              () => error2,
              () => reset
            );
          });
        } catch (error3) {
          return invoke_error_boundary(
            error3,
            /** @type {Effect} */
            this.#effect.parent
          ), null;
        } finally {
          this.#is_creating_fallback = !1;
        }
      });
    });
  }
}
function flatten(blockers, sync, async, fn) {
  const d = derived;
  if (async.length === 0 && blockers.length === 0) {
    fn(sync.map(d));
    return;
  }
  var batch = current_batch, parent = (
    /** @type {Effect} */
    active_effect
  ), restore = capture();
  function run() {
    Promise.all(async.map((expression) => /* @__PURE__ */ async_derived(expression))).then((result) => {
      restore();
      try {
        fn([...sync.map(d), ...result]);
      } catch (error2) {
        (parent.f & DESTROYED) === 0 && invoke_error_boundary(error2, parent);
      }
      batch?.deactivate(), unset_context();
    }).catch((error2) => {
      invoke_error_boundary(error2, parent);
    });
  }
  __name(run, "run"), blockers.length > 0 ? Promise.all(blockers).then(() => {
    restore();
    try {
      return run();
    } finally {
      batch?.deactivate(), unset_context();
    }
  }) : run();
}
__name(flatten, "flatten");
function capture() {
  var previous_effect = active_effect, previous_reaction = active_reaction, previous_component_context = component_context, previous_batch2 = current_batch;
  return /* @__PURE__ */ __name(function(activate_batch = !0) {
    set_active_effect(previous_effect), set_active_reaction(previous_reaction), set_component_context(previous_component_context), activate_batch && previous_batch2?.activate();
  }, "restore");
}
__name(capture, "capture");
function unset_context() {
  set_active_effect(null), set_active_reaction(null), set_component_context(null);
}
__name(unset_context, "unset_context");
// @__NO_SIDE_EFFECTS__
function derived(fn) {
  var flags2 = DERIVED | DIRTY, parent_derived = active_reaction !== null && (active_reaction.f & DERIVED) !== 0 ? (
    /** @type {Derived} */
    active_reaction
  ) : null;
  return active_effect !== null && (active_effect.f |= EFFECT_PRESERVED), {
    ctx: component_context,
    deps: null,
    effects: null,
    equals,
    f: flags2,
    fn,
    reactions: null,
    rv: 0,
    v: (
      /** @type {V} */
      UNINITIALIZED
    ),
    wv: 0,
    parent: parent_derived ?? active_effect,
    ac: null
  };
}
__name(derived, "derived");
// @__NO_SIDE_EFFECTS__
function async_derived(fn, label, location) {
  let parent = (
    /** @type {Effect | null} */
    active_effect
  );
  parent === null && async_derived_orphan();
  var boundary2 = (
    /** @type {Boundary} */
    parent.b
  ), promise = (
    /** @type {Promise<V>} */
    /** @type {unknown} */
    void 0
  ), signal = source(
    /** @type {V} */
    UNINITIALIZED
  ), should_suspend = !active_reaction, deferreds = /* @__PURE__ */ new Map();
  return async_effect(() => {
    var d = deferred();
    promise = d.promise;
    try {
      Promise.resolve(fn()).then(d.resolve, d.reject).then(() => {
        batch === current_batch && batch.committed && batch.deactivate(), unset_context();
      });
    } catch (error2) {
      d.reject(error2), unset_context();
    }
    var batch = (
      /** @type {Batch} */
      current_batch
    );
    if (should_suspend) {
      var blocking = boundary2.is_rendered();
      boundary2.update_pending_count(1), batch.increment(blocking), deferreds.get(batch)?.reject(STALE_REACTION), deferreds.delete(batch), deferreds.set(batch, d);
    }
    const handler = /* @__PURE__ */ __name((value, error2 = void 0) => {
      if (batch.activate(), error2)
        error2 !== STALE_REACTION && (signal.f |= ERROR_VALUE, internal_set(signal, error2));
      else {
        (signal.f & ERROR_VALUE) !== 0 && (signal.f ^= ERROR_VALUE), internal_set(signal, value);
        for (const [b, d2] of deferreds) {
          if (deferreds.delete(b), b === batch) break;
          d2.reject(STALE_REACTION);
        }
      }
      should_suspend && (boundary2.update_pending_count(-1), batch.decrement(blocking));
    }, "handler");
    d.promise.then(handler, (e) => handler(null, e || "unknown"));
  }), teardown(() => {
    for (const d of deferreds.values())
      d.reject(STALE_REACTION);
  }), new Promise((fulfil) => {
    function next(p) {
      function go() {
        p === promise ? fulfil(signal) : next(promise);
      }
      __name(go, "go"), p.then(go, go);
    }
    __name(next, "next"), next(promise);
  });
}
__name(async_derived, "async_derived");
// @__NO_SIDE_EFFECTS__
function user_derived(fn) {
  const d = /* @__PURE__ */ derived(fn);
  return push_reaction_value(d), d;
}
__name(user_derived, "user_derived");
// @__NO_SIDE_EFFECTS__
function derived_safe_equal(fn) {
  const signal = /* @__PURE__ */ derived(fn);
  return signal.equals = safe_equals, signal;
}
__name(derived_safe_equal, "derived_safe_equal");
function destroy_derived_effects(derived2) {
  var effects = derived2.effects;
  if (effects !== null) {
    derived2.effects = null;
    for (var i = 0; i < effects.length; i += 1)
      destroy_effect(
        /** @type {Effect} */
        effects[i]
      );
  }
}
__name(destroy_derived_effects, "destroy_derived_effects");
function get_derived_parent_effect(derived2) {
  for (var parent = derived2.parent; parent !== null; ) {
    if ((parent.f & DERIVED) === 0)
      return (parent.f & DESTROYED) === 0 ? (
        /** @type {Effect} */
        parent
      ) : null;
    parent = parent.parent;
  }
  return null;
}
__name(get_derived_parent_effect, "get_derived_parent_effect");
function execute_derived(derived2) {
  var value, prev_active_effect = active_effect;
  set_active_effect(get_derived_parent_effect(derived2));
  try {
    derived2.f &= ~WAS_MARKED, destroy_derived_effects(derived2), value = update_reaction(derived2);
  } finally {
    set_active_effect(prev_active_effect);
  }
  return value;
}
__name(execute_derived, "execute_derived");
function update_derived(derived2) {
  var value = execute_derived(derived2);
  if (!derived2.equals(value) && (derived2.wv = increment_write_version(), (!current_batch?.is_fork || derived2.deps === null) && (derived2.v = value, derived2.deps === null))) {
    set_signal_status(derived2, CLEAN);
    return;
  }
  is_destroying_effect || (batch_values !== null ? (effect_tracking() || current_batch?.is_fork) && batch_values.set(derived2, value) : update_derived_status(derived2));
}
__name(update_derived, "update_derived");
let eager_effects = /* @__PURE__ */ new Set();
const old_values = /* @__PURE__ */ new Map();
let eager_effects_deferred = !1;
function source(v, stack) {
  var signal = {
    f: 0,
    // TODO ideally we could skip this altogether, but it causes type errors
    v,
    reactions: null,
    equals,
    rv: 0,
    wv: 0
  };
  return signal;
}
__name(source, "source");
// @__NO_SIDE_EFFECTS__
function state(v, stack) {
  const s = source(v);
  return push_reaction_value(s), s;
}
__name(state, "state");
// @__NO_SIDE_EFFECTS__
function mutable_source(initial_value, immutable = !1, trackable = !0) {
  const s = source(initial_value);
  return immutable || (s.equals = safe_equals), s;
}
__name(mutable_source, "mutable_source");
function set(source2, value, should_proxy = !1) {
  active_reaction !== null && // since we are untracking the function inside `$inspect.with` we need to add this check
  // to ensure we error if state is set inside an inspect effect
  (!untracking || (active_reaction.f & EAGER_EFFECT) !== 0) && is_runes() && (active_reaction.f & (DERIVED | BLOCK_EFFECT | ASYNC | EAGER_EFFECT)) !== 0 && !current_sources?.includes(source2) && state_unsafe_mutation();
  let new_value = should_proxy ? proxy(value) : value;
  return internal_set(source2, new_value);
}
__name(set, "set");
function internal_set(source2, value) {
  if (!source2.equals(value)) {
    var old_value = source2.v;
    is_destroying_effect ? old_values.set(source2, value) : old_values.set(source2, old_value), source2.v = value;
    var batch = Batch.ensure();
    if (batch.capture(source2, old_value), (source2.f & DERIVED) !== 0) {
      const derived2 = (
        /** @type {Derived} */
        source2
      );
      (source2.f & DIRTY) !== 0 && execute_derived(derived2), update_derived_status(derived2);
    }
    source2.wv = increment_write_version(), mark_reactions(source2, DIRTY), active_effect !== null && (active_effect.f & CLEAN) !== 0 && (active_effect.f & (BRANCH_EFFECT | ROOT_EFFECT)) === 0 && (untracked_writes === null ? set_untracked_writes([source2]) : untracked_writes.push(source2)), !batch.is_fork && eager_effects.size > 0 && !eager_effects_deferred && flush_eager_effects();
  }
  return value;
}
__name(internal_set, "internal_set");
function flush_eager_effects() {
  eager_effects_deferred = !1;
  var prev_is_updating_effect = is_updating_effect;
  set_is_updating_effect(!0);
  const inspects = Array.from(eager_effects);
  try {
    for (const effect2 of inspects)
      (effect2.f & CLEAN) !== 0 && set_signal_status(effect2, MAYBE_DIRTY), is_dirty(effect2) && update_effect(effect2);
  } finally {
    set_is_updating_effect(prev_is_updating_effect);
  }
  eager_effects.clear();
}
__name(flush_eager_effects, "flush_eager_effects");
function increment(source2) {
  set(source2, source2.v + 1);
}
__name(increment, "increment");
function mark_reactions(signal, status) {
  var reactions = signal.reactions;
  if (reactions !== null)
    for (var length = reactions.length, i = 0; i < length; i++) {
      var reaction = reactions[i], flags2 = reaction.f, not_dirty = (flags2 & DIRTY) === 0;
      if (not_dirty && set_signal_status(reaction, status), (flags2 & DERIVED) !== 0) {
        var derived2 = (
          /** @type {Derived} */
          reaction
        );
        batch_values?.delete(derived2), (flags2 & WAS_MARKED) === 0 && (flags2 & CONNECTED && (reaction.f |= WAS_MARKED), mark_reactions(derived2, MAYBE_DIRTY));
      } else not_dirty && ((flags2 & BLOCK_EFFECT) !== 0 && eager_block_effects !== null && eager_block_effects.add(
        /** @type {Effect} */
        reaction
      ), schedule_effect(
        /** @type {Effect} */
        reaction
      ));
    }
}
__name(mark_reactions, "mark_reactions");
let listening_to_form_reset = !1;
function add_form_reset_listener() {
  listening_to_form_reset || (listening_to_form_reset = !0, document.addEventListener(
    "reset",
    (evt) => {
      Promise.resolve().then(() => {
        if (!evt.defaultPrevented)
          for (
            const e of
            /**@type {HTMLFormElement} */
            evt.target.elements
          )
            e.__on_r?.();
      });
    },
    // In the capture phase to guarantee we get noticed of it (no possibility of stopPropagation)
    { capture: !0 }
  ));
}
__name(add_form_reset_listener, "add_form_reset_listener");
function without_reactive_context(fn) {
  var previous_reaction = active_reaction, previous_effect = active_effect;
  set_active_reaction(null), set_active_effect(null);
  try {
    return fn();
  } finally {
    set_active_reaction(previous_reaction), set_active_effect(previous_effect);
  }
}
__name(without_reactive_context, "without_reactive_context");
function listen_to_event_and_reset_event(element, event2, handler, on_reset = handler) {
  element.addEventListener(event2, () => without_reactive_context(handler));
  const prev = element.__on_r;
  prev ? element.__on_r = () => {
    prev(), on_reset(!0);
  } : element.__on_r = () => on_reset(!0), add_form_reset_listener();
}
__name(listen_to_event_and_reset_event, "listen_to_event_and_reset_event");
let is_updating_effect = !1;
function set_is_updating_effect(value) {
  is_updating_effect = value;
}
__name(set_is_updating_effect, "set_is_updating_effect");
let is_destroying_effect = !1;
function set_is_destroying_effect(value) {
  is_destroying_effect = value;
}
__name(set_is_destroying_effect, "set_is_destroying_effect");
let active_reaction = null, untracking = !1;
function set_active_reaction(reaction) {
  active_reaction = reaction;
}
__name(set_active_reaction, "set_active_reaction");
let active_effect = null;
function set_active_effect(effect2) {
  active_effect = effect2;
}
__name(set_active_effect, "set_active_effect");
let current_sources = null;
function push_reaction_value(value) {
  active_reaction !== null && (current_sources === null ? current_sources = [value] : current_sources.push(value));
}
__name(push_reaction_value, "push_reaction_value");
let new_deps = null, skipped_deps = 0, untracked_writes = null;
function set_untracked_writes(value) {
  untracked_writes = value;
}
__name(set_untracked_writes, "set_untracked_writes");
let write_version = 1, read_version = 0, update_version = read_version;
function set_update_version(value) {
  update_version = value;
}
__name(set_update_version, "set_update_version");
function increment_write_version() {
  return ++write_version;
}
__name(increment_write_version, "increment_write_version");
function is_dirty(reaction) {
  var flags2 = reaction.f;
  if ((flags2 & DIRTY) !== 0)
    return !0;
  if (flags2 & DERIVED && (reaction.f &= ~WAS_MARKED), (flags2 & MAYBE_DIRTY) !== 0) {
    for (var dependencies = (
      /** @type {Value[]} */
      reaction.deps
    ), length = dependencies.length, i = 0; i < length; i++) {
      var dependency = dependencies[i];
      if (is_dirty(
        /** @type {Derived} */
        dependency
      ) && update_derived(
        /** @type {Derived} */
        dependency
      ), dependency.wv > reaction.wv)
        return !0;
    }
    (flags2 & CONNECTED) !== 0 && // During time traveling we don't want to reset the status so that
    // traversal of the graph in the other batches still happens
    batch_values === null && set_signal_status(reaction, CLEAN);
  }
  return !1;
}
__name(is_dirty, "is_dirty");
function schedule_possible_effect_self_invalidation(signal, effect2, root2 = !0) {
  var reactions = signal.reactions;
  if (reactions !== null && !current_sources?.includes(signal))
    for (var i = 0; i < reactions.length; i++) {
      var reaction = reactions[i];
      (reaction.f & DERIVED) !== 0 ? schedule_possible_effect_self_invalidation(
        /** @type {Derived} */
        reaction,
        effect2,
        !1
      ) : effect2 === reaction && (root2 ? set_signal_status(reaction, DIRTY) : (reaction.f & CLEAN) !== 0 && set_signal_status(reaction, MAYBE_DIRTY), schedule_effect(
        /** @type {Effect} */
        reaction
      ));
    }
}
__name(schedule_possible_effect_self_invalidation, "schedule_possible_effect_self_invalidation");
function update_reaction(reaction) {
  var previous_deps = new_deps, previous_skipped_deps = skipped_deps, previous_untracked_writes = untracked_writes, previous_reaction = active_reaction, previous_sources = current_sources, previous_component_context = component_context, previous_untracking = untracking, previous_update_version = update_version, flags2 = reaction.f;
  new_deps = /** @type {null | Value[]} */
  null, skipped_deps = 0, untracked_writes = null, active_reaction = (flags2 & (BRANCH_EFFECT | ROOT_EFFECT)) === 0 ? reaction : null, current_sources = null, set_component_context(reaction.ctx), untracking = !1, update_version = ++read_version, reaction.ac !== null && (without_reactive_context(() => {
    reaction.ac.abort(STALE_REACTION);
  }), reaction.ac = null);
  try {
    reaction.f |= REACTION_IS_UPDATING;
    var fn = (
      /** @type {Function} */
      reaction.fn
    ), result = fn(), deps = reaction.deps;
    if (new_deps !== null) {
      var i;
      if (remove_reactions(reaction, skipped_deps), deps !== null && skipped_deps > 0)
        for (deps.length = skipped_deps + new_deps.length, i = 0; i < new_deps.length; i++)
          deps[skipped_deps + i] = new_deps[i];
      else
        reaction.deps = deps = new_deps;
      if (effect_tracking() && (reaction.f & CONNECTED) !== 0)
        for (i = skipped_deps; i < deps.length; i++)
          (deps[i].reactions ??= []).push(reaction);
    } else deps !== null && skipped_deps < deps.length && (remove_reactions(reaction, skipped_deps), deps.length = skipped_deps);
    if (is_runes() && untracked_writes !== null && !untracking && deps !== null && (reaction.f & (DERIVED | MAYBE_DIRTY | DIRTY)) === 0)
      for (i = 0; i < /** @type {Source[]} */
      untracked_writes.length; i++)
        schedule_possible_effect_self_invalidation(
          untracked_writes[i],
          /** @type {Effect} */
          reaction
        );
    return previous_reaction !== null && previous_reaction !== reaction && (read_version++, untracked_writes !== null && (previous_untracked_writes === null ? previous_untracked_writes = untracked_writes : previous_untracked_writes.push(.../** @type {Source[]} */
    untracked_writes))), (reaction.f & ERROR_VALUE) !== 0 && (reaction.f ^= ERROR_VALUE), result;
  } catch (error2) {
    return handle_error(error2);
  } finally {
    reaction.f ^= REACTION_IS_UPDATING, new_deps = previous_deps, skipped_deps = previous_skipped_deps, untracked_writes = previous_untracked_writes, active_reaction = previous_reaction, current_sources = previous_sources, set_component_context(previous_component_context), untracking = previous_untracking, update_version = previous_update_version;
  }
}
__name(update_reaction, "update_reaction");
function remove_reaction(signal, dependency) {
  let reactions = dependency.reactions;
  if (reactions !== null) {
    var index2 = index_of.call(reactions, signal);
    if (index2 !== -1) {
      var new_length = reactions.length - 1;
      new_length === 0 ? reactions = dependency.reactions = null : (reactions[index2] = reactions[new_length], reactions.pop());
    }
  }
  if (reactions === null && (dependency.f & DERIVED) !== 0 && // Destroying a child effect while updating a parent effect can cause a dependency to appear
  // to be unused, when in fact it is used by the currently-updating parent. Checking `new_deps`
  // allows us to skip the expensive work of disconnecting and immediately reconnecting it
  (new_deps === null || !new_deps.includes(dependency))) {
    var derived2 = (
      /** @type {Derived} */
      dependency
    );
    (derived2.f & CONNECTED) !== 0 && (derived2.f ^= CONNECTED, derived2.f &= ~WAS_MARKED), update_derived_status(derived2), destroy_derived_effects(derived2), remove_reactions(derived2, 0);
  }
}
__name(remove_reaction, "remove_reaction");
function remove_reactions(signal, start_index) {
  var dependencies = signal.deps;
  if (dependencies !== null)
    for (var i = start_index; i < dependencies.length; i++)
      remove_reaction(signal, dependencies[i]);
}
__name(remove_reactions, "remove_reactions");
function update_effect(effect2) {
  var flags2 = effect2.f;
  if ((flags2 & DESTROYED) === 0) {
    set_signal_status(effect2, CLEAN);
    var previous_effect = active_effect, was_updating_effect = is_updating_effect;
    active_effect = effect2, is_updating_effect = !0;
    try {
      (flags2 & (BLOCK_EFFECT | MANAGED_EFFECT)) !== 0 ? destroy_block_effect_children(effect2) : destroy_effect_children(effect2), execute_effect_teardown(effect2);
      var teardown2 = update_reaction(effect2);
      effect2.teardown = typeof teardown2 == "function" ? teardown2 : null, effect2.wv = write_version;
      var dep;
      DEV && tracing_mode_flag && (effect2.f & DIRTY) !== 0 && effect2.deps;
    } finally {
      is_updating_effect = was_updating_effect, active_effect = previous_effect;
    }
  }
}
__name(update_effect, "update_effect");
async function tick() {
  await Promise.resolve(), flushSync();
}
__name(tick, "tick");
function get$1(signal) {
  var flags2 = signal.f, is_derived = (flags2 & DERIVED) !== 0;
  if (active_reaction !== null && !untracking) {
    var destroyed = active_effect !== null && (active_effect.f & DESTROYED) !== 0;
    if (!destroyed && !current_sources?.includes(signal)) {
      var deps = active_reaction.deps;
      if ((active_reaction.f & REACTION_IS_UPDATING) !== 0)
        signal.rv < read_version && (signal.rv = read_version, new_deps === null && deps !== null && deps[skipped_deps] === signal ? skipped_deps++ : new_deps === null ? new_deps = [signal] : new_deps.includes(signal) || new_deps.push(signal));
      else {
        (active_reaction.deps ??= []).push(signal);
        var reactions = signal.reactions;
        reactions === null ? signal.reactions = [active_reaction] : reactions.includes(active_reaction) || reactions.push(active_reaction);
      }
    }
  }
  if (is_destroying_effect && old_values.has(signal))
    return old_values.get(signal);
  if (is_derived) {
    var derived2 = (
      /** @type {Derived} */
      signal
    );
    if (is_destroying_effect) {
      var value = derived2.v;
      return ((derived2.f & CLEAN) === 0 && derived2.reactions !== null || depends_on_old_values(derived2)) && (value = execute_derived(derived2)), old_values.set(derived2, value), value;
    }
    var should_connect = (derived2.f & CONNECTED) === 0 && !untracking && active_reaction !== null && (is_updating_effect || (active_reaction.f & CONNECTED) !== 0), is_new = derived2.deps === null;
    is_dirty(derived2) && (should_connect && (derived2.f |= CONNECTED), update_derived(derived2)), should_connect && !is_new && reconnect(derived2);
  }
  if (batch_values?.has(signal))
    return batch_values.get(signal);
  if ((signal.f & ERROR_VALUE) !== 0)
    throw signal.v;
  return signal.v;
}
__name(get$1, "get$1");
function reconnect(derived2) {
  if (derived2.deps !== null) {
    derived2.f |= CONNECTED;
    for (const dep of derived2.deps)
      (dep.reactions ??= []).push(derived2), (dep.f & DERIVED) !== 0 && (dep.f & CONNECTED) === 0 && reconnect(
        /** @type {Derived} */
        dep
      );
  }
}
__name(reconnect, "reconnect");
function depends_on_old_values(derived2) {
  if (derived2.v === UNINITIALIZED) return !0;
  if (derived2.deps === null) return !1;
  for (const dep of derived2.deps)
    if (old_values.has(dep) || (dep.f & DERIVED) !== 0 && depends_on_old_values(
      /** @type {Derived} */
      dep
    ))
      return !0;
  return !1;
}
__name(depends_on_old_values, "depends_on_old_values");
function untrack(fn) {
  var previous_untracking = untracking;
  try {
    return untracking = !0, fn();
  } finally {
    untracking = previous_untracking;
  }
}
__name(untrack, "untrack");
function validate_effect(rune) {
  active_effect === null && (active_reaction === null && effect_orphan(), effect_in_unowned_derived()), is_destroying_effect && effect_in_teardown();
}
__name(validate_effect, "validate_effect");
function push_effect(effect2, parent_effect) {
  var parent_last = parent_effect.last;
  parent_last === null ? parent_effect.last = parent_effect.first = effect2 : (parent_last.next = effect2, effect2.prev = parent_last, parent_effect.last = effect2);
}
__name(push_effect, "push_effect");
function create_effect(type, fn, sync) {
  var parent = active_effect;
  parent !== null && (parent.f & INERT) !== 0 && (type |= INERT);
  var effect2 = {
    ctx: component_context,
    deps: null,
    nodes: null,
    f: type | DIRTY | CONNECTED,
    first: null,
    fn,
    last: null,
    next: null,
    parent,
    b: parent && parent.b,
    prev: null,
    teardown: null,
    wv: 0,
    ac: null
  };
  if (sync)
    try {
      update_effect(effect2), effect2.f |= EFFECT_RAN;
    } catch (e2) {
      throw destroy_effect(effect2), e2;
    }
  else fn !== null && schedule_effect(effect2);
  var e = effect2;
  if (sync && e.deps === null && e.teardown === null && e.nodes === null && e.first === e.last && // either `null`, or a singular child
  (e.f & EFFECT_PRESERVED) === 0 && (e = e.first, (type & BLOCK_EFFECT) !== 0 && (type & EFFECT_TRANSPARENT) !== 0 && e !== null && (e.f |= EFFECT_TRANSPARENT)), e !== null && (e.parent = parent, parent !== null && push_effect(e, parent), active_reaction !== null && (active_reaction.f & DERIVED) !== 0 && (type & ROOT_EFFECT) === 0)) {
    var derived2 = (
      /** @type {Derived} */
      active_reaction
    );
    (derived2.effects ??= []).push(e);
  }
  return effect2;
}
__name(create_effect, "create_effect");
function effect_tracking() {
  return active_reaction !== null && !untracking;
}
__name(effect_tracking, "effect_tracking");
function teardown(fn) {
  const effect2 = create_effect(RENDER_EFFECT, null, !1);
  return set_signal_status(effect2, CLEAN), effect2.teardown = fn, effect2;
}
__name(teardown, "teardown");
function user_effect(fn) {
  validate_effect();
  var flags2 = (
    /** @type {Effect} */
    active_effect.f
  ), defer = !active_reaction && (flags2 & BRANCH_EFFECT) !== 0 && (flags2 & EFFECT_RAN) === 0;
  if (defer) {
    var context = (
      /** @type {ComponentContext} */
      component_context
    );
    (context.e ??= []).push(fn);
  } else
    return create_user_effect(fn);
}
__name(user_effect, "user_effect");
function create_user_effect(fn) {
  return create_effect(EFFECT | USER_EFFECT, fn, !1);
}
__name(create_user_effect, "create_user_effect");
function component_root(fn) {
  Batch.ensure();
  const effect2 = create_effect(ROOT_EFFECT | EFFECT_PRESERVED, fn, !0);
  return (options = {}) => new Promise((fulfil) => {
    options.outro ? pause_effect(effect2, () => {
      destroy_effect(effect2), fulfil(void 0);
    }) : (destroy_effect(effect2), fulfil(void 0));
  });
}
__name(component_root, "component_root");
function effect(fn) {
  return create_effect(EFFECT, fn, !1);
}
__name(effect, "effect");
function async_effect(fn) {
  return create_effect(ASYNC | EFFECT_PRESERVED, fn, !0);
}
__name(async_effect, "async_effect");
function render_effect(fn, flags2 = 0) {
  return create_effect(RENDER_EFFECT | flags2, fn, !0);
}
__name(render_effect, "render_effect");
function template_effect(fn, sync = [], async = [], blockers = []) {
  flatten(blockers, sync, async, (values) => {
    create_effect(RENDER_EFFECT, () => fn(...values.map(get$1)), !0);
  });
}
__name(template_effect, "template_effect");
function block(fn, flags2 = 0) {
  var effect2 = create_effect(BLOCK_EFFECT | flags2, fn, !0);
  return effect2;
}
__name(block, "block");
function branch(fn) {
  return create_effect(BRANCH_EFFECT | EFFECT_PRESERVED, fn, !0);
}
__name(branch, "branch");
function execute_effect_teardown(effect2) {
  var teardown2 = effect2.teardown;
  if (teardown2 !== null) {
    const previously_destroying_effect = is_destroying_effect, previous_reaction = active_reaction;
    set_is_destroying_effect(!0), set_active_reaction(null);
    try {
      teardown2.call(null);
    } finally {
      set_is_destroying_effect(previously_destroying_effect), set_active_reaction(previous_reaction);
    }
  }
}
__name(execute_effect_teardown, "execute_effect_teardown");
function destroy_effect_children(signal, remove_dom = !1) {
  var effect2 = signal.first;
  for (signal.first = signal.last = null; effect2 !== null; ) {
    const controller = effect2.ac;
    controller !== null && without_reactive_context(() => {
      controller.abort(STALE_REACTION);
    });
    var next = effect2.next;
    (effect2.f & ROOT_EFFECT) !== 0 ? effect2.parent = null : destroy_effect(effect2, remove_dom), effect2 = next;
  }
}
__name(destroy_effect_children, "destroy_effect_children");
function destroy_block_effect_children(signal) {
  for (var effect2 = signal.first; effect2 !== null; ) {
    var next = effect2.next;
    (effect2.f & BRANCH_EFFECT) === 0 && destroy_effect(effect2), effect2 = next;
  }
}
__name(destroy_block_effect_children, "destroy_block_effect_children");
function destroy_effect(effect2, remove_dom = !0) {
  var removed = !1;
  (remove_dom || (effect2.f & HEAD_EFFECT) !== 0) && effect2.nodes !== null && effect2.nodes.end !== null && (remove_effect_dom(
    effect2.nodes.start,
    /** @type {TemplateNode} */
    effect2.nodes.end
  ), removed = !0), destroy_effect_children(effect2, remove_dom && !removed), remove_reactions(effect2, 0), set_signal_status(effect2, DESTROYED);
  var transitions = effect2.nodes && effect2.nodes.t;
  if (transitions !== null)
    for (const transition of transitions)
      transition.stop();
  execute_effect_teardown(effect2);
  var parent = effect2.parent;
  parent !== null && parent.first !== null && unlink_effect(effect2), effect2.next = effect2.prev = effect2.teardown = effect2.ctx = effect2.deps = effect2.fn = effect2.nodes = effect2.ac = null;
}
__name(destroy_effect, "destroy_effect");
function remove_effect_dom(node, end) {
  for (; node !== null; ) {
    var next = node === end ? null : /* @__PURE__ */ get_next_sibling(node);
    node.remove(), node = next;
  }
}
__name(remove_effect_dom, "remove_effect_dom");
function unlink_effect(effect2) {
  var parent = effect2.parent, prev = effect2.prev, next = effect2.next;
  prev !== null && (prev.next = next), next !== null && (next.prev = prev), parent !== null && (parent.first === effect2 && (parent.first = next), parent.last === effect2 && (parent.last = prev));
}
__name(unlink_effect, "unlink_effect");
function pause_effect(effect2, callback, destroy = !0) {
  var transitions = [];
  pause_children(effect2, transitions, !0);
  var fn = /* @__PURE__ */ __name(() => {
    destroy && destroy_effect(effect2), callback && callback();
  }, "fn"), remaining = transitions.length;
  if (remaining > 0) {
    var check = /* @__PURE__ */ __name(() => --remaining || fn(), "check");
    for (var transition of transitions)
      transition.out(check);
  } else
    fn();
}
__name(pause_effect, "pause_effect");
function pause_children(effect2, transitions, local) {
  if ((effect2.f & INERT) === 0) {
    effect2.f ^= INERT;
    var t = effect2.nodes && effect2.nodes.t;
    if (t !== null)
      for (const transition of t)
        (transition.is_global || local) && transitions.push(transition);
    for (var child2 = effect2.first; child2 !== null; ) {
      var sibling2 = child2.next, transparent = (child2.f & EFFECT_TRANSPARENT) !== 0 || // If this is a branch effect without a block effect parent,
      // it means the parent block effect was pruned. In that case,
      // transparency information was transferred to the branch effect.
      (child2.f & BRANCH_EFFECT) !== 0 && (effect2.f & BLOCK_EFFECT) !== 0;
      pause_children(child2, transitions, transparent ? local : !1), child2 = sibling2;
    }
  }
}
__name(pause_children, "pause_children");
function resume_effect(effect2) {
  resume_children(effect2, !0);
}
__name(resume_effect, "resume_effect");
function resume_children(effect2, local) {
  if ((effect2.f & INERT) !== 0) {
    effect2.f ^= INERT, (effect2.f & CLEAN) === 0 && (set_signal_status(effect2, DIRTY), schedule_effect(effect2));
    for (var child2 = effect2.first; child2 !== null; ) {
      var sibling2 = child2.next, transparent = (child2.f & EFFECT_TRANSPARENT) !== 0 || (child2.f & BRANCH_EFFECT) !== 0;
      resume_children(child2, transparent ? local : !1), child2 = sibling2;
    }
    var t = effect2.nodes && effect2.nodes.t;
    if (t !== null)
      for (const transition of t)
        (transition.is_global || local) && transition.in();
  }
}
__name(resume_children, "resume_children");
function move_effect(effect2, fragment) {
  if (effect2.nodes)
    for (var node = effect2.nodes.start, end = effect2.nodes.end; node !== null; ) {
      var next = node === end ? null : /* @__PURE__ */ get_next_sibling(node);
      fragment.append(node), node = next;
    }
}
__name(move_effect, "move_effect");
const PASSIVE_EVENTS = ["touchstart", "touchmove"];
function is_passive_event(name) {
  return PASSIVE_EVENTS.includes(name);
}
__name(is_passive_event, "is_passive_event");
const all_registered_events = /* @__PURE__ */ new Set(), root_event_handles = /* @__PURE__ */ new Set();
function create_event(event_name, dom, handler, options = {}) {
  function target_handler(event2) {
    if (options.capture || handle_event_propagation.call(dom, event2), !event2.cancelBubble)
      return without_reactive_context(() => handler?.call(this, event2));
  }
  return __name(target_handler, "target_handler"), event_name.startsWith("pointer") || event_name.startsWith("touch") || event_name === "wheel" ? queue_micro_task(() => {
    dom.addEventListener(event_name, target_handler, options);
  }) : dom.addEventListener(event_name, target_handler, options), target_handler;
}
__name(create_event, "create_event");
function event(event_name, dom, handler, capture2, passive) {
  var options = { capture: capture2, passive }, target_handler = create_event(event_name, dom, handler, options);
  (dom === document.body || // @ts-ignore
  dom === window || // @ts-ignore
  dom === document || // Firefox has quirky behavior, it can happen that we still get "canplay" events when the element is already removed
  dom instanceof HTMLMediaElement) && teardown(() => {
    dom.removeEventListener(event_name, target_handler, options);
  });
}
__name(event, "event");
function delegate(events) {
  for (var i = 0; i < events.length; i++)
    all_registered_events.add(events[i]);
  for (var fn of root_event_handles)
    fn(events);
}
__name(delegate, "delegate");
let last_propagated_event = null;
function handle_event_propagation(event2) {
  var handler_element = this, owner_document = (
    /** @type {Node} */
    handler_element.ownerDocument
  ), event_name = event2.type, path = event2.composedPath?.() || [], current_target = (
    /** @type {null | Element} */
    path[0] || event2.target
  );
  last_propagated_event = event2;
  var path_idx = 0, handled_at = last_propagated_event === event2 && event2.__root;
  if (handled_at) {
    var at_idx = path.indexOf(handled_at);
    if (at_idx !== -1 && (handler_element === document || handler_element === /** @type {any} */
    window)) {
      event2.__root = handler_element;
      return;
    }
    var handler_idx = path.indexOf(handler_element);
    if (handler_idx === -1)
      return;
    at_idx <= handler_idx && (path_idx = at_idx);
  }
  if (current_target = /** @type {Element} */
  path[path_idx] || event2.target, current_target !== handler_element) {
    define_property(event2, "currentTarget", {
      configurable: !0,
      get() {
        return current_target || owner_document;
      }
    });
    var previous_reaction = active_reaction, previous_effect = active_effect;
    set_active_reaction(null), set_active_effect(null);
    try {
      for (var throw_error, other_errors = []; current_target !== null; ) {
        var parent_element = current_target.assignedSlot || current_target.parentNode || /** @type {any} */
        current_target.host || null;
        try {
          var delegated = current_target["__" + event_name];
          delegated != null && (!/** @type {any} */
          current_target.disabled || // DOM could've been updated already by the time this is reached, so we check this as well
          // -> the target could not have been disabled because it emits the event in the first place
          event2.target === current_target) && delegated.call(current_target, event2);
        } catch (error2) {
          throw_error ? other_errors.push(error2) : throw_error = error2;
        }
        if (event2.cancelBubble || parent_element === handler_element || parent_element === null)
          break;
        current_target = parent_element;
      }
      if (throw_error) {
        for (let error2 of other_errors)
          queueMicrotask(() => {
            throw error2;
          });
        throw throw_error;
      }
    } finally {
      event2.__root = handler_element, delete event2.currentTarget, set_active_reaction(previous_reaction), set_active_effect(previous_effect);
    }
  }
}
__name(handle_event_propagation, "handle_event_propagation");
function create_fragment_from_html(html2) {
  var elem = document.createElement("template");
  return elem.innerHTML = html2.replaceAll("<!>", "<!---->"), elem.content;
}
__name(create_fragment_from_html, "create_fragment_from_html");
function assign_nodes(start, end) {
  var effect2 = (
    /** @type {Effect} */
    active_effect
  );
  effect2.nodes === null && (effect2.nodes = { start, end, a: null, t: null });
}
__name(assign_nodes, "assign_nodes");
// @__NO_SIDE_EFFECTS__
function from_html(content, flags2) {
  var is_fragment = (flags2 & TEMPLATE_FRAGMENT) !== 0, use_import_node = (flags2 & TEMPLATE_USE_IMPORT_NODE) !== 0, node, has_start = !content.startsWith("<!>");
  return () => {
    node === void 0 && (node = create_fragment_from_html(has_start ? content : "<!>" + content), is_fragment || (node = /** @type {TemplateNode} */
    /* @__PURE__ */ get_first_child(node)));
    var clone = (
      /** @type {TemplateNode} */
      use_import_node || is_firefox ? document.importNode(node, !0) : node.cloneNode(!0)
    );
    if (is_fragment) {
      var start = (
        /** @type {TemplateNode} */
        /* @__PURE__ */ get_first_child(clone)
      ), end = (
        /** @type {TemplateNode} */
        clone.lastChild
      );
      assign_nodes(start, end);
    } else
      assign_nodes(clone, clone);
    return clone;
  };
}
__name(from_html, "from_html");
function comment() {
  var frag = document.createDocumentFragment(), start = document.createComment(""), anchor = create_text();
  return frag.append(start, anchor), assign_nodes(start, anchor), frag;
}
__name(comment, "comment");
function append(anchor, dom) {
  anchor !== null && anchor.before(
    /** @type {Node} */
    dom
  );
}
__name(append, "append");
function set_text(text, value) {
  var str = value == null ? "" : typeof value == "object" ? value + "" : value;
  str !== (text.__t ??= text.nodeValue) && (text.__t = str, text.nodeValue = str + "");
}
__name(set_text, "set_text");
function mount(component, options) {
  return _mount(component, options);
}
__name(mount, "mount");
const document_listeners = /* @__PURE__ */ new Map();
function _mount(Component, { target, anchor, props = {}, events, context, intro = !0 }) {
  init_operations();
  var registered_events = /* @__PURE__ */ new Set(), event_handle = /* @__PURE__ */ __name((events2) => {
    for (var i = 0; i < events2.length; i++) {
      var event_name = events2[i];
      if (!registered_events.has(event_name)) {
        registered_events.add(event_name);
        var passive = is_passive_event(event_name);
        target.addEventListener(event_name, handle_event_propagation, { passive });
        var n = document_listeners.get(event_name);
        n === void 0 ? (document.addEventListener(event_name, handle_event_propagation, { passive }), document_listeners.set(event_name, 1)) : document_listeners.set(event_name, n + 1);
      }
    }
  }, "event_handle");
  event_handle(array_from(all_registered_events)), root_event_handles.add(event_handle);
  var component = void 0, unmount2 = component_root(() => {
    var anchor_node = anchor ?? target.appendChild(create_text());
    return boundary(
      /** @type {TemplateNode} */
      anchor_node,
      {
        pending: /* @__PURE__ */ __name(() => {
        }, "pending")
      },
      (anchor_node2) => {
        if (context) {
          push({});
          var ctx = (
            /** @type {ComponentContext} */
            component_context
          );
          ctx.c = context;
        }
        events && (props.$$events = events), component = Component(anchor_node2, props) || {}, context && pop();
      }
    ), () => {
      for (var event_name of registered_events) {
        target.removeEventListener(event_name, handle_event_propagation);
        var n = (
          /** @type {number} */
          document_listeners.get(event_name)
        );
        --n === 0 ? (document.removeEventListener(event_name, handle_event_propagation), document_listeners.delete(event_name)) : document_listeners.set(event_name, n);
      }
      root_event_handles.delete(event_handle), anchor_node !== anchor && anchor_node.parentNode?.removeChild(anchor_node);
    };
  });
  return mounted_components.set(component, unmount2), component;
}
__name(_mount, "_mount");
let mounted_components = /* @__PURE__ */ new WeakMap();
function unmount(component, options) {
  const fn = mounted_components.get(component);
  return fn ? (mounted_components.delete(component), fn(options)) : Promise.resolve();
}
__name(unmount, "unmount");
class BranchManager {
  static {
    __name(this, "BranchManager");
  }
  /** @type {TemplateNode} */
  anchor;
  /** @type {Map<Batch, Key>} */
  #batches = /* @__PURE__ */ new Map();
  /**
   * Map of keys to effects that are currently rendered in the DOM.
   * These effects are visible and actively part of the document tree.
   * Example:
   * ```
   * {#if condition}
   * 	foo
   * {:else}
   * 	bar
   * {/if}
   * ```
   * Can result in the entries `true->Effect` and `false->Effect`
   * @type {Map<Key, Effect>}
   */
  #onscreen = /* @__PURE__ */ new Map();
  /**
   * Similar to #onscreen with respect to the keys, but contains branches that are not yet
   * in the DOM, because their insertion is deferred.
   * @type {Map<Key, Branch>}
   */
  #offscreen = /* @__PURE__ */ new Map();
  /**
   * Keys of effects that are currently outroing
   * @type {Set<Key>}
   */
  #outroing = /* @__PURE__ */ new Set();
  /**
   * Whether to pause (i.e. outro) on change, or destroy immediately.
   * This is necessary for `<svelte:element>`
   */
  #transition = !0;
  /**
   * @param {TemplateNode} anchor
   * @param {boolean} transition
   */
  constructor(anchor, transition = !0) {
    this.anchor = anchor, this.#transition = transition;
  }
  #commit = /* @__PURE__ */ __name(() => {
    var batch = (
      /** @type {Batch} */
      current_batch
    );
    if (this.#batches.has(batch)) {
      var key = (
        /** @type {Key} */
        this.#batches.get(batch)
      ), onscreen = this.#onscreen.get(key);
      if (onscreen)
        resume_effect(onscreen), this.#outroing.delete(key);
      else {
        var offscreen = this.#offscreen.get(key);
        offscreen && (this.#onscreen.set(key, offscreen.effect), this.#offscreen.delete(key), offscreen.fragment.lastChild.remove(), this.anchor.before(offscreen.fragment), onscreen = offscreen.effect);
      }
      for (const [b, k] of this.#batches) {
        if (this.#batches.delete(b), b === batch)
          break;
        const offscreen2 = this.#offscreen.get(k);
        offscreen2 && (destroy_effect(offscreen2.effect), this.#offscreen.delete(k));
      }
      for (const [k, effect2] of this.#onscreen) {
        if (k === key || this.#outroing.has(k)) continue;
        const on_destroy = /* @__PURE__ */ __name(() => {
          if (Array.from(this.#batches.values()).includes(k)) {
            var fragment = document.createDocumentFragment();
            move_effect(effect2, fragment), fragment.append(create_text()), this.#offscreen.set(k, { effect: effect2, fragment });
          } else
            destroy_effect(effect2);
          this.#outroing.delete(k), this.#onscreen.delete(k);
        }, "on_destroy");
        this.#transition || !onscreen ? (this.#outroing.add(k), pause_effect(effect2, on_destroy, !1)) : on_destroy();
      }
    }
  }, "#commit");
  /**
   * @param {Batch} batch
   */
  #discard = /* @__PURE__ */ __name((batch) => {
    this.#batches.delete(batch);
    const keys = Array.from(this.#batches.values());
    for (const [k, branch2] of this.#offscreen)
      keys.includes(k) || (destroy_effect(branch2.effect), this.#offscreen.delete(k));
  }, "#discard");
  /**
   *
   * @param {any} key
   * @param {null | ((target: TemplateNode) => void)} fn
   */
  ensure(key, fn) {
    var batch = (
      /** @type {Batch} */
      current_batch
    ), defer = should_defer_append();
    if (fn && !this.#onscreen.has(key) && !this.#offscreen.has(key))
      if (defer) {
        var fragment = document.createDocumentFragment(), target = create_text();
        fragment.append(target), this.#offscreen.set(key, {
          effect: branch(() => fn(target)),
          fragment
        });
      } else
        this.#onscreen.set(
          key,
          branch(() => fn(this.anchor))
        );
    if (this.#batches.set(batch, key), defer) {
      for (const [k, effect2] of this.#onscreen)
        k === key ? batch.skipped_effects.delete(effect2) : batch.skipped_effects.add(effect2);
      for (const [k, branch2] of this.#offscreen)
        k === key ? batch.skipped_effects.delete(branch2.effect) : batch.skipped_effects.add(branch2.effect);
      batch.oncommit(this.#commit), batch.ondiscard(this.#discard);
    } else
      this.#commit();
  }
}
function if_block(node, fn, elseif = !1) {
  var branches = new BranchManager(node), flags2 = elseif ? EFFECT_TRANSPARENT : 0;
  function update_branch(condition, fn2) {
    branches.ensure(condition, fn2);
  }
  __name(update_branch, "update_branch"), block(() => {
    var has_branch = !1;
    fn((fn2, flag = !0) => {
      has_branch = !0, update_branch(flag, fn2);
    }), has_branch || update_branch(!1, null);
  }, flags2);
}
__name(if_block, "if_block");
function index(_, i) {
  return i;
}
__name(index, "index");
function pause_effects(state2, to_destroy, controlled_anchor) {
  for (var transitions = [], length = to_destroy.length, group, remaining = to_destroy.length, i = 0; i < length; i++) {
    let effect2 = to_destroy[i];
    pause_effect(
      effect2,
      () => {
        if (group) {
          if (group.pending.delete(effect2), group.done.add(effect2), group.pending.size === 0) {
            var groups = (
              /** @type {Set<EachOutroGroup>} */
              state2.outrogroups
            );
            destroy_effects(array_from(group.done)), groups.delete(group), groups.size === 0 && (state2.outrogroups = null);
          }
        } else
          remaining -= 1;
      },
      !1
    );
  }
  if (remaining === 0) {
    var fast_path = transitions.length === 0 && controlled_anchor !== null;
    if (fast_path) {
      var anchor = (
        /** @type {Element} */
        controlled_anchor
      ), parent_node = (
        /** @type {Element} */
        anchor.parentNode
      );
      clear_text_content(parent_node), parent_node.append(anchor), state2.items.clear();
    }
    destroy_effects(to_destroy, !fast_path);
  } else
    group = {
      pending: new Set(to_destroy),
      done: /* @__PURE__ */ new Set()
    }, (state2.outrogroups ??= /* @__PURE__ */ new Set()).add(group);
}
__name(pause_effects, "pause_effects");
function destroy_effects(to_destroy, remove_dom = !0) {
  for (var i = 0; i < to_destroy.length; i++)
    destroy_effect(to_destroy[i], remove_dom);
}
__name(destroy_effects, "destroy_effects");
var offscreen_anchor;
function each(node, flags2, get_collection, get_key, render_fn, fallback_fn = null) {
  var anchor = node, items = /* @__PURE__ */ new Map(), is_controlled = (flags2 & EACH_IS_CONTROLLED) !== 0;
  if (is_controlled) {
    var parent_node = (
      /** @type {Element} */
      node
    );
    anchor = parent_node.appendChild(create_text());
  }
  var fallback = null, each_array = /* @__PURE__ */ derived_safe_equal(() => {
    var collection = get_collection();
    return is_array(collection) ? collection : collection == null ? [] : array_from(collection);
  }), array, first_run = !0;
  function commit() {
    state2.fallback = fallback, reconcile(state2, array, anchor, flags2, get_key), fallback !== null && (array.length === 0 ? (fallback.f & EFFECT_OFFSCREEN) === 0 ? resume_effect(fallback) : (fallback.f ^= EFFECT_OFFSCREEN, move(fallback, null, anchor)) : pause_effect(fallback, () => {
      fallback = null;
    }));
  }
  __name(commit, "commit");
  var effect2 = block(() => {
    array = /** @type {V[]} */
    get$1(each_array);
    for (var length = array.length, keys = /* @__PURE__ */ new Set(), batch = (
      /** @type {Batch} */
      current_batch
    ), defer = should_defer_append(), index2 = 0; index2 < length; index2 += 1) {
      var value = array[index2], key = get_key(value, index2), item = first_run ? null : items.get(key);
      item ? (item.v && internal_set(item.v, value), item.i && internal_set(item.i, index2), defer && batch.skipped_effects.delete(item.e)) : (item = create_item(
        items,
        first_run ? anchor : offscreen_anchor ??= create_text(),
        value,
        key,
        index2,
        render_fn,
        flags2,
        get_collection
      ), first_run || (item.e.f |= EFFECT_OFFSCREEN), items.set(key, item)), keys.add(key);
    }
    if (length === 0 && fallback_fn && !fallback && (first_run ? fallback = branch(() => fallback_fn(anchor)) : (fallback = branch(() => fallback_fn(offscreen_anchor ??= create_text())), fallback.f |= EFFECT_OFFSCREEN)), !first_run)
      if (defer) {
        for (const [key2, item2] of items)
          keys.has(key2) || batch.skipped_effects.add(item2.e);
        batch.oncommit(commit), batch.ondiscard(() => {
        });
      } else
        commit();
    get$1(each_array);
  }), state2 = { effect: effect2, items, outrogroups: null, fallback };
  first_run = !1;
}
__name(each, "each");
function reconcile(state2, array, anchor, flags2, get_key) {
  var is_animated = (flags2 & EACH_IS_ANIMATED) !== 0, length = array.length, items = state2.items, current = state2.effect.first, seen, prev = null, to_animate, matched = [], stashed = [], value, key, effect2, i;
  if (is_animated)
    for (i = 0; i < length; i += 1)
      value = array[i], key = get_key(value, i), effect2 = /** @type {EachItem} */
      items.get(key).e, (effect2.f & EFFECT_OFFSCREEN) === 0 && (effect2.nodes?.a?.measure(), (to_animate ??= /* @__PURE__ */ new Set()).add(effect2));
  for (i = 0; i < length; i += 1) {
    if (value = array[i], key = get_key(value, i), effect2 = /** @type {EachItem} */
    items.get(key).e, state2.outrogroups !== null)
      for (const group of state2.outrogroups)
        group.pending.delete(effect2), group.done.delete(effect2);
    if ((effect2.f & EFFECT_OFFSCREEN) !== 0)
      if (effect2.f ^= EFFECT_OFFSCREEN, effect2 === current)
        move(effect2, null, anchor);
      else {
        var next = prev ? prev.next : current;
        effect2 === state2.effect.last && (state2.effect.last = effect2.prev), effect2.prev && (effect2.prev.next = effect2.next), effect2.next && (effect2.next.prev = effect2.prev), link(state2, prev, effect2), link(state2, effect2, next), move(effect2, next, anchor), prev = effect2, matched = [], stashed = [], current = prev.next;
        continue;
      }
    if ((effect2.f & INERT) !== 0 && (resume_effect(effect2), is_animated && (effect2.nodes?.a?.unfix(), (to_animate ??= /* @__PURE__ */ new Set()).delete(effect2))), effect2 !== current) {
      if (seen !== void 0 && seen.has(effect2)) {
        if (matched.length < stashed.length) {
          var start = stashed[0], j;
          prev = start.prev;
          var a = matched[0], b = matched[matched.length - 1];
          for (j = 0; j < matched.length; j += 1)
            move(matched[j], start, anchor);
          for (j = 0; j < stashed.length; j += 1)
            seen.delete(stashed[j]);
          link(state2, a.prev, b.next), link(state2, prev, a), link(state2, b, start), current = start, prev = b, i -= 1, matched = [], stashed = [];
        } else
          seen.delete(effect2), move(effect2, current, anchor), link(state2, effect2.prev, effect2.next), link(state2, effect2, prev === null ? state2.effect.first : prev.next), link(state2, prev, effect2), prev = effect2;
        continue;
      }
      for (matched = [], stashed = []; current !== null && current !== effect2; )
        (seen ??= /* @__PURE__ */ new Set()).add(current), stashed.push(current), current = current.next;
      if (current === null)
        continue;
    }
    (effect2.f & EFFECT_OFFSCREEN) === 0 && matched.push(effect2), prev = effect2, current = effect2.next;
  }
  if (state2.outrogroups !== null) {
    for (const group of state2.outrogroups)
      group.pending.size === 0 && (destroy_effects(array_from(group.done)), state2.outrogroups?.delete(group));
    state2.outrogroups.size === 0 && (state2.outrogroups = null);
  }
  if (current !== null || seen !== void 0) {
    var to_destroy = [];
    if (seen !== void 0)
      for (effect2 of seen)
        (effect2.f & INERT) === 0 && to_destroy.push(effect2);
    for (; current !== null; )
      (current.f & INERT) === 0 && current !== state2.fallback && to_destroy.push(current), current = current.next;
    var destroy_length = to_destroy.length;
    if (destroy_length > 0) {
      var controlled_anchor = (flags2 & EACH_IS_CONTROLLED) !== 0 && length === 0 ? anchor : null;
      if (is_animated) {
        for (i = 0; i < destroy_length; i += 1)
          to_destroy[i].nodes?.a?.measure();
        for (i = 0; i < destroy_length; i += 1)
          to_destroy[i].nodes?.a?.fix();
      }
      pause_effects(state2, to_destroy, controlled_anchor);
    }
  }
  is_animated && queue_micro_task(() => {
    if (to_animate !== void 0)
      for (effect2 of to_animate)
        effect2.nodes?.a?.apply();
  });
}
__name(reconcile, "reconcile");
function create_item(items, anchor, value, key, index2, render_fn, flags2, get_collection) {
  var v = (flags2 & EACH_ITEM_REACTIVE) !== 0 ? (flags2 & EACH_ITEM_IMMUTABLE) === 0 ? /* @__PURE__ */ mutable_source(value, !1, !1) : source(value) : null, i = (flags2 & EACH_INDEX_REACTIVE) !== 0 ? source(index2) : null;
  return {
    v,
    i,
    e: branch(() => (render_fn(anchor, v ?? value, i ?? index2, get_collection), () => {
      items.delete(key);
    }))
  };
}
__name(create_item, "create_item");
function move(effect2, next, anchor) {
  if (effect2.nodes)
    for (var node = effect2.nodes.start, end = effect2.nodes.end, dest = next && (next.f & EFFECT_OFFSCREEN) === 0 ? (
      /** @type {EffectNodes} */
      next.nodes.start
    ) : anchor; node !== null; ) {
      var next_node = (
        /** @type {TemplateNode} */
        /* @__PURE__ */ get_next_sibling(node)
      );
      if (dest.before(node), node === end)
        return;
      node = next_node;
    }
}
__name(move, "move");
function link(state2, prev, next) {
  prev === null ? state2.effect.first = next : prev.next = next, next === null ? state2.effect.last = prev : next.prev = prev;
}
__name(link, "link");
function html(node, get_value, svg = !1, mathml = !1, skip_warning = !1) {
  var anchor = node, value = "";
  template_effect(() => {
    var effect2 = (
      /** @type {Effect} */
      active_effect
    );
    if (value !== (value = get_value() ?? "") && (effect2.nodes !== null && (remove_effect_dom(
      effect2.nodes.start,
      /** @type {TemplateNode} */
      effect2.nodes.end
    ), effect2.nodes = null), value !== "")) {
      var html2 = value + "";
      svg ? html2 = `<svg>${html2}</svg>` : mathml && (html2 = `<math>${html2}</math>`);
      var node2 = create_fragment_from_html(html2);
      if ((svg || mathml) && (node2 = /** @type {Element} */
      /* @__PURE__ */ get_first_child(node2)), assign_nodes(
        /** @type {TemplateNode} */
        /* @__PURE__ */ get_first_child(node2),
        /** @type {TemplateNode} */
        node2.lastChild
      ), svg || mathml)
        for (; /* @__PURE__ */ get_first_child(node2); )
          anchor.before(
            /** @type {TemplateNode} */
            /* @__PURE__ */ get_first_child(node2)
          );
      else
        anchor.before(node2);
    }
  });
}
__name(html, "html");
function r(e) {
  var t, f, n = "";
  if (typeof e == "string" || typeof e == "number") n += e;
  else if (typeof e == "object") if (Array.isArray(e)) {
    var o = e.length;
    for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  } else for (f in e) e[f] && (n && (n += " "), n += f);
  return n;
}
__name(r, "r");
function clsx$1() {
  for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}
__name(clsx$1, "clsx$1");
function clsx(value) {
  return typeof value == "object" ? clsx$1(value) : value ?? "";
}
__name(clsx, "clsx");
function to_class(value, hash, directives) {
  var classname = value == null ? "" : "" + value;
  return hash && (classname = classname ? classname + " " + hash : hash), classname === "" ? null : classname;
}
__name(to_class, "to_class");
function to_style(value, styles) {
  return value == null ? null : String(value);
}
__name(to_style, "to_style");
function set_class(dom, is_html, value, hash, prev_classes, next_classes) {
  var prev = dom.__className;
  if (prev !== value || prev === void 0) {
    var next_class_name = to_class(value, hash);
    next_class_name == null ? dom.removeAttribute("class") : dom.className = next_class_name, dom.__className = value;
  }
  return next_classes;
}
__name(set_class, "set_class");
function set_style(dom, value, prev_styles, next_styles) {
  var prev = dom.__style;
  if (prev !== value) {
    var next_style_attr = to_style(value);
    next_style_attr == null ? dom.removeAttribute("style") : dom.style.cssText = next_style_attr, dom.__style = value;
  }
  return next_styles;
}
__name(set_style, "set_style");
const IS_CUSTOM_ELEMENT = /* @__PURE__ */ Symbol("is custom element"), IS_HTML = /* @__PURE__ */ Symbol("is html");
function set_value(element, value) {
  var attributes = get_attributes(element);
  attributes.value === (attributes.value = // treat null and undefined the same for the initial value
  value ?? void 0) || // @ts-expect-error
  // `progress` elements always need their value set when it's `0`
  element.value === value && (value !== 0 || element.nodeName !== "PROGRESS") || (element.value = value ?? "");
}
__name(set_value, "set_value");
function set_attribute(element, attribute, value, skip_warning) {
  var attributes = get_attributes(element);
  attributes[attribute] !== (attributes[attribute] = value) && (attribute === "loading" && (element[LOADING_ATTR_SYMBOL] = value), value == null ? element.removeAttribute(attribute) : typeof value != "string" && get_setters(element).includes(attribute) ? element[attribute] = value : element.setAttribute(attribute, value));
}
__name(set_attribute, "set_attribute");
function set_custom_element_data(node, prop2, value) {
  var previous_reaction = active_reaction, previous_effect = active_effect;
  set_active_reaction(null), set_active_effect(null);
  try {
    // `style` should use `set_attribute` rather than the setter
    prop2 !== "style" && // Don't compute setters for custom elements while they aren't registered yet,
    // because during their upgrade/instantiation they might add more setters.
    // Instead, fall back to a simple "an object, then set as property" heuristic.
    (setters_cache.has(node.getAttribute("is") || node.nodeName) || // customElements may not be available in browser extension contexts
    !customElements || customElements.get(node.getAttribute("is") || node.tagName.toLowerCase()) ? get_setters(node).includes(prop2) : value && typeof value == "object") ? node[prop2] = value : set_attribute(node, prop2, value == null ? value : String(value));
  } finally {
    set_active_reaction(previous_reaction), set_active_effect(previous_effect);
  }
}
__name(set_custom_element_data, "set_custom_element_data");
function get_attributes(element) {
  return (
    /** @type {Record<string | symbol, unknown>} **/
    // @ts-expect-error
    element.__attributes ??= {
      [IS_CUSTOM_ELEMENT]: element.nodeName.includes("-"),
      [IS_HTML]: element.namespaceURI === NAMESPACE_HTML
    }
  );
}
__name(get_attributes, "get_attributes");
var setters_cache = /* @__PURE__ */ new Map();
function get_setters(element) {
  var cache_key = element.getAttribute("is") || element.nodeName, setters = setters_cache.get(cache_key);
  if (setters) return setters;
  setters_cache.set(cache_key, setters = []);
  for (var descriptors, proto = element, element_proto = Element.prototype; element_proto !== proto; ) {
    descriptors = get_descriptors(proto);
    for (var key in descriptors)
      descriptors[key].set && setters.push(key);
    proto = get_prototype_of(proto);
  }
  return setters;
}
__name(get_setters, "get_setters");
function bind_value(input, get2, set2 = get2) {
  var batches2 = /* @__PURE__ */ new WeakSet();
  listen_to_event_and_reset_event(input, "input", async (is_reset) => {
    var value = is_reset ? input.defaultValue : input.value;
    if (value = is_numberlike_input(input) ? to_number(value) : value, set2(value), current_batch !== null && batches2.add(current_batch), await tick(), value !== (value = get2())) {
      var start = input.selectionStart, end = input.selectionEnd, length = input.value.length;
      if (input.value = value ?? "", end !== null) {
        var new_length = input.value.length;
        start === end && end === length && new_length > length ? (input.selectionStart = new_length, input.selectionEnd = new_length) : (input.selectionStart = start, input.selectionEnd = Math.min(end, new_length));
      }
    }
  }), // If we are hydrating and the value has since changed,
  // then use the updated value from the input instead.
  // If defaultValue is set, then value == defaultValue
  // TODO Svelte 6: remove input.value check and set to empty string?
  untrack(get2) == null && input.value && (set2(is_numberlike_input(input) ? to_number(input.value) : input.value), current_batch !== null && batches2.add(current_batch)), render_effect(() => {
    var value = get2();
    if (input === document.activeElement) {
      var batch = (
        /** @type {Batch} */
        previous_batch ?? current_batch
      );
      if (batches2.has(batch))
        return;
    }
    is_numberlike_input(input) && value === to_number(input.value) || input.type === "date" && !value && !input.value || value !== input.value && (input.value = value ?? "");
  });
}
__name(bind_value, "bind_value");
function is_numberlike_input(input) {
  var type = input.type;
  return type === "number" || type === "range";
}
__name(is_numberlike_input, "is_numberlike_input");
function to_number(value) {
  return value === "" ? null : +value;
}
__name(to_number, "to_number");
function is_bound_this(bound_value, element_or_component) {
  return bound_value === element_or_component || bound_value?.[STATE_SYMBOL] === element_or_component;
}
__name(is_bound_this, "is_bound_this");
function bind_this(element_or_component = {}, update, get_value, get_parts) {
  return effect(() => {
    var old_parts, parts;
    return render_effect(() => {
      old_parts = parts, parts = [], untrack(() => {
        element_or_component !== get_value(...parts) && (update(element_or_component, ...parts), old_parts && is_bound_this(get_value(...old_parts), element_or_component) && update(null, ...old_parts));
      });
    }), () => {
      queue_micro_task(() => {
        parts && is_bound_this(get_value(...parts), element_or_component) && update(null, ...parts);
      });
    };
  }), element_or_component;
}
__name(bind_this, "bind_this");
let is_store_binding = !1;
function capture_store_binding(fn) {
  var previous_is_store_binding = is_store_binding;
  try {
    return is_store_binding = !1, [fn(), is_store_binding];
  } finally {
    is_store_binding = previous_is_store_binding;
  }
}
__name(capture_store_binding, "capture_store_binding");
function prop(props, key, flags2, fallback) {
  var bindable = (flags2 & PROPS_IS_BINDABLE) !== 0, lazy = (flags2 & PROPS_IS_LAZY_INITIAL) !== 0, fallback_value = (
    /** @type {V} */
    fallback
  ), fallback_dirty = !0, get_fallback = /* @__PURE__ */ __name(() => (fallback_dirty && (fallback_dirty = !1, fallback_value = lazy ? untrack(
    /** @type {() => V} */
    fallback
  ) : (
    /** @type {V} */
    fallback
  )), fallback_value), "get_fallback"), setter;
  if (bindable) {
    var is_entry_props = STATE_SYMBOL in props || LEGACY_PROPS in props;
    setter = get_descriptor(props, key)?.set ?? (is_entry_props && key in props ? (v) => props[key] = v : void 0);
  }
  var initial_value, is_store_sub = !1;
  bindable ? [initial_value, is_store_sub] = capture_store_binding(() => (
    /** @type {V} */
    props[key]
  )) : initial_value = /** @type {V} */
  props[key], initial_value === void 0 && fallback !== void 0 && (initial_value = get_fallback(), setter && (props_invalid_value(), setter(initial_value)));
  var getter;
  if (getter = /* @__PURE__ */ __name(() => {
    var value = (
      /** @type {V} */
      props[key]
    );
    return value === void 0 ? get_fallback() : (fallback_dirty = !0, value);
  }, "getter"), (flags2 & PROPS_IS_UPDATED) === 0)
    return getter;
  if (setter) {
    var legacy_parent = props.$$legacy;
    return (
      /** @type {() => V} */
      (function(value, mutation) {
        return arguments.length > 0 ? ((!mutation || legacy_parent || is_store_sub) && setter(mutation ? getter() : value), value) : getter();
      })
    );
  }
  var overridden = !1, d = ((flags2 & PROPS_IS_IMMUTABLE) !== 0 ? derived : derived_safe_equal)(() => (overridden = !1, getter()));
  bindable && get$1(d);
  var parent_effect = (
    /** @type {Effect} */
    active_effect
  );
  return (
    /** @type {() => V} */
    (function(value, mutation) {
      if (arguments.length > 0) {
        const new_value = mutation ? get$1(d) : bindable ? proxy(value) : value;
        return set(d, new_value), overridden = !0, fallback_value !== void 0 && (fallback_value = new_value), value;
      }
      return is_destroying_effect && overridden || (parent_effect.f & DESTROYED) !== 0 ? d.v : get$1(d);
    })
  );
}
__name(prop, "prop");
function onMount(fn) {
  component_context === null && lifecycle_outside_component(), user_effect(() => {
    const cleanup = untrack(fn);
    if (typeof cleanup == "function") return (
      /** @type {() => void} */
      cleanup
    );
  });
}
__name(onMount, "onMount");
function subscribe_to_store(store, run, invalidate) {
  if (store == null)
    return run(void 0), noop;
  const unsub = untrack(
    () => store.subscribe(
      run,
      // @ts-expect-error
      invalidate
    )
  );
  return unsub.unsubscribe ? () => unsub.unsubscribe() : unsub;
}
__name(subscribe_to_store, "subscribe_to_store");
const subscriber_queue = [];
function writable(value, start = noop) {
  let stop = null;
  const subscribers = /* @__PURE__ */ new Set();
  function set2(new_value) {
    if (safe_not_equal(value, new_value) && (value = new_value, stop)) {
      const run_queue = !subscriber_queue.length;
      for (const subscriber of subscribers)
        subscriber[1](), subscriber_queue.push(subscriber, value);
      if (run_queue) {
        for (let i = 0; i < subscriber_queue.length; i += 2)
          subscriber_queue[i][0](subscriber_queue[i + 1]);
        subscriber_queue.length = 0;
      }
    }
  }
  __name(set2, "set");
  function update(fn) {
    set2(fn(
      /** @type {T} */
      value
    ));
  }
  __name(update, "update");
  function subscribe(run, invalidate = noop) {
    const subscriber = [run, invalidate];
    return subscribers.add(subscriber), subscribers.size === 1 && (stop = start(set2, update) || noop), run(
      /** @type {T} */
      value
    ), () => {
      subscribers.delete(subscriber), subscribers.size === 0 && stop && (stop(), stop = null);
    };
  }
  return __name(subscribe, "subscribe"), { set: set2, update, subscribe };
}
__name(writable, "writable");
function get(store) {
  let value;
  return subscribe_to_store(store, (_) => value = _)(), value;
}
__name(get, "get");
function createEditSessionStore() {
  const { subscribe, set: set2, update } = writable(null);
  return {
    subscribe,
    startSession: /* @__PURE__ */ __name((session) => set2({ ...session, pendingFeatures: [] }), "startSession"),
    clearSession: /* @__PURE__ */ __name(() => set2(null), "clearSession"),
    addFeature: /* @__PURE__ */ __name((feature, mode) => {
      update((s) => s ? { ...s, pendingFeatures: [...s.pendingFeatures, { feature, mode }] } : null);
    }, "addFeature"),
    clearPendingFeatures: /* @__PURE__ */ __name(() => {
      update((s) => s ? { ...s, pendingFeatures: [] } : null);
    }, "clearPendingFeatures")
  };
}
__name(createEditSessionStore, "createEditSessionStore");
const editSessionStore = createEditSessionStore(), ACTIVATION_ICONS = {
  action: "fa-circle",
  bonus: "fa-play",
  reaction: "fa-exchange-alt",
  minute: "fa-hourglass-start",
  hour: "fa-hourglass-half",
  day: "fa-hourglass-end",
  "minute:1": "fa-hourglass-start",
  "hour:1": "fa-hourglass-half",
  "day:1": "fa-hourglass-end"
}, ACTIVATION_LABELS = {
  action: "Action",
  bonus: "Bonus Action",
  reaction: "Reaction",
  minute: "Minute",
  hour: "Hour",
  day: "Day",
  "minute:1": "1 Minute",
  "hour:1": "1 Hour",
  "day:1": "1 Day"
};
class ContextMenuHandler {
  static {
    __name(this, "ContextMenuHandler");
  }
  /**
   * Register all context menu hooks
   */
  static registerContextMenus() {
    try {
      ContextMenuHandler.registerItemContextMenu(), ContextMenuHandler.registerTurnPrepContextMenu(), ContextMenuHandler.registerDragDropHandlers(), info("Context menus registered");
    } catch (error2) {
      warn("Failed to register context menus:", error2);
    }
  }
  /**
   * Register "Add to Turn Prep" option on items in actor sheets
   * Works with both Tidy5e and default sheets
   */
  static registerItemContextMenu() {
    debug("Registering item context menu hook");
    const hookCallback = /* @__PURE__ */ __name((item, menuItems) => {
      try {
        if (!item) {
          debug("Context menu hook fired with no item");
          return;
        }
        const actor = item.actor || item.parent;
        if (!actor) {
          debug(`No actor found for item: ${item.name}`);
          return;
        }
        let activities = [];
        try {
          activities = FeatureSelector.getActivitiesForItem(item);
        } catch (actErr) {
          warn(`Error getting activities for ${item.name}:`, actErr);
          return;
        }
        debug(`Adding context menu for ${item.name} (${activities.length} activities)`);
        const menuItem = {
          name: "Add to Turn Prep",
          icon: '<i class="fas fa-plus fa-fw"></i>',
          group: "customize",
          // Use Tidy5e's customize group
          condition: /* @__PURE__ */ __name(() => !0, "condition"),
          callback: /* @__PURE__ */ __name(async (li) => {
            try {
              debug(`Adding ${item.name} to turn prep`), await ContextMenuHandler.handleAddToTurnPrep(actor, item, activities);
            } catch (cbErr) {
              warn(`Failed to add ${item.name} to turn prep:`, cbErr), ui.notifications?.error(`Failed to add ${item.name} to Turn Prep`);
            }
          }, "callback")
        };
        menuItems.push(menuItem);
      } catch (err) {
        console.error("[TURN-PREP] EXCEPTION in hook callback:", err), console.error(err);
      }
    }, "hookCallback");
    Hooks.on("dnd5e.getItemContextOptions", hookCallback), debug("Registered dnd5e.getItemContextOptions hook"), Hooks.on("getActorSheetContextMenuItems", (html2, menuItems) => {
      debug("getActorSheetContextMenuItems hook fired (fallback for non-Tidy5e sheets)"), ContextMenuHandler.addMenuItemsToList(html2, menuItems);
    });
  }
  /**
   * Add menu items to a context menu list
   */
  static addMenuItemsToList(html2, menuItems) {
    const itemElement = html2.closest("[data-item-id]");
    if (!itemElement) {
      debug("No item element found in context menu");
      return;
    }
    const itemId = itemElement.getAttribute("data-item-id");
    if (!itemId) {
      debug("No item ID found");
      return;
    }
    debug(`Found item element with ID: ${itemId}`);
    let sheet = null;
    for (const w of Object.values(ui.windows)) {
      const window2 = w;
      if (window2.element && window2.object && window2.object.items && window2.object.items.get(itemId)) {
        sheet = window2;
        break;
      }
    }
    if (!sheet) {
      const sheetElement = $(html2).closest(".sheet");
      if (sheetElement.length > 0) {
        const sheetApp = sheetElement.data("app");
        sheetApp && sheetApp.object && (sheet = sheetApp);
      }
    }
    if (!sheet?.object) {
      debug("Could not find sheet or actor");
      return;
    }
    const actor = sheet.object, item = actor.items.get(itemId);
    if (!item) {
      debug(`Item ${itemId} not found on actor ${actor.name}`);
      return;
    }
    debug(`Found item: ${item.name} on actor: ${actor.name}`);
    const activities = FeatureSelector.getActivitiesForItem(item);
    debug(`Found ${activities.length} activities for ${item.name}`), menuItems.push({
      name: "Add to Turn Prep",
      icon: '<i class="fas fa-plus"></i>',
      callback: /* @__PURE__ */ __name(async (li) => {
        await ContextMenuHandler.handleAddToTurnPrep(actor, item, activities);
      }, "callback")
    }), info(`Added "Add to Turn Prep" menu item for ${item.name}`);
  }
  /**
   * Handle adding an item to turn prep
   * Adds the feature once with access to all its activities
   */
  static async handleAddToTurnPrep(actor, item, activities) {
    debug(`Handling add to turn prep for item: ${item.name}`);
    try {
      const firstActivity = activities.length > 0 ? activities[0] : null, activationType = firstActivity?.activation?.type || "other";
      await ContextMenuHandler.addFeatureToField(actor, item, firstActivity, activationType);
    } catch (error2) {
      warn(`Failed to add feature to turn prep: ${error2}`), ui.notifications?.error(`Failed to add ${item.name} to turn prep`);
    }
  }
  /**
   * Add a feature to a turn plan field
   */
  static async addFeatureToField(actor, item, activity, activationType) {
    const normalizedType = activationType && activationType !== "other" ? FeatureSelector.getActivationType(activationType) : activationType ?? "other";
    debug(`Adding feature to field: ${item.name} (${normalizedType})`);
    try {
      const feature = {
        itemId: item.id,
        itemName: item.name ?? "Unknown Feature",
        itemType: item.type ?? "item",
        actionType: normalizedType
      }, session = get(editSessionStore);
      if (session && session.actorId === actor.id) {
        editSessionStore.addFeature(feature, normalizedType), ui.notifications?.info(`Added ${item.name} to edited plan`);
        return;
      }
      const turnPrepData = await ContextMenuHandler.ensureTurnPrepData(actor), targetPlan = turnPrepData.turnPlans[0];
      switch (normalizedType) {
        case "action":
          targetPlan.actions = targetPlan.actions ?? [], targetPlan.actions.push(feature);
          break;
        case "bonus":
          targetPlan.bonusActions = targetPlan.bonusActions ?? [], targetPlan.bonusActions.push(feature);
          break;
        case "reaction": {
          Array.isArray(turnPrepData.reactions) || (turnPrepData.reactions = []);
          let targetReaction;
          if (!turnPrepData.reactions.length)
            targetReaction = createReaction("", "", [feature]), turnPrepData.reactions.push(targetReaction);
          else {
            targetReaction = turnPrepData.reactions[0];
            const existing = Array.isArray(targetReaction.reactionFeatures) ? [...targetReaction.reactionFeatures] : [];
            existing.push({
              itemId: feature.itemId,
              itemName: feature.itemName,
              itemType: feature.itemType,
              actionType: feature.actionType
            }), targetReaction.reactionFeatures = existing;
          }
          await TurnPrepStorage.save(actor, turnPrepData), ui.notifications?.info(`Added ${item.name} to reaction plan`), Hooks.callAll("turnprepAddedFeature", {
            actor,
            item,
            feature,
            isReaction: !0,
            reactionPlan: targetReaction
          });
          return;
        }
        default:
          targetPlan.additionalFeatures = targetPlan.additionalFeatures ?? [], targetPlan.additionalFeatures.push(feature);
      }
      await TurnPrepStorage.save(actor, turnPrepData), ui.notifications?.info(`Added ${item.name} to turn prep (${normalizedType})`), Hooks.callAll("turnprepAddedFeature", { actor, item, feature, plan: targetPlan });
    } catch (error2) {
      warn(`Failed to add feature to turn prep: ${error2}`), ui.notifications?.error(`Failed to add ${item.name} to turn prep`);
    }
  }
  /**
   * Ensure the actor has at least one turn plan and return the data structure
   */
  static async ensureTurnPrepData(actor) {
    const turnPrepData = await TurnPrepStorage.load(actor);
    if (Array.isArray(turnPrepData.turnPlans) || (turnPrepData.turnPlans = []), turnPrepData.turnPlans.length === 0) {
      const planLabel = FoundryAdapter.localize("TURN_PREP.TurnPlans.PlanLabel") || "Turn Plan", defaultPlan = createTurnPlan(`${planLabel} 1`, "");
      turnPrepData.turnPlans.push(defaultPlan), turnPrepData.activePlanIndex = 0;
    }
    return Array.isArray(turnPrepData.reactions) || (turnPrepData.reactions = []), turnPrepData.turnPlans = turnPrepData.turnPlans.map((plan) => ({
      ...plan,
      actions: Array.isArray(plan.actions) ? plan.actions : [],
      bonusActions: Array.isArray(plan.bonusActions) ? plan.bonusActions : [],
      reactions: Array.isArray(plan.reactions) ? plan.reactions : [],
      additionalFeatures: Array.isArray(plan.additionalFeatures) ? plan.additionalFeatures : []
    })), turnPrepData;
  }
  /**
   * Register context menu for Turn Prep panel items
   */
  static registerTurnPrepContextMenu() {
    debug("Turn Prep context menu registration placeholder");
  }
  /**
   * Register drag & drop handlers for field movement
   */
  static registerDragDropHandlers() {
    debug("Drag & drop handlers registration placeholder");
  }
  /**
   * Get all activities for a specific activation type from an item
   */
  static getActivitiesForActivationType(item, type) {
    return FeatureSelector.getActivitiesForItem(item).filter((activity) => activity.activation?.type === type);
  }
  /**
   * Get icon for an activation type
   */
  static getIconForActivationType(type) {
    return ACTIVATION_ICONS[type] || "fa-star";
  }
  /**
   * Get label for an activation type
   */
  static getLabelForActivationType(type) {
    return ACTIVATION_LABELS[type] || type.charAt(0).toUpperCase() + type.slice(1);
  }
}
async function readyModule() {
  logSection("TURN PREP READY");
  try {
    if (!isModuleEnabled()) {
      info("Turn Prep module is disabled in world settings");
      return;
    }
    checkDependencies(), await setupSheetIntegrations(), registerHooks(), validateModuleData(), window.TurnPrepAPI = TurnPrepApiInstance, game.TurnPrepAPI = TurnPrepApiInstance, info("Module ready and initialized"), info("API exposed as game.TurnPrepAPI and window.TurnPrepAPI");
  } catch (err) {
    error("Failed to complete module ready initialization", err), notifyWarning("Turn Prep: Initialization failed. Check console for details.");
  }
}
__name(readyModule, "readyModule");
function isModuleEnabled() {
  try {
    return FoundryAdapter.getSetting(SETTINGS.ENABLE_TAB.key) !== !1;
  } catch {
    return warn("Settings not yet fully initialized, defaulting to enabled"), !0;
  }
}
__name(isModuleEnabled, "isModuleEnabled");
function checkDependencies() {
  info("Checking dependencies..."), FoundryAdapter.isModuleActive("tidy5e-sheet") ? info("✓ Tidy 5E Sheets detected") : warn("Tidy 5E Sheets not active - using default sheet integration");
  const d5eSystemId = game.system?.id;
  d5eSystemId !== "dnd5e" ? warn(`System is "${d5eSystemId}", Turn Prep is designed for "dnd5e"`) : info("✓ D&D 5e system detected");
  const midiActive = FoundryAdapter.isModuleActive("midi-qol");
  info(midiActive ? "✓ MidiQOL detected - optional integration available" : "MidiQOL not active - that's ok, it's optional");
}
__name(checkDependencies, "checkDependencies");
async function setupSheetIntegrations() {
  info("Setting up sheet integrations..."), FoundryAdapter.isModuleActive("tidy5e-sheet") ? await setupTidyIntegration() : setupDefaultSheetIntegration(), info("Sheet integrations configured");
}
__name(setupSheetIntegrations, "setupSheetIntegrations");
async function setupTidyIntegration() {
  info("Integrating with Tidy 5E Sheets...");
  try {
    info("✓ Tidy 5E integration hooks registered at module load time");
  } catch (err) {
    warn("Failed to integrate with Tidy 5E Sheets", err);
  }
}
__name(setupTidyIntegration, "setupTidyIntegration");
function setupDefaultSheetIntegration() {
  info("Preparing default sheet integration..."), info("Default sheet integration layer ready for Phase 2 implementation");
}
__name(setupDefaultSheetIntegration, "setupDefaultSheetIntegration");
function registerHooks() {
  info("Registering module hooks...");
  try {
    ContextMenuHandler.registerContextMenus(), info("✓ Context menu hooks registered");
  } catch (err) {
    error("Failed to register context menu hooks", err);
  }
  info("Hook handlers configured");
}
__name(registerHooks, "registerHooks");
function validateModuleData() {
  info("Validating existing module data...");
  try {
    const actors = FoundryAdapter.getOwnedActors();
    info(`Found ${actors.length} owned actors to validate`);
    let dataFixed = 0;
    for (const actor of actors)
      FoundryAdapter.getTurnPrepData(actor) && info(`Actor "${actor.name}" has Turn Prep data`);
    dataFixed > 0, info("Data validation complete");
  } catch (err) {
    warn("Error during data validation", err);
  }
}
__name(validateModuleData, "validateModuleData");
const PUBLIC_VERSION = "5";
typeof window < "u" && ((window.__svelte ??= {}).v ??= /* @__PURE__ */ new Set()).add(PUBLIC_VERSION);
var root_3$5 = /* @__PURE__ */ from_html('<p class="turn-prep-context-menu__section-label"> </p>'), root_5$3 = /* @__PURE__ */ from_html('<span class="description"> </span>'), root_6$2 = /* @__PURE__ */ from_html('<span class="turn-prep-context-menu__item-caret" aria-hidden="true">&#8250;</span>'), root_4$4 = /* @__PURE__ */ from_html('<button type="button" role="menuitem"><span class="turn-prep-context-menu__item-icon" aria-hidden="true"><i></i></span> <span class="turn-prep-context-menu__item-text"><span class="label"> </span> <!></span> <!></button>'), root_2$5 = /* @__PURE__ */ from_html('<section class="turn-prep-context-menu__section"><!> <div class="turn-prep-context-menu__items"></div></section>'), root_9$3 = /* @__PURE__ */ from_html('<p class="turn-prep-context-menu__section-label"> </p>'), root_11$4 = /* @__PURE__ */ from_html('<span class="description"> </span>'), root_12$4 = /* @__PURE__ */ from_html('<span class="turn-prep-context-menu__item-caret" aria-hidden="true">&#8250;</span>'), root_10$4 = /* @__PURE__ */ from_html('<button type="button" role="menuitem"><span class="turn-prep-context-menu__item-icon" aria-hidden="true"><i></i></span> <span class="turn-prep-context-menu__item-text"><span class="label"> </span> <!></span> <!></button>'), root_8$4 = /* @__PURE__ */ from_html('<section class="turn-prep-context-menu__section"><!> <div class="turn-prep-context-menu__items"></div></section>'), root_7$4 = /* @__PURE__ */ from_html('<div class="turn-prep-context-menu turn-prep-context-menu--submenu" role="menu" aria-label="Submenu"><div class="turn-prep-context-menu__sections"></div></div>'), root_1$6 = /* @__PURE__ */ from_html('<div class="turn-prep-context-menu-root"><div class="turn-prep-context-menu" role="menu"><div class="turn-prep-context-menu__sections"></div></div> <!></div>');
function ContextMenuHost($$anchor, $$props) {
  push($$props, !0);
  let menuState = /* @__PURE__ */ state(null), menuElement = /* @__PURE__ */ state(null), menuPosition = /* @__PURE__ */ state(proxy({ top: -9999, left: -9999 })), submenuState = /* @__PURE__ */ state(null), submenuElement = /* @__PURE__ */ state(null), submenuPosition = /* @__PURE__ */ state(proxy({ top: -9999, left: -9999 })), submenuAnchor = null, unsubscribe = null;
  async function updateState(next) {
    if (set(menuState, next, !0), !next) {
      set(menuPosition, { top: -9999, left: -9999 }, !0), set(submenuState, null), set(submenuPosition, { top: -9999, left: -9999 }, !0);
      return;
    }
    await tick(), positionMenu(next), focusFirstButton();
  }
  __name(updateState, "updateState");
  function positionMenu(state2) {
    if (!get$1(menuElement)) return;
    const rect = get$1(menuElement).getBoundingClientRect(), padding = 8;
    let x = state2.position.x, y = state2.position.y;
    x + rect.width + padding > window.innerWidth && (x = Math.max(padding, window.innerWidth - rect.width - padding)), y + rect.height + padding > window.innerHeight && (y = Math.max(padding, window.innerHeight - rect.height - padding)), set(menuPosition, { top: y, left: x }, !0);
  }
  __name(positionMenu, "positionMenu");
  function positionSubmenu() {
    if (!get$1(submenuState) || !get$1(submenuElement)) return;
    const anchorRect = get$1(submenuState).anchorRect, rect = get$1(submenuElement).getBoundingClientRect(), padding = 8;
    let x = (anchorRect?.right ?? get$1(menuPosition).left) + 6, y = anchorRect?.top ?? get$1(menuPosition).top;
    x + rect.width + padding > window.innerWidth && (x = Math.max(padding, (anchorRect?.left ?? get$1(menuPosition).left) - rect.width - 6)), y + rect.height + padding > window.innerHeight && (y = Math.max(padding, window.innerHeight - rect.height - padding)), set(submenuPosition, { top: y, left: x }, !0);
  }
  __name(positionSubmenu, "positionSubmenu");
  function focusFirstButton() {
    if (!get$1(menuElement)) return;
    get$1(menuElement).querySelector("button:not(:disabled)")?.focus({ preventScroll: !0 });
  }
  __name(focusFirstButton, "focusFirstButton");
  function handleGlobalPointer(event2) {
    if (!get$1(menuState)) return;
    const target = event2.target;
    target && (get$1(menuElement)?.contains(target) || get$1(submenuElement)?.contains(target) || get$1(menuState).anchorElement?.contains?.(target)) || $$props.controller.close("dismiss");
  }
  __name(handleGlobalPointer, "handleGlobalPointer");
  function handleKeyDown(event2) {
    if (!get$1(menuState)) return;
    if (event2.key === "Escape") {
      event2.preventDefault(), $$props.controller.close("escape");
      return;
    }
    if (event2.key === "ArrowLeft") {
      get$1(submenuState) && submenuAnchor && get$1(submenuElement)?.contains(document.activeElement) && (event2.preventDefault(), submenuAnchor.focus({ preventScroll: !0 }), set(submenuState, null), set(submenuPosition, { top: -9999, left: -9999 }, !0));
      return;
    }
    if (event2.key === "ArrowRight") {
      const active2 = document.activeElement;
      active2 instanceof HTMLElement && active2.dataset?.submenu === "true" && (event2.preventDefault(), openSubmenuFromAnchor(active2), focusFirstSubmenuButton());
      return;
    }
    if (event2.key !== "ArrowDown" && event2.key !== "ArrowUp")
      return;
    const focusedElement = document.activeElement, container = get$1(submenuElement)?.contains(focusedElement) ? get$1(submenuElement) : get$1(menuElement), buttons = Array.from(container?.querySelectorAll("button:not(:disabled)") ?? []);
    if (!buttons.length)
      return;
    event2.preventDefault();
    const direction = event2.key === "ArrowDown" ? 1 : -1, active = document.activeElement, nextIndex = (buttons.findIndex((btn) => btn === active) + direction + buttons.length) % buttons.length;
    buttons[nextIndex]?.focus({ preventScroll: !0 });
  }
  __name(handleKeyDown, "handleKeyDown");
  function handleWindowChange() {
    get$1(menuState) && (positionMenu(get$1(menuState)), positionSubmenu());
  }
  __name(handleWindowChange, "handleWindowChange");
  function handleItemPointer(event2) {
    event2.stopPropagation();
  }
  __name(handleItemPointer, "handleItemPointer");
  function handleItemClick(event2, action) {
    event2.preventDefault(), event2.stopPropagation(), !action.submenu?.length && $$props.controller.runAction(action);
  }
  __name(handleItemClick, "handleItemClick");
  function handleItemEnter(action, target) {
    action.submenu?.length ? openSubmenu(action, target) : (set(submenuState, null), set(submenuPosition, { top: -9999, left: -9999 }, !0));
  }
  __name(handleItemEnter, "handleItemEnter");
  async function openSubmenu(action, target) {
    if (!action.submenu?.length || !target) {
      set(submenuState, null), set(submenuPosition, { top: -9999, left: -9999 }, !0), submenuAnchor = null;
      return;
    }
    submenuAnchor = target, set(
      submenuState,
      {
        actionId: action.id,
        sections: action.submenu,
        anchorRect: target.getBoundingClientRect()
      },
      !0
    ), await tick(), positionSubmenu();
  }
  __name(openSubmenu, "openSubmenu");
  async function openSubmenuFromAnchor(target) {
    const actionId = target.dataset?.actionId;
    if (!actionId) return;
    const action = get$1(menuState)?.sections.flatMap((s) => s.actions).find((a) => a.id === actionId);
    action && await openSubmenu(action, target);
  }
  __name(openSubmenuFromAnchor, "openSubmenuFromAnchor");
  function focusFirstSubmenuButton() {
    if (!get$1(submenuElement)) return;
    get$1(submenuElement).querySelector("button:not(:disabled)")?.focus({ preventScroll: !0 });
  }
  __name(focusFirstSubmenuButton, "focusFirstSubmenuButton"), onMount(() => (unsubscribe = $$props.controller.subscribe((state2) => {
    updateState(state2);
  }), document.addEventListener("pointerdown", handleGlobalPointer, !0), document.addEventListener("contextmenu", handleGlobalPointer, !0), document.addEventListener("wheel", handleGlobalPointer, !0), document.addEventListener("keydown", handleKeyDown, !0), window.addEventListener("resize", handleWindowChange), () => {
    document.removeEventListener("pointerdown", handleGlobalPointer, !0), document.removeEventListener("contextmenu", handleGlobalPointer, !0), document.removeEventListener("wheel", handleGlobalPointer, !0), document.removeEventListener("keydown", handleKeyDown, !0), window.removeEventListener("resize", handleWindowChange), unsubscribe?.(), unsubscribe = null;
  }));
  var fragment = comment(), node = first_child(fragment);
  {
    var consequent_7 = /* @__PURE__ */ __name(($$anchor2) => {
      var div = root_1$6(), div_1 = child(div), div_2 = child(div_1);
      each(div_2, 21, () => get$1(menuState).sections, (section) => section.id, ($$anchor3, section) => {
        var section_1 = root_2$5(), node_1 = child(section_1);
        {
          var consequent = /* @__PURE__ */ __name(($$anchor4) => {
            var p = root_3$5(), text = child(p);
            template_effect(() => set_text(text, get$1(section).label)), append($$anchor4, p);
          }, "consequent");
          if_block(node_1, ($$render) => {
            get$1(section).label && $$render(consequent);
          });
        }
        var div_3 = sibling(node_1, 2);
        each(div_3, 21, () => get$1(section).actions, (action) => action.id, ($$anchor4, action) => {
          var button_1 = root_4$4();
          button_1.__pointerdown = handleItemPointer, button_1.__click = (event2) => handleItemClick(event2, get$1(action));
          var span = child(button_1), i = child(span), span_1 = sibling(span, 2), span_2 = child(span_1), text_1 = child(span_2), node_2 = sibling(span_2, 2);
          {
            var consequent_1 = /* @__PURE__ */ __name(($$anchor5) => {
              var span_3 = root_5$3(), text_2 = child(span_3);
              template_effect(() => set_text(text_2, get$1(action).description)), append($$anchor5, span_3);
            }, "consequent_1");
            if_block(node_2, ($$render) => {
              get$1(action).description && $$render(consequent_1);
            });
          }
          var node_3 = sibling(span_1, 2);
          {
            var consequent_2 = /* @__PURE__ */ __name(($$anchor5) => {
              var span_4 = root_6$2();
              append($$anchor5, span_4);
            }, "consequent_2");
            if_block(node_3, ($$render) => {
              get$1(action).submenu?.length && $$render(consequent_2);
            });
          }
          template_effect(() => {
            set_class(button_1, 1, `turn-prep-context-menu__item ${get$1(action).variant === "destructive" ? "is-destructive" : ""} ${get$1(action).disabled ? "is-disabled" : ""}`), set_attribute(button_1, "aria-haspopup", get$1(action).submenu?.length ? "true" : void 0), set_attribute(button_1, "data-action-id", get$1(action).id), set_attribute(button_1, "data-submenu", get$1(action).submenu?.length ? "true" : void 0), button_1.disabled = get$1(action).disabled, set_class(i, 1, clsx(get$1(action).icon)), set_text(text_1, get$1(action).label);
          }), event("pointerenter", button_1, (event2) => handleItemEnter(get$1(action), event2.currentTarget)), event("focus", button_1, (event2) => handleItemEnter(get$1(action), event2.currentTarget)), append($$anchor4, button_1);
        }), template_effect(() => set_attribute(section_1, "aria-label", get$1(section).label)), append($$anchor3, section_1);
      }), bind_this(div_1, ($$value) => set(menuElement, $$value), () => get$1(menuElement));
      var node_4 = sibling(div_1, 2);
      {
        var consequent_6 = /* @__PURE__ */ __name(($$anchor3) => {
          var div_4 = root_7$4(), div_5 = child(div_4);
          each(div_5, 21, () => get$1(submenuState).sections, (section) => section.id, ($$anchor4, section) => {
            var section_2 = root_8$4(), node_5 = child(section_2);
            {
              var consequent_3 = /* @__PURE__ */ __name(($$anchor5) => {
                var p_1 = root_9$3(), text_3 = child(p_1);
                template_effect(() => set_text(text_3, get$1(section).label)), append($$anchor5, p_1);
              }, "consequent_3");
              if_block(node_5, ($$render) => {
                get$1(section).label && $$render(consequent_3);
              });
            }
            var div_6 = sibling(node_5, 2);
            each(div_6, 21, () => get$1(section).actions, (action) => action.id, ($$anchor5, action) => {
              var button_2 = root_10$4();
              button_2.__pointerdown = handleItemPointer, button_2.__click = (event2) => handleItemClick(event2, get$1(action));
              var span_5 = child(button_2), i_1 = child(span_5), span_6 = sibling(span_5, 2), span_7 = child(span_6), text_4 = child(span_7), node_6 = sibling(span_7, 2);
              {
                var consequent_4 = /* @__PURE__ */ __name(($$anchor6) => {
                  var span_8 = root_11$4(), text_5 = child(span_8);
                  template_effect(() => set_text(text_5, get$1(action).description)), append($$anchor6, span_8);
                }, "consequent_4");
                if_block(node_6, ($$render) => {
                  get$1(action).description && $$render(consequent_4);
                });
              }
              var node_7 = sibling(span_6, 2);
              {
                var consequent_5 = /* @__PURE__ */ __name(($$anchor6) => {
                  var span_9 = root_12$4();
                  append($$anchor6, span_9);
                }, "consequent_5");
                if_block(node_7, ($$render) => {
                  get$1(action).submenu?.length && $$render(consequent_5);
                });
              }
              template_effect(() => {
                set_class(button_2, 1, `turn-prep-context-menu__item ${get$1(action).variant === "destructive" ? "is-destructive" : ""} ${get$1(action).disabled ? "is-disabled" : ""}`), button_2.disabled = get$1(action).disabled, set_class(i_1, 1, clsx(get$1(action).icon)), set_text(text_4, get$1(action).label);
              }), append($$anchor5, button_2);
            }), template_effect(() => set_attribute(section_2, "aria-label", get$1(section).label)), append($$anchor4, section_2);
          }), bind_this(div_4, ($$value) => set(submenuElement, $$value), () => get$1(submenuElement)), template_effect(() => set_style(div_4, `top: ${get$1(submenuPosition).top}px; left: ${get$1(submenuPosition).left}px;`)), append($$anchor3, div_4);
        }, "consequent_6");
        if_block(node_4, ($$render) => {
          get$1(submenuState) && $$render(consequent_6);
        });
      }
      template_effect(() => {
        set_style(div_1, `top: ${get$1(menuPosition).top}px; left: ${get$1(menuPosition).left}px;`), set_attribute(div_1, "aria-label", typeof get$1(menuState).context?.ariaLabel == "string" ? get$1(menuState).context?.ariaLabel : "Context menu");
      }), append($$anchor2, div);
    }, "consequent_7");
    if_block(node, ($$render) => {
      get$1(menuState) && $$render(consequent_7);
    });
  }
  append($$anchor, fragment), pop();
}
__name(ContextMenuHost, "ContextMenuHost");
delegate(["pointerdown", "click"]);
let controllerCounter = 0;
class ContextMenuController {
  static {
    __name(this, "ContextMenuController");
  }
  state = null;
  subscribers = /* @__PURE__ */ new Set();
  id;
  constructor(id) {
    controllerCounter += 1, this.id = id ?? `context-menu-${controllerCounter}`;
  }
  subscribe(listener) {
    return this.subscribers.add(listener), listener(this.state), () => {
      this.subscribers.delete(listener);
    };
  }
  open(request) {
    const requestId = request.requestId ?? `${this.id}-${Date.now()}`, previous = this.state;
    if (previous)
      try {
        previous.onClose?.("dismiss");
      } catch (err) {
        warn("[ContextMenuController] Previous onClose callback failed", err);
      }
    this.state = {
      ...request,
      requestId,
      isOpen: !0,
      openedAt: Date.now()
    }, this.emit();
  }
  close(reason = "manual") {
    if (!this.state)
      return;
    const current = this.state;
    this.state = null, this.emit();
    try {
      current.onClose?.(reason);
    } catch (err) {
      warn("[ContextMenuController] onClose callback failed", err);
    }
  }
  runAction(action, reason = "select") {
    if (action.disabled)
      return;
    this.state?.closeOnSelect !== !1 && this.close(reason);
    try {
      const result = action.onSelect();
      result instanceof Promise && result.catch((err) => {
        warn("[ContextMenuController] Action handler failed", err);
      });
    } catch (err) {
      warn("[ContextMenuController] Action handler threw", err);
    }
  }
  getState() {
    return this.state;
  }
  emit() {
    for (const listener of this.subscribers)
      try {
        listener(this.state);
      } catch (err) {
        warn("[ContextMenuController] Subscriber failed", err);
      }
  }
}
var root_2$4 = /* @__PURE__ */ from_html(`<div role="group" tabindex="-1"><div class="question-inputs svelte-tp-11nt91r"><input type="text" class="turn-prep-input question-input" placeholder="What do you want to ask the DM?"/> <textarea class="turn-prep-textarea answer-input svelte-tp-11nt91r" placeholder="DM's answer (or your notes)"></textarea></div> <div class="question-actions svelte-tp-11nt91r"><button type="button" aria-haspopup="menu"><i class="fa-solid fa-ellipsis-vertical svelte-tp-11nt91r"></i></button></div></div>`), root_1$5 = /* @__PURE__ */ from_html('<div class="turn-prep-panel-list questions-list"></div>'), root$5 = /* @__PURE__ */ from_html('<div class="turn-prep-panel turn-prep-dm-questions"><div class="turn-prep-panel-header"><button type="button" class="turn-prep-panel-toggle"><i></i></button> <h3>DM Questions</h3> <button type="button" class="turn-prep-panel-action-btn"><i class="fas fa-plus"></i> Add Question</button></div> <!></div> <!>', 1);
function DmQuestionsPanel($$anchor, $$props) {
  push($$props, !0);
  function loadQuestions() {
    if (!$$props.actor)
      return Array.from({ length: 1 }, () => ({ question: "", answer: "" }));
    const savedData = $$props.actor.getFlag(FLAG_SCOPE, FLAG_KEY_DATA);
    if (savedData?.dmQuestions) {
      if (Array.isArray(savedData.dmQuestions))
        return savedData.dmQuestions;
      if (typeof savedData.dmQuestions == "object") {
        const oldData = savedData.dmQuestions, migrated = Object.values(oldData);
        return info("Migrated DM Questions from object to array format"), setTimeout(
          () => {
            const currentData = $$props.actor.getFlag(FLAG_SCOPE, FLAG_KEY_DATA) || {};
            $$props.actor.setFlag(FLAG_SCOPE, FLAG_KEY_DATA, { ...currentData, dmQuestions: migrated });
          },
          0
        ), migrated;
      }
    }
    return Array.from({ length: 1 }, () => ({ question: "", answer: "" }));
  }
  __name(loadQuestions, "loadQuestions");
  let questions = /* @__PURE__ */ state(proxy(loadQuestions())), collapsed = /* @__PURE__ */ state(!1);
  const questionMenuController = new ContextMenuController("dm-questions-panel");
  let activeContextIndex = /* @__PURE__ */ state(null);
  onMount(() => {
    const unsubscribe = questionMenuController.subscribe((state2) => {
      const contextIndex = state2?.context?.index;
      set(activeContextIndex, typeof contextIndex == "number" ? contextIndex : null, !0);
    });
    return () => unsubscribe();
  });
  let saveTimeout = null;
  function saveQuestions() {
    if (!$$props.actor) return;
    const payload = {
      ...$$props.actor.getFlag(FLAG_SCOPE, FLAG_KEY_DATA) || {},
      dmQuestions: get$1(questions).map((q) => ({ ...q }))
    }, flagPath = `flags.${FLAG_SCOPE}.${FLAG_KEY_DATA}`;
    $$props.actor.update({ [flagPath]: payload }, { render: !1, diff: !1 }).catch((err) => error("Failed to save DM questions", err));
  }
  __name(saveQuestions, "saveQuestions");
  function debouncedSave() {
    saveTimeout && clearTimeout(saveTimeout), saveTimeout = setTimeout(
      () => {
        saveQuestions(), saveTimeout = null;
      },
      1e3
    );
  }
  __name(debouncedSave, "debouncedSave");
  function handleInput(index2, field, value) {
    get$1(questions)[index2][field] = value, debouncedSave();
  }
  __name(handleInput, "handleInput");
  function addQuestion() {
    set(questions, [...get$1(questions), { question: "", answer: "" }], !0), saveQuestions();
  }
  __name(addQuestion, "addQuestion");
  function removeQuestion(index2) {
    get$1(questions).length === 1 ? get$1(questions)[index2] = { question: "", answer: "" } : set(questions, get$1(questions).filter((_, i) => i !== index2), !0), saveQuestions();
  }
  __name(removeQuestion, "removeQuestion");
  function duplicateQuestion(index2) {
    const source2 = get$1(questions)[index2];
    if (!source2)
      return;
    const clone = { question: source2.question, answer: source2.answer };
    set(
      questions,
      [
        ...get$1(questions).slice(0, index2 + 1),
        clone,
        ...get$1(questions).slice(index2 + 1)
      ],
      !0
    ), saveQuestions();
  }
  __name(duplicateQuestion, "duplicateQuestion");
  function reorderQuestions(fromIndex, toIndex) {
    get$1(questions).length && (set(questions, moveArrayItem$1(get$1(questions), fromIndex, toIndex), !0), debouncedSave());
  }
  __name(reorderQuestions, "reorderQuestions");
  async function whisperToDm(index2) {
    const q = get$1(questions)[index2];
    if (!q.question) return;
    const content = q.question, gmIds = (game.users?.filter((u) => u.isGM) || []).map((u) => u.id);
    await ChatMessage.create({
      content,
      whisper: gmIds,
      speaker: ChatMessage.getSpeaker({ actor: $$props.actor })
    }), ui.notifications?.info("Question whispered to DM");
  }
  __name(whisperToDm, "whisperToDm");
  async function sendToChat(index2) {
    const q = get$1(questions)[index2];
    if (!q.question) return;
    const content = q.question;
    await ChatMessage.create({
      content,
      speaker: ChatMessage.getSpeaker({ actor: $$props.actor })
    }), ui.notifications?.info("Question sent to chat");
  }
  __name(sendToChat, "sendToChat");
  function getQuestionMenuActions(index2) {
    const total = get$1(questions).length, arrangeActions = [
      {
        id: "move-up",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveUp") || "Move Up",
        icon: "fa-solid fa-angle-up",
        onSelect: /* @__PURE__ */ __name(() => reorderQuestions(index2, Math.max(0, index2 - 1)), "onSelect")
      },
      {
        id: "move-down",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveDown") || "Move Down",
        icon: "fa-solid fa-angle-down",
        onSelect: /* @__PURE__ */ __name(() => reorderQuestions(index2, Math.min(total - 1, index2 + 1)), "onSelect")
      },
      {
        id: "move-top",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveTop") || "Move to Top",
        icon: "fa-solid fa-angles-up",
        onSelect: /* @__PURE__ */ __name(() => reorderQuestions(index2, 0), "onSelect")
      },
      {
        id: "move-bottom",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveBottom") || "Move to Bottom",
        icon: "fa-solid fa-angles-down",
        onSelect: /* @__PURE__ */ __name(() => reorderQuestions(index2, total - 1), "onSelect")
      }
    ], arrangeSubmenu = [
      { id: `dm-question-${index2}-reorder`, actions: arrangeActions }
    ];
    return [
      {
        id: "whisper",
        label: FoundryAdapter.localize("TURN_PREP.DmQuestions.ContextMenu.Whisper"),
        icon: "fas fa-paper-plane",
        onSelect: /* @__PURE__ */ __name(() => whisperToDm(index2), "onSelect")
      },
      {
        id: "chat",
        label: FoundryAdapter.localize("TURN_PREP.DmQuestions.ContextMenu.SendToChat"),
        icon: "fas fa-comments",
        onSelect: /* @__PURE__ */ __name(() => sendToChat(index2), "onSelect")
      },
      {
        id: "duplicate",
        label: FoundryAdapter.localize("TURN_PREP.DmQuestions.ContextMenu.Duplicate"),
        icon: "fas fa-copy",
        onSelect: /* @__PURE__ */ __name(() => duplicateQuestion(index2), "onSelect")
      },
      {
        id: "arrange",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.Arrange") || "Arrange",
        icon: "fa-solid fa-arrow-up-wide-short",
        submenu: arrangeSubmenu,
        onSelect: /* @__PURE__ */ __name(() => {
        }, "onSelect")
      },
      {
        id: "delete",
        label: FoundryAdapter.localize("TURN_PREP.DmQuestions.ContextMenu.Delete"),
        icon: "fas fa-trash",
        variant: "destructive",
        onSelect: /* @__PURE__ */ __name(() => removeQuestion(index2), "onSelect")
      }
    ];
  }
  __name(getQuestionMenuActions, "getQuestionMenuActions");
  function buildQuestionMenuSections(index2) {
    return [
      {
        id: `dm-question-${index2}`,
        actions: getQuestionMenuActions(index2)
      }
    ];
  }
  __name(buildQuestionMenuSections, "buildQuestionMenuSections");
  function openQuestionContextMenu(index2, position, anchorElement) {
    questionMenuController.open({
      sections: buildQuestionMenuSections(index2),
      position,
      anchorElement: anchorElement ?? null,
      context: {
        index: index2,
        ariaLabel: FoundryAdapter.localize("TURN_PREP.Reactions.ContextMenuLabel")
      }
    });
  }
  __name(openQuestionContextMenu, "openQuestionContextMenu");
  function handleQuestionContextMenu(index2, event2) {
    event2.preventDefault(), event2.stopPropagation(), openQuestionContextMenu(index2, { x: event2.clientX, y: event2.clientY }, event2.currentTarget);
  }
  __name(handleQuestionContextMenu, "handleQuestionContextMenu");
  function handleQuestionMenuButton(index2, event2) {
    event2.preventDefault(), event2.stopPropagation();
    const button = event2.currentTarget;
    if (button) {
      const rect = button.getBoundingClientRect();
      openQuestionContextMenu(index2, { x: rect.right, y: rect.bottom + 4 }, button);
      return;
    }
    openQuestionContextMenu(index2, { x: event2.clientX, y: event2.clientY });
  }
  __name(handleQuestionMenuButton, "handleQuestionMenuButton");
  var fragment = root$5(), div = first_child(fragment), div_1 = child(div), button_1 = child(div_1);
  button_1.__click = () => set(collapsed, !get$1(collapsed));
  var i_1 = child(button_1), button_2 = sibling(button_1, 4);
  button_2.__click = addQuestion;
  var node = sibling(div_1, 2);
  {
    var consequent = /* @__PURE__ */ __name(($$anchor2) => {
      var div_2 = root_1$5();
      each(div_2, 21, () => get$1(questions), index, ($$anchor3, q, i) => {
        var div_3 = root_2$4();
        div_3.__contextmenu = (event2) => handleQuestionContextMenu(i, event2);
        var div_4 = child(div_3), input = child(div_4);
        input.__input = (e) => handleInput(i, "question", e.currentTarget.value);
        var textarea = sibling(input, 2);
        textarea.__input = (e) => handleInput(i, "answer", e.currentTarget.value);
        var div_5 = sibling(div_4, 2), button_3 = child(div_5);
        button_3.__click = (event2) => handleQuestionMenuButton(i, event2), template_effect(
          ($0) => {
            set_class(div_3, 1, `turn-prep-panel-card question-row ${get$1(activeContextIndex) === i ? "context-open" : ""}`, "svelte-tp-11nt91r"), set_value(input, get$1(q).question), set_value(textarea, get$1(q).answer), set_class(button_3, 1, `question-menu-btn ${get$1(activeContextIndex) === i ? "is-active" : ""}`, "svelte-tp-11nt91r"), set_attribute(button_3, "title", $0), set_attribute(button_3, "aria-expanded", get$1(activeContextIndex) === i ? "true" : "false");
          },
          [
            () => FoundryAdapter.localize("TURN_PREP.Reactions.ContextMenuLabel")
          ]
        ), append($$anchor3, div_3);
      }), append($$anchor2, div_2);
    }, "consequent");
    if_block(node, ($$render) => {
      get$1(collapsed) || $$render(consequent);
    });
  }
  var node_1 = sibling(div, 2);
  ContextMenuHost(node_1, {
    get controller() {
      return questionMenuController;
    }
  }), template_effect(() => {
    set_attribute(button_1, "title", get$1(collapsed) ? "Expand" : "Collapse"), set_class(i_1, 1, `fas fa-chevron-${get$1(collapsed) ? "right" : "down"}`);
  }), append($$anchor, fragment), pop();
}
__name(DmQuestionsPanel, "DmQuestionsPanel");
delegate(["click", "contextmenu", "input"]);
const DAMAGE_ICON_BASE_PATH = "systems/dnd5e/icons/svg/damage", TURN_PREP_DRAG_MIME = "application/vnd.turn-prep.feature", UUID_FALLBACK_PATTERN = /^(Actor|Item|Scene|JournalEntry|Macro|Playlist|RollTable|User|Cards|Token|AmbientSound|PlaylistSound|Region)\./i;
function resolveTurnPlanTableForActivations(activations) {
  const normalized = normalizeActivationTypes(activations);
  return normalized.has("action") ? "actions" : normalized.has("bonus") || normalized.has("bonus action") ? "bonusActions" : normalized.has("reaction") ? "reactions" : "additionalFeatures";
}
__name(resolveTurnPlanTableForActivations, "resolveTurnPlanTableForActivations");
function resolveReactionPlanTableForActivations(activations) {
  return normalizeActivationTypes(activations).has("reaction") ? "reactionFeatures" : "additionalFeatures";
}
__name(resolveReactionPlanTableForActivations, "resolveReactionPlanTableForActivations");
function isActivationCompatibleWithTable(activation, table) {
  if (table === "additionalFeatures") return !0;
  const normalized = normalizeSingleActivation(activation);
  if (!normalized) return !1;
  const required = getRequiredActivationForTable(table);
  return required ? normalized === required : !1;
}
__name(isActivationCompatibleWithTable, "isActivationCompatibleWithTable");
function hasDuplicateFeature(list, feature) {
  const targetId = feature?.itemId;
  return targetId ? (list ?? []).some((entry) => entry?.itemId === targetId) : !1;
}
__name(hasDuplicateFeature, "hasDuplicateFeature");
function moveArrayItem(list, fromIndex, toIndex) {
  if (!Array.isArray(list) || list.length === 0) return Array.isArray(list) ? Array.from(list) : [];
  if (!Number.isFinite(fromIndex) || !Number.isFinite(toIndex))
    return Array.from(list);
  const array = Array.from(list), clampedFrom = clampIndex(fromIndex, array.length), clampedTo = clampIndex(toIndex, array.length);
  if (clampedFrom === clampedTo)
    return array;
  const [item] = array.splice(clampedFrom, 1);
  return array.splice(clampedTo, 0, item), array;
}
__name(moveArrayItem, "moveArrayItem");
function setTurnPrepDragData(dataTransfer, payload) {
  if (!dataTransfer) return;
  const serialized = JSON.stringify(payload);
  dataTransfer.setData(TURN_PREP_DRAG_MIME, serialized), dataTransfer.setData("application/json", serialized);
  const uuid = buildActorItemUuid(payload.actorId, payload.feature?.itemId);
  uuid && dataTransfer.setData("text/plain", uuid);
}
__name(setTurnPrepDragData, "setTurnPrepDragData");
function parseTurnPrepDragData(dataTransfer) {
  if (!dataTransfer) return null;
  const custom = dataTransfer.getData(TURN_PREP_DRAG_MIME), customPayload = parseTurnPrepPayload(custom);
  if (customPayload)
    return { kind: "turn-prep-feature", payload: customPayload };
  const json = dataTransfer.getData("application/json"), parsedJson = parseJson(json), payloadFromJson = parseTurnPrepPayloadFromObject(parsedJson);
  if (payloadFromJson)
    return { kind: "turn-prep-feature", payload: payloadFromJson };
  const uuidFromJson = parseUuidFromObject(parsedJson);
  if (uuidFromJson)
    return { kind: "foundry-item", uuid: uuidFromJson };
  const plain = dataTransfer.getData("text/plain"), uuid = parseUuidFromText(plain);
  return uuid ? { kind: "foundry-item", uuid } : null;
}
__name(parseTurnPrepDragData, "parseTurnPrepDragData");
function normalizeActivationTypes(values) {
  const set2 = /* @__PURE__ */ new Set();
  for (const value of values ?? []) {
    const normalized = normalizeSingleActivation(value);
    normalized && set2.add(normalized);
  }
  return set2;
}
__name(normalizeActivationTypes, "normalizeActivationTypes");
function normalizeSingleActivation(value) {
  const trimmed = normalizeActionType(value).trim();
  return trimmed ? trimmed === "bonus action" ? "bonus" : trimmed : null;
}
__name(normalizeSingleActivation, "normalizeSingleActivation");
function getRequiredActivationForTable(table) {
  return {
    actions: "action",
    bonusActions: "bonus",
    reactions: "reaction",
    reactionFeatures: "reaction",
    additionalFeatures: null
  }[table] ?? null;
}
__name(getRequiredActivationForTable, "getRequiredActivationForTable");
function clampIndex(index2, length) {
  if (length <= 1) return 0;
  const max = length - 1;
  return index2 < 0 ? 0 : index2 > max ? max : Math.floor(index2);
}
__name(clampIndex, "clampIndex");
function buildActorItemUuid(actorId, itemId) {
  return !actorId || !itemId ? null : `Actor.${actorId}.Item.${itemId}`;
}
__name(buildActorItemUuid, "buildActorItemUuid");
function parseTurnPrepPayload(serialized) {
  if (!serialized) return null;
  const parsed = parseJson(serialized);
  return parseTurnPrepPayloadFromObject(parsed);
}
__name(parseTurnPrepPayload, "parseTurnPrepPayload");
function parseTurnPrepPayloadFromObject(value) {
  if (!value || typeof value != "object") return null;
  const payload = value;
  return payload.kind !== "turn-prep-feature" || !payload.feature?.itemId || !payload.actorId ? null : payload;
}
__name(parseTurnPrepPayloadFromObject, "parseTurnPrepPayloadFromObject");
function parseUuidFromObject(value) {
  const candidate = value?.uuid ?? value?.data?.uuid;
  return typeof candidate == "string" && candidate.trim().length ? candidate.trim() : null;
}
__name(parseUuidFromObject, "parseUuidFromObject");
function parseUuidFromText(value) {
  if (!value || typeof value != "string") return null;
  const trimmed = value.trim();
  if (!trimmed) return null;
  const parsedJson = parseJson(trimmed), uuidFromJson = parseUuidFromObject(parsedJson);
  return uuidFromJson || (UUID_FALLBACK_PATTERN.test(trimmed) ? trimmed : null);
}
__name(parseUuidFromText, "parseUuidFromText");
function parseJson(value) {
  if (typeof value != "string" || !value.trim().length) return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}
__name(parseJson, "parseJson");
function cloneSelectedFeature(feature) {
  return feature ? {
    itemId: feature.itemId,
    itemName: feature.itemName,
    itemType: feature.itemType,
    actionType: feature.actionType
  } : null;
}
__name(cloneSelectedFeature, "cloneSelectedFeature");
function cloneSelectedFeatureArray(features) {
  return Array.isArray(features) ? features.map((feature) => cloneSelectedFeature(feature)).filter((feature) => !!feature) : [];
}
__name(cloneSelectedFeatureArray, "cloneSelectedFeatureArray");
function mergeSelectedFeatureArrays(arrayValue, legacyValue) {
  const merged = cloneSelectedFeatureArray(arrayValue), legacy = cloneSelectedFeature(legacyValue);
  return legacy && merged.push(legacy), merged;
}
__name(mergeSelectedFeatureArrays, "mergeSelectedFeatureArrays");
function normalizeActionType(value) {
  return (value || "").toLowerCase();
}
__name(normalizeActionType, "normalizeActionType");
function buildDisplayFeatureList(actor, ownerId, list, keyPrefix) {
  return list.map((feature, index2) => buildDisplayFeature(actor, ownerId, feature, `${keyPrefix}-${index2}`)).filter((feature) => !!feature);
}
__name(buildDisplayFeatureList, "buildDisplayFeatureList");
function buildDisplayFeature(actor, ownerId, feature, keySuffix) {
  if (!feature?.itemId) return null;
  const rowKey = `${ownerId}-${keySuffix}-${feature.itemId}`, item = actor?.items?.get?.(feature.itemId);
  if (!item)
    return {
      ...feature,
      rowKey,
      icon: null,
      usesValue: null,
      usesMax: null,
      rollLabel: null,
      formula: null,
      range: null,
      target: null,
      summary: FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.MissingItemDetails"),
      tags: [FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.MissingItem")],
      isMissing: !0,
      activities: [],
      descriptionHtml: null,
      descriptionRollData: null,
      damageEntries: []
    };
  const system = item.system ?? {}, rawActivities = FeatureSelector.getActivitiesForItem(item) ?? [], activityDisplays = buildActivityList(item, rawActivities, rowKey), { usesValue, usesMax } = resolveFeatureUses(system, rawActivities), rollMeta = resolveRollMeta(item, rawActivities), rollLabel = rollMeta?.label ?? null, rollDisplay = rollMeta ?? null, formula = resolveFormula(system, rawActivities, item), range = resolveRange(system?.range, rawActivities), target = resolveTarget(item, rawActivities), damageEntries = resolveDamageEntries(item, rawActivities), descriptionHtml = extractDescriptionHtml(system?.description), descriptionRollData = item?.actor?.getRollData?.() ?? item?.getRollData?.() ?? null;
  return {
    ...feature,
    rowKey,
    itemName: item.name ?? feature.itemName,
    itemType: item.type ?? feature.itemType,
    icon: item.img ?? null,
    usesValue,
    usesMax,
    rollLabel,
    rollDisplay,
    formula,
    range,
    target,
    damageEntries,
    descriptionHtml,
    descriptionRollData,
    summary: formatSummary(system?.description),
    tags: buildTagList(feature, item, system),
    isMissing: !1,
    activities: activityDisplays
  };
}
__name(buildDisplayFeature, "buildDisplayFeature");
function buildActivityList(item, activities, rowKey) {
  return activities?.length ? activities.map((activity, index2) => formatDisplayActivity(item, activity, rowKey, index2)).filter((activity) => !!activity) : [];
}
__name(buildActivityList, "buildActivityList");
function formatDisplayActivity(item, activity, rowKey, index2) {
  if (!activity)
    return null;
  const rawId = activity.id ?? activity._id ?? index2, activityId = String(rawId), name = activity.name ?? item?.name ?? FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Feature"), { usesValue, usesMax } = resolveActivityUses(activity, item);
  return {
    activityId,
    rowKey: `${rowKey}-activity-${activityId}`,
    name,
    icon: activity.img ?? item?.img ?? null,
    usesValue,
    usesMax,
    timeLabel: formatActivityTime(activity),
    formula: formatFormula(activity, item),
    damageEntries: formatDamageEntries(activity)
  };
}
__name(formatDisplayActivity, "formatDisplayActivity");
function resolveActivityUses(activity, item) {
  const useType = getActivityUseSource(activity);
  return useType === "itemUses" ? {
    usesValue: formatUsesValue(item?.system),
    usesMax: formatUsesMax(item?.system)
  } : useType === "activityUses" ? {
    usesValue: formatUsesValue(activity),
    usesMax: formatUsesMax(activity)
  } : {
    usesValue: formatUsesValue(activity),
    usesMax: formatUsesMax(activity)
  };
}
__name(resolveActivityUses, "resolveActivityUses");
function getActivityUseSource(activity) {
  const targets = activity?.consumption?.targets;
  return Array.isArray(targets) ? targets.find(
    (entry) => entry?.type === "itemUses" || entry?.type === "activityUses"
  )?.type ?? null : null;
}
__name(getActivityUseSource, "getActivityUseSource");
function resolveFeatureUses(system, activities) {
  let usesValue = formatUsesValue(system), usesMax = formatUsesMax(system);
  if (!hasDisplayValue(usesValue) && !hasDisplayValue(usesMax)) {
    const activityWithUses = activities?.find((activity) => hasDisplayValue(formatUsesMax(activity)));
    activityWithUses && (usesValue = formatUsesValue(activityWithUses), usesMax = formatUsesMax(activityWithUses));
  }
  return { usesValue, usesMax };
}
__name(resolveFeatureUses, "resolveFeatureUses");
function resolveRollMeta(item, activities) {
  const direct = formatRollDisplay(item);
  return direct || selectFromActivities(activities, (activity) => formatActivityRollDisplay(activity));
}
__name(resolveRollMeta, "resolveRollMeta");
function resolveFormula(source2, activities, item) {
  const direct = formatFormula(source2, item);
  return hasDisplayValue(direct) ? direct : selectFromActivities(activities, (activity) => formatFormula(activity, item));
}
__name(resolveFormula, "resolveFormula");
function resolveRange(range, activities) {
  const direct = formatRange(range);
  return hasDisplayValue(direct) ? direct : selectFromActivities(
    activities,
    (activity) => formatRange(activity?.range ?? activity?.system?.range)
  );
}
__name(resolveRange, "resolveRange");
function resolveTarget(item, activities) {
  const labelTarget = formatLabelsTarget(item, activities);
  if (hasDisplayValue(labelTarget))
    return labelTarget;
  const direct = formatTarget(item?.system?.target);
  return hasDisplayValue(direct) ? direct : selectFromActivities(
    activities,
    (activity) => formatTarget(activity?.target ?? activity?.system?.target)
  );
}
__name(resolveTarget, "resolveTarget");
function formatLabelsTarget(item, activities) {
  const labels = item?.labels;
  if (!labels)
    return null;
  const activationTargets = collectActivationTargets(labels, activities);
  if (activationTargets.length > 1)
    return activationTargets.join(" / ");
  if (activationTargets.length === 1)
    return labels?.target ?? activationTargets[0];
  const singleTarget = labels?.target;
  return hasDisplayValue(singleTarget) ? singleTarget : null;
}
__name(formatLabelsTarget, "formatLabelsTarget");
function collectActivationTargets(labels, activities) {
  const activationLabels = labels?.activations;
  if (!activationLabels)
    return [];
  const targets = [], seen = /* @__PURE__ */ new Set(), addTarget = /* @__PURE__ */ __name((value) => {
    if (typeof value != "string") return;
    const trimmed = value.trim();
    !trimmed || seen.has(trimmed) || (seen.add(trimmed), targets.push(trimmed));
  }, "addTarget");
  if (Array.isArray(activationLabels)) {
    for (const entry of activationLabels)
      addTarget(entry?.target);
    return targets;
  }
  if (typeof activationLabels == "object")
    if (Array.isArray(activities) && activities.length)
      for (const activity of activities) {
        const key = activity?.id ?? activity?._id;
        if (!key) continue;
        const activationEntry = activationLabels[key];
        addTarget(activationEntry?.target);
      }
    else
      for (const entry of Object.values(activationLabels))
        addTarget(entry?.target);
  return targets;
}
__name(collectActivationTargets, "collectActivationTargets");
function resolveDamageEntries(item, activities) {
  const direct = formatDamageEntries(item);
  return direct.length ? direct : selectFromActivities(activities, (activity) => {
    const entries = formatDamageEntries(activity);
    return entries.length ? entries : null;
  }) ?? [];
}
__name(resolveDamageEntries, "resolveDamageEntries");
function selectFromActivities(activities, selector) {
  for (const activity of activities ?? []) {
    const value = selector(activity);
    if (value != null && !(typeof value == "string" && !hasDisplayValue(value)))
      return value;
  }
  return null;
}
__name(selectFromActivities, "selectFromActivities");
function formatDamageEntries(source2) {
  const damages = source2?.labels?.damages;
  return !Array.isArray(damages) || !damages.length ? [] : damages.map((entry) => normalizeDamageEntry(entry)).filter((entry) => !!entry);
}
__name(formatDamageEntries, "formatDamageEntries");
function normalizeDamageEntry(entry) {
  const rawFormula = entry?.formula ?? entry?.value;
  if (!hasDisplayValue(rawFormula))
    return null;
  const formula = String(rawFormula).trim();
  if (!formula.length)
    return null;
  const damageType = extractDamageType(entry), typeLabel = damageType ? capitalizeDamageType(damageType) : null;
  return {
    formula,
    type: typeLabel,
    icon: getDamageIconPath(damageType),
    ariaLabel: typeLabel ? `${formula} ${typeLabel}` : formula
  };
}
__name(normalizeDamageEntry, "normalizeDamageEntry");
function extractDamageType(entry) {
  const type = entry?.damageType ?? entry?.type ?? entry?.types;
  if (typeof type == "string") {
    const trimmed = type.trim();
    return trimmed ? trimmed.toLowerCase() : null;
  }
  if (Array.isArray(type)) {
    const found = type.find((value) => typeof value == "string" && value.trim().length);
    return found ? found.trim().toLowerCase() : null;
  }
  return null;
}
__name(extractDamageType, "extractDamageType");
function getDamageIconPath(type) {
  return type ? `${DAMAGE_ICON_BASE_PATH}/${type}.svg` : null;
}
__name(getDamageIconPath, "getDamageIconPath");
function capitalizeDamageType(type) {
  return type && type.split(/[-\s]/).filter(Boolean).map((segment) => capitalize(segment)).join(" ");
}
__name(capitalizeDamageType, "capitalizeDamageType");
function formatActivityRollDisplay(activity) {
  const labels = activity?.labels;
  if (hasDisplayValue(labels?.toHit))
    return { value: labels.toHit };
  if (labels?.attack)
    return { label: labels.attack };
  const save = activity?.save ?? labels?.save;
  if (save) {
    const ability = extractAbilityAbbreviation(save?.ability ?? labels?.save?.ability), dcValue = extractDcValue(save?.dc ?? labels?.save?.dc, labels?.save);
    if (ability || dcValue)
      return {
        ability,
        value: dcValue,
        label: typeof labels?.save == "string" ? labels.save : null
      };
  }
  return null;
}
__name(formatActivityRollDisplay, "formatActivityRollDisplay");
function extractAbilityAbbreviation(value) {
  if (!value) return null;
  if (typeof value == "string")
    return value.toUpperCase();
  if (Array.isArray(value) && value.length)
    return value.map((entry) => String(entry).toUpperCase()).join("/");
  if (typeof value?.first == "function") {
    const first = value.first();
    return typeof first == "string" ? first.toUpperCase() : null;
  }
  return null;
}
__name(extractAbilityAbbreviation, "extractAbilityAbbreviation");
function extractDcValue(dc, fallbackLabel) {
  if (typeof dc == "number" || typeof dc == "string")
    return dc;
  if (typeof dc?.value == "number" || typeof dc?.value == "string")
    return dc.value;
  if (typeof fallbackLabel == "string") {
    const match = fallbackLabel.match(/(\d+)/);
    return match ? match[1] : null;
  }
  return null;
}
__name(extractDcValue, "extractDcValue");
function hasDisplayValue(value) {
  return !(value == null || value === "");
}
__name(hasDisplayValue, "hasDisplayValue");
function formatActivityTime(activity) {
  const activation = activity?.activation;
  if (!activation?.type)
    return null;
  const typeLabel = capitalize(activation.type), cost = typeof activation.cost == "number" ? activation.cost : typeof activation.value == "number" ? activation.value : null;
  return cost && cost > 1 ? `${cost} ${typeLabel}` : typeLabel;
}
__name(formatActivityTime, "formatActivityTime");
function formatUsesValue(system) {
  const uses = system?.uses;
  return uses && (typeof uses.value == "number" || typeof uses.value == "string") ? uses.value : null;
}
__name(formatUsesValue, "formatUsesValue");
function formatUsesMax(system) {
  const uses = system?.uses;
  return uses && (typeof uses.max == "number" || typeof uses.max == "string") ? uses.max : null;
}
__name(formatUsesMax, "formatUsesMax");
function extractDamageFormula(part, item) {
  return part ? typeof part == "string" ? resolveFormulaVariables(part, item) : part?.formula ? resolveFormulaVariables(part.formula, item) : part?.custom?.formula ? resolveFormulaVariables(part.custom.formula, item) : Array.isArray(part) && part.length ? resolveFormulaVariables(part[0], item) : null : null;
}
__name(extractDamageFormula, "extractDamageFormula");
function resolveFormulaVariables(formula, item) {
  if (!formula || typeof formula != "string" || !formula.includes("@"))
    return formula;
  try {
    const rollData = item?.actor?.getRollData?.() ?? item?.getRollData?.(), RollClass = globalThis?.Roll;
    return !rollData || typeof RollClass?.replaceFormulaData != "function" ? formula : RollClass.replaceFormulaData(formula, rollData);
  } catch (error2) {
    return console.warn("[TurnPrep] Failed to resolve formula variables", error2), formula;
  }
}
__name(resolveFormulaVariables, "resolveFormulaVariables");
function formatRollDisplay(item) {
  const labels = item?.labels;
  if (hasDisplayValue(labels?.toHit))
    return { value: labels.toHit };
  if (labels?.attack)
    return { label: labels.attack };
  const save = item?.system?.save ?? labels?.save;
  if (save) {
    const ability = extractAbilityAbbreviation(save?.ability ?? labels?.save?.ability), value = extractDcValue(save?.dc ?? labels?.save?.dc, labels?.save);
    if (ability || value)
      return {
        ability,
        value,
        label: typeof labels?.save == "string" ? labels.save : null
      };
  }
  return null;
}
__name(formatRollDisplay, "formatRollDisplay");
function formatFormula(system, item) {
  const parts = system?.damage?.parts ?? system?.damageParts;
  if (Array.isArray(parts) && parts.length) {
    const formulas = parts.map((part) => Array.isArray(part) ? part[0] : part).map((entry) => extractDamageFormula(entry, item)).filter((entry) => typeof entry == "string" && entry.trim().length > 0);
    if (formulas.length)
      return formulas.join(" + ");
  }
  return typeof system?.formula == "string" && system.formula.trim().length ? resolveFormulaVariables(system.formula.trim(), item) : null;
}
__name(formatFormula, "formatFormula");
function formatRange(range) {
  if (!range) return null;
  if (typeof range == "string")
    return normalizeRangeOutput(range);
  const shortValue = getNumericRangeValue(range.short ?? range.value), longValue = getNumericRangeValue(range.long);
  let distanceLabel = null;
  shortValue !== null && longValue !== null ? distanceLabel = `${shortValue} / ${longValue}` : shortValue !== null ? distanceLabel = `${shortValue}` : typeof range.value == "string" && range.value.trim().length && (distanceLabel = range.value.trim());
  const units = formatRangeUnits(range.units), output = [distanceLabel, units].filter(Boolean).join(" ").trim();
  return normalizeRangeOutput(output);
}
__name(formatRange, "formatRange");
function getNumericRangeValue(value) {
  return typeof value == "number" ? value : null;
}
__name(getNumericRangeValue, "getNumericRangeValue");
function formatRangeUnits(units) {
  if (typeof units != "string") return "";
  const trimmed = units.trim();
  if (!trimmed || trimmed.toLowerCase() === "self")
    return "";
  const normalized = trimmed.toLowerCase();
  return {
    ft: "ft.",
    mi: "mi.",
    m: "m",
    km: "km"
  }[normalized] ?? trimmed;
}
__name(formatRangeUnits, "formatRangeUnits");
function normalizeRangeOutput(value) {
  if (!value) return null;
  const trimmed = value.trim();
  return !trimmed || trimmed.toLowerCase() === "self" ? null : trimmed;
}
__name(normalizeRangeOutput, "normalizeRangeOutput");
function formatTarget(target) {
  if (!target) return null;
  const template = target.template || target.shape;
  if (template) {
    const pieces = [], size = template.size ?? template.value;
    if (size) {
      const units = template.units ? `${template.units}` : "";
      pieces.push(`${size}${units ? ` ${units}` : ""}`);
    }
    return template.type && pieces.push(capitalize(template.type)), template.width && template.type === "line" && pieces.push(`${template.width} ft wide`), pieces.length ? pieces.join(" ").trim() : null;
  }
  const parts = [];
  return target.value && parts.push(String(target.value)), target.units && parts.push(capitalize(target.units)), target.type && parts.push(capitalize(target.type)), parts.length ? parts.join(" ") : null;
}
__name(formatTarget, "formatTarget");
function extractDescriptionHtml(description) {
  const raw = typeof description == "string" ? description : description?.value;
  if (typeof raw != "string") return null;
  const trimmed = raw.trim();
  return trimmed.length ? trimmed : null;
}
__name(extractDescriptionHtml, "extractDescriptionHtml");
function formatSummary(description) {
  const raw = typeof description == "string" ? description : description?.value;
  if (typeof raw != "string") return null;
  const text = stripHtml(raw);
  return text ? text.length > 320 ? `${text.slice(0, 317)}...` : text : null;
}
__name(formatSummary, "formatSummary");
function stripHtml(value) {
  return value.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}
__name(stripHtml, "stripHtml");
function buildTagList(feature, item, system) {
  const tags = /* @__PURE__ */ new Set(), actionType = normalizeActionType(feature.actionType);
  actionType && tags.add(capitalize(actionType)), item?.type && tags.add(capitalize(item.type));
  const activation = system?.activation?.type;
  return activation && tags.add(capitalize(activation)), system?.school?.abbr && tags.add(system.school.abbr.toUpperCase()), Array.from(tags).filter(Boolean);
}
__name(buildTagList, "buildTagList");
function capitalize(value) {
  return value && value.charAt(0).toUpperCase() + value.slice(1);
}
__name(capitalize, "capitalize");
var root_1$4 = /* @__PURE__ */ from_html('<div class="tidy-table-row-container empty svelte-tp-1nnogk2" role="presentation"><div class="tidy-table-row"><div class="tidy-table-cell primary" style="grid-column: span 8; justify-content: center;"> </div></div></div>'), root_4$3 = /* @__PURE__ */ from_html('<input type="text" class="uninput uses-value svelte-tp-1nnogk2" readonly=""/> <span class="divider">/</span> <span class="uses-max"> </span>', 1), root_5$2 = /* @__PURE__ */ from_html('<span class="color-text-disabled">—</span>'), root_7$3 = /* @__PURE__ */ from_html('<span class="ability uppercase color-text-gold-emphasis font-label-medium"> </span>'), root_8$3 = /* @__PURE__ */ from_html('<span class="value font-label-medium"> </span>'), root_6$1 = /* @__PURE__ */ from_html('<div class="stacked roll-display svelte-tp-1nnogk2"><!> <!></div>'), root_9$2 = /* @__PURE__ */ from_html("<span> </span>"), root_12$3 = /* @__PURE__ */ from_html('<span class="damage-icon svelte-tp-1nnogk2"><dnd5e-icon></dnd5e-icon></span>', 2), root_14$1 = /* @__PURE__ */ from_html('<span class="damage-type-label svelte-tp-1nnogk2"> </span>'), root_11$3 = /* @__PURE__ */ from_html('<div class="damage-formula-container svelte-tp-1nnogk2"><span class="damage-formula truncate svelte-tp-1nnogk2"> </span> <!></div>'), root_10$3 = /* @__PURE__ */ from_html('<div class="damage-list svelte-tp-1nnogk2"></div>'), root_15 = /* @__PURE__ */ from_html("<span> </span>"), root_18 = /* @__PURE__ */ from_html('<input type="text" class="uninput uses-value svelte-tp-1nnogk2" readonly=""/> <span class="divider">/</span> <span class="uses-max"> </span>', 1), root_19 = /* @__PURE__ */ from_html('<span class="color-text-disabled">—</span>'), root_22 = /* @__PURE__ */ from_html('<span class="damage-icon svelte-tp-1nnogk2"><dnd5e-icon></dnd5e-icon></span>', 2), root_24 = /* @__PURE__ */ from_html('<span class="damage-type-label svelte-tp-1nnogk2"> </span>'), root_21 = /* @__PURE__ */ from_html('<div class="damage-formula-container svelte-tp-1nnogk2"><span class="damage-formula truncate svelte-tp-1nnogk2"> </span> <!></div>'), root_20 = /* @__PURE__ */ from_html('<div class="damage-list svelte-tp-1nnogk2"></div>'), root_25 = /* @__PURE__ */ from_html("<span> </span>"), root_17 = /* @__PURE__ */ from_html('<div class="tidy-table-row-container"><div class="tidy-table-row tidy-table-row-v2 activity svelte-tp-1nnogk2"><button type="button" class="tidy-table-row-use-button svelte-tp-1nnogk2"><img class="item-image"/> <span class="roll-prompt"><i class="fa fa-dice-d20"></i></span></button> <div class="tidy-table-cell item-label text-cell primary svelte-tp-1nnogk2"><span class="item-name svelte-tp-1nnogk2"><span class="cell-text"><span class="cell-name"> </span></span></span></div> <div class="tidy-table-cell inline-uses svelte-tp-1nnogk2" data-tidy-column-key="uses"><!></div> <div class="tidy-table-cell" data-tidy-column-key="time"><span> </span></div> <div class="tidy-table-cell" data-tidy-column-key="formula"><!></div> <div class="tidy-table-cell tidy-table-actions" data-tidy-column-key="actions"><button type="button" class="tidy-table-button svelte-tp-1nnogk2"><i class="fa-solid fa-ellipsis-vertical"></i></button></div></div></div>'), root_16 = /* @__PURE__ */ from_html('<section class="tidy-table inline-activities-table svelte-tp-1nnogk2"><header class="tidy-table-header-row theme-dark svelte-tp-1nnogk2" data-tidy-sheet-part="table-header-row"><div class="tidy-table-header-cell header-label-cell primary"><h3 class="svelte-tp-1nnogk2"> </h3> <span class="table-header-count"> </span></div> <div class="tidy-table-header-cell"> </div> <div class="tidy-table-header-cell"> </div> <div class="tidy-table-header-cell"> </div> <div class="tidy-table-header-cell">&nbsp;</div></header> <div class="expandable expanded" role="presentation"><div role="presentation" class="expandable-child-animation-wrapper"><div class="item-table-body"></div></div></div></section>'), root_26 = /* @__PURE__ */ from_html('<div class="feature-description rich-text svelte-tp-1nnogk2"><!></div>'), root_27 = /* @__PURE__ */ from_html("<p> </p>"), root_28 = /* @__PURE__ */ from_html('<span class="tag"><span class="value"> </span></span>'), root_3$4 = /* @__PURE__ */ from_html('<div class="tidy-table-row-container" draggable="true" role="button" tabindex="-1" aria-haspopup="menu"><div><button type="button" class="tidy-table-row-use-button svelte-tp-1nnogk2"><img class="item-image"/> <span class="roll-prompt"><i class="fa fa-dice-d20"></i></span></button> <div class="tidy-table-cell item-label text-cell primary svelte-tp-1nnogk2" data-tidy-column-key="feature"><button type="button" class="item-name svelte-tp-1nnogk2"><span class="cell-text"><span class="cell-name"> </span></span> <span class="row-detail-expand-indicator"><i></i></span></button></div> <div class="tidy-table-cell inline-uses svelte-tp-1nnogk2" data-tidy-column-key="uses"><!></div> <div class="tidy-table-cell" data-tidy-column-key="roll"><!></div> <div class="tidy-table-cell" data-tidy-column-key="formula"><!></div> <div class="tidy-table-cell" data-tidy-column-key="range"><span> </span></div> <div class="tidy-table-cell" data-tidy-column-key="target"><span> </span></div> <div class="tidy-table-cell tidy-table-actions svelte-tp-1nnogk2" data-tidy-column-key="actions"><button type="button" aria-haspopup="menu"><i class="fa-solid fa-ellipsis-vertical"></i></button></div></div> <div role="presentation"><div role="presentation" class="expandable-child-animation-wrapper"><div class="feature-row-details svelte-tp-1nnogk2"><!> <div class="editor-rendered-content"><!> <div class="item-property-tags"></div> <div class="tidy-table-summary-actions svelte-tp-1nnogk2"><button type="button" class="svelte-tp-1nnogk2"><i class="fa-solid fa-message-arrow-up-right"></i> </button> <button type="button" class="svelte-tp-1nnogk2"><i class="fas fa-dice-d20"></i> </button></div></div></div></div></div></div>'), root$4 = /* @__PURE__ */ from_html('<section class="tidy-table turn-plan-feature-table svelte-tp-1nnogk2"><header class="tidy-table-header-row toggleable svelte-tp-1nnogk2" data-tidy-sheet-part="table-header-row" role="button" tabindex="0"><div class="tidy-table-header-cell icon-column" aria-hidden="true"></div> <div class="tidy-table-header-cell header-label-cell primary"><div><i class="fa-solid fa-chevron-right"></i></div> <h3 style="color: var(--t5e-color-palette-white, #f0f0f0);" class="svelte-tp-1nnogk2"> </h3> <span class="table-header-count"> </span></div> <div class="tidy-table-header-cell" data-tidy-column-key="uses"> </div> <div class="tidy-table-header-cell" data-tidy-column-key="roll"> </div> <div class="tidy-table-header-cell" data-tidy-column-key="formula"> </div> <div class="tidy-table-header-cell" data-tidy-column-key="range"> </div> <div class="tidy-table-header-cell" data-tidy-column-key="target"> </div> <div class="tidy-table-header-cell header-cell-actions" data-tidy-column-key="actions">&nbsp;</div></header> <div role="presentation"><div role="presentation" class="expandable-child-animation-wrapper"><div class="item-table-body" role="list"><!></div></div></div></section> <!>', 1);
function TurnPlanFeatureTable($$anchor, $$props) {
  push($$props, !0);
  const columnWidths = {
    icon: "2.25rem",
    feature: "minmax(0, 1fr)",
    uses: "5rem",
    roll: "3.125rem",
    formula: "5rem",
    range: "5rem",
    target: "5rem",
    actions: "1.6875rem"
  }, templateColumns = [
    columnWidths.icon,
    columnWidths.feature,
    columnWidths.uses,
    columnWidths.roll,
    columnWidths.formula,
    columnWidths.range,
    columnWidths.target,
    columnWidths.actions
  ].join(" "), activityColumnWidths = {
    icon: columnWidths.icon,
    name: columnWidths.feature,
    uses: columnWidths.uses,
    time: columnWidths.roll,
    formula: columnWidths.formula,
    actions: columnWidths.actions
  }, activityTemplateColumns = [
    activityColumnWidths.icon,
    activityColumnWidths.name,
    activityColumnWidths.uses,
    activityColumnWidths.time,
    activityColumnWidths.formula,
    activityColumnWidths.actions
  ].join(" "), defaultIcon = "icons/svg/book.svg";
  let actor = prop($$props, "actor", 3, null), features = prop($$props, "features", 19, () => []), emptyMessage = prop($$props, "emptyMessage", 19, () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Empty")), onRemoveFeature = prop($$props, "onRemoveFeature", 3, () => {
  }), ownerId = prop($$props, "ownerId", 3, void 0), panelKind = prop($$props, "panelKind", 3, "turn"), tableType = prop($$props, "tableType", 3, void 0), onFeatureDrop = prop($$props, "onFeatureDrop", 3, void 0), onReorderFeature = prop($$props, "onReorderFeature", 3, void 0), buildMoveToMenu = prop($$props, "buildMoveToMenu", 3, void 0), buildCopyToMenu = prop($$props, "buildCopyToMenu", 3, void 0), expanded = /* @__PURE__ */ state(!0), rowStates = /* @__PURE__ */ state(proxy({})), descriptionCache = /* @__PURE__ */ state(proxy({}));
  const pendingDescriptions = /* @__PURE__ */ new Set(), featureContextMenu = new ContextMenuController("turn-plan-feature-table");
  let activeContextRowKey = /* @__PURE__ */ state(null), dragOverIndex = /* @__PURE__ */ state(null), draggingRowKey = /* @__PURE__ */ state(null);
  onMount(() => {
    const unsubscribe = featureContextMenu.subscribe((state2) => {
      set(activeContextRowKey, state2?.context?.rowKey ?? null, !0);
    });
    return () => unsubscribe();
  }), user_effect(() => {
    const validIds = new Set(features().map((feature) => feature.rowKey));
    let changed = !1;
    const nextStates = { ...get$1(rowStates) };
    for (const id of Object.keys(nextStates))
      validIds.has(id) || (delete nextStates[id], changed = !0);
    changed && set(rowStates, nextStates, !0);
    const cacheKeys = Object.keys(get$1(descriptionCache));
    if (cacheKeys.some((key) => !validIds.has(key))) {
      const nextCache = {};
      for (const key of cacheKeys)
        validIds.has(key) && (nextCache[key] = get$1(descriptionCache)[key]);
      set(descriptionCache, nextCache, !0);
    }
    for (const feature of features())
      feature.descriptionHtml && (get$1(descriptionCache)[feature.rowKey] || pendingDescriptions.has(feature.rowKey) || (pendingDescriptions.add(feature.rowKey), hydrateDescription(feature)));
  });
  async function hydrateDescription(feature) {
    try {
      const html2 = await FoundryAdapter.enrichHtml(feature.descriptionHtml ?? "", { rollData: feature.descriptionRollData ?? void 0 });
      if (!html2 || !features().find((entry) => entry.rowKey === feature.rowKey))
        return;
      set(descriptionCache, { ...get$1(descriptionCache), [feature.rowKey]: html2 }, !0);
    } catch (error2) {
      console.warn("[TurnPlanFeatureTable] Failed to enrich description", error2);
    } finally {
      pendingDescriptions.delete(feature.rowKey);
    }
  }
  __name(hydrateDescription, "hydrateDescription");
  function toggleTable() {
    set(expanded, !get$1(expanded));
  }
  __name(toggleTable, "toggleTable");
  function handleHeaderKey(event2) {
    (event2.key === "Enter" || event2.key === " ") && (event2.preventDefault(), toggleTable());
  }
  __name(handleHeaderKey, "handleHeaderKey");
  function toggleRow(rowKey) {
    set(rowStates, { ...get$1(rowStates), [rowKey]: !get$1(rowStates)[rowKey] }, !0);
  }
  __name(toggleRow, "toggleRow");
  function formatValue(value) {
    return value == null || value === "" ? "—" : value;
  }
  __name(formatValue, "formatValue");
  function getTags(feature) {
    const tags = feature.tags ?? [];
    return tags.length ? tags : [feature.itemType, feature.actionType].filter(Boolean);
  }
  __name(getTags, "getTags");
  const noDetails = FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.NoDetails");
  function hasLimitedUses(entry) {
    return entry?.usesMax !== void 0 && entry?.usesMax !== null && entry?.usesMax !== "";
  }
  __name(hasLimitedUses, "hasLimitedUses");
  function handlePendingActionsClick(event2) {
    event2?.preventDefault(), event2?.stopPropagation(), ui.notifications?.info(FoundryAdapter.localize("TURN_PREP.Messages.NotImplemented"));
  }
  __name(handlePendingActionsClick, "handlePendingActionsClick");
  function getFeatureItem(feature) {
    return FoundryAdapter.getItemFromActor(actor(), feature?.itemId);
  }
  __name(getFeatureItem, "getFeatureItem");
  function getActorId() {
    const actorId = actor()?.id ?? actor()?._id ?? actor()?.document?.id ?? actor()?.document?._id;
    return typeof actorId == "string" ? actorId : null;
  }
  __name(getActorId, "getActorId");
  function deriveTableTypeFromKey(key) {
    const lower = (key ?? "").toLowerCase();
    return lower.startsWith("action") ? "actions" : lower.startsWith("bonus") ? "bonusActions" : lower.startsWith("reaction") ? panelKind() === "reaction" ? "reactionFeatures" : "reactions" : "additionalFeatures";
  }
  __name(deriveTableTypeFromKey, "deriveTableTypeFromKey");
  function getEffectiveTableType() {
    return tableType() ?? deriveTableTypeFromKey($$props.tableKey);
  }
  __name(getEffectiveTableType, "getEffectiveTableType");
  function notifyWarning2(key, data) {
    const message = data ? FoundryAdapter.localizeFormat(key, data) : FoundryAdapter.localize(key);
    ui.notifications?.warn(message);
  }
  __name(notifyWarning2, "notifyWarning");
  function ensureFeatureItem(feature) {
    const item = getFeatureItem(feature);
    return item || (notifyWarning2("TURN_PREP.TurnPlans.Messages.ItemUnavailable"), null);
  }
  __name(ensureFeatureItem, "ensureFeatureItem");
  function notifyDuplicateFeature() {
    ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.DuplicateFeature") || "Feature already exists in this table.");
  }
  __name(notifyDuplicateFeature, "notifyDuplicateFeature");
  function notifyActorMismatch() {
    ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.ActorMismatch") || "Cannot move features between different actors.");
  }
  __name(notifyActorMismatch, "notifyActorMismatch");
  function openFeatureSheet(feature, editable) {
    const item = ensureFeatureItem(feature);
    item && FoundryAdapter.openItemSheet(item, { editable });
  }
  __name(openFeatureSheet, "openFeatureSheet");
  async function displayFeatureInChat(feature) {
    const item = ensureFeatureItem(feature);
    item && await FoundryAdapter.displayItemInChat(item);
  }
  __name(displayFeatureInChat, "displayFeatureInChat");
  function removeFeatureFromPlan(feature) {
    !feature?.itemId || typeof onRemoveFeature() != "function" || onRemoveFeature()(feature.itemId);
  }
  __name(removeFeatureFromPlan, "removeFeatureFromPlan");
  function getFeatureContextMenuActions(feature) {
    const index2 = features().findIndex((entry) => entry.rowKey === feature.rowKey), total = Array.isArray(features()) ? features().length : 0, canReorder = typeof onReorderFeature() == "function" && total > 0 && index2 >= 0, reorderActions = [];
    canReorder && reorderActions.push(
      {
        id: "move-up",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveUp") || "Move Up",
        icon: "fa-solid fa-angle-up",
        onSelect: /* @__PURE__ */ __name(() => onReorderFeature()?.(index2, Math.max(0, index2 - 1)), "onSelect")
      },
      {
        id: "move-down",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveDown") || "Move Down",
        icon: "fa-solid fa-angle-down",
        onSelect: /* @__PURE__ */ __name(() => onReorderFeature()?.(index2, Math.min(total - 1, index2 + 1)), "onSelect")
      },
      {
        id: "move-top",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveTop") || "Move to Top",
        icon: "fa-solid fa-angles-up",
        onSelect: /* @__PURE__ */ __name(() => onReorderFeature()?.(index2, 0), "onSelect")
      },
      {
        id: "move-bottom",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveBottom") || "Move to Bottom",
        icon: "fa-solid fa-angles-down",
        onSelect: /* @__PURE__ */ __name(() => onReorderFeature()?.(index2, total - 1), "onSelect")
      }
    );
    const moveToSubmenu = buildMoveToMenu()?.(feature) ?? [], copyToSubmenu = buildCopyToMenu()?.(feature) ?? [], arrangeSubmenu = reorderActions.length ? [{ id: `${feature.rowKey}-reorder`, actions: reorderActions }] : [], moveCopyActions = [];
    return moveToSubmenu.length && moveCopyActions.push({
      id: "move-to",
      label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveTo") || "Move To",
      icon: "fa-solid fa-up-right-from-square",
      submenu: moveToSubmenu,
      onSelect: /* @__PURE__ */ __name(() => {
      }, "onSelect")
    }), copyToSubmenu.length && moveCopyActions.push({
      id: "copy-to",
      label: FoundryAdapter.localize("TURN_PREP.ContextMenu.CopyTo") || "Copy To",
      icon: "fa-regular fa-copy",
      submenu: copyToSubmenu,
      onSelect: /* @__PURE__ */ __name(() => {
      }, "onSelect")
    }), [
      {
        id: "view",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.View"),
        icon: "fa-solid fa-eye",
        onSelect: /* @__PURE__ */ __name(() => openFeatureSheet(feature, !1), "onSelect")
      },
      {
        id: "edit",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.Edit"),
        icon: "fa-solid fa-pen-to-square",
        onSelect: /* @__PURE__ */ __name(() => openFeatureSheet(feature, !0), "onSelect")
      },
      {
        id: "display",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.DisplayInChat"),
        icon: "fa-solid fa-message-arrow-up-right",
        onSelect: /* @__PURE__ */ __name(() => displayFeatureInChat(feature), "onSelect")
      },
      ...moveCopyActions,
      ...arrangeSubmenu.length ? [
        {
          id: "arrange",
          label: FoundryAdapter.localize("TURN_PREP.ContextMenu.Arrange") || "Arrange",
          icon: "fa-solid fa-arrow-up-wide-short",
          submenu: arrangeSubmenu,
          onSelect: /* @__PURE__ */ __name(() => {
          }, "onSelect")
        }
      ] : [],
      {
        id: "remove",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.RemoveFromTurnPrep"),
        icon: "fa-regular fa-hourglass",
        variant: "destructive",
        onSelect: /* @__PURE__ */ __name(() => removeFeatureFromPlan(feature), "onSelect")
      }
    ];
  }
  __name(getFeatureContextMenuActions, "getFeatureContextMenuActions");
  function buildFeatureMenuSections(feature) {
    return [
      {
        id: `${feature.rowKey}-menu`,
        actions: getFeatureContextMenuActions(feature)
      }
    ];
  }
  __name(buildFeatureMenuSections, "buildFeatureMenuSections");
  function openFeatureContextMenu(feature, position, anchorElement) {
    featureContextMenu.open({
      sections: buildFeatureMenuSections(feature),
      position,
      anchorElement: anchorElement ?? null,
      context: {
        rowKey: feature.rowKey,
        featureId: feature.itemId,
        ariaLabel: `${feature.itemName} ${FoundryAdapter.localize("TURN_PREP.Common.Actions")}`
      }
    });
  }
  __name(openFeatureContextMenu, "openFeatureContextMenu");
  function handleDragStart(feature, index2, event2) {
    if (!event2?.dataTransfer) return;
    const actorId = getActorId();
    if (!actorId) return;
    const cloned = cloneSelectedFeature(feature);
    if (!cloned) return;
    const payload = {
      kind: "turn-prep-feature",
      actorId,
      feature: cloned,
      sourcePlanId: panelKind() === "turn" ? ownerId() : void 0,
      sourceReactionId: panelKind() === "reaction" ? ownerId() : void 0,
      sourceTable: getEffectiveTableType(),
      sourceIndex: index2
    };
    setTurnPrepDragData(event2.dataTransfer, payload), event2.dataTransfer.effectAllowed = "copyMove", set(draggingRowKey, feature.rowKey, !0), event2.stopPropagation();
  }
  __name(handleDragStart, "handleDragStart");
  function handleDragOver(event2, index2) {
    event2.preventDefault(), event2.stopPropagation(), event2.dataTransfer && (event2.dataTransfer.dropEffect = event2.shiftKey ? "copy" : "move"), set(dragOverIndex, index2 ?? features().length, !0);
  }
  __name(handleDragOver, "handleDragOver");
  function handleDragEnter(event2, index2) {
    event2.preventDefault(), event2.stopPropagation(), set(dragOverIndex, index2 ?? features().length, !0);
  }
  __name(handleDragEnter, "handleDragEnter");
  function handleDragLeave(event2) {
    event2.stopPropagation(), set(dragOverIndex, null);
  }
  __name(handleDragLeave, "handleDragLeave");
  function clearDragState() {
    set(dragOverIndex, null), set(draggingRowKey, null);
  }
  __name(clearDragState, "clearDragState");
  function handleDrop(event2, index2) {
    event2.preventDefault(), event2.stopPropagation();
    const result = parseTurnPrepDragData(event2.dataTransfer), targetIndex = index2 ?? features().length, targetTable = getEffectiveTableType(), copy = !!event2.shiftKey, actorId = getActorId();
    if (!result) {
      clearDragState();
      return;
    }
    if (result.kind === "turn-prep-feature") {
      const payload = result.payload;
      if (actorId && payload.actorId && payload.actorId !== actorId) {
        notifyActorMismatch(), clearDragState();
        return;
      }
      const feature = cloneSelectedFeature(payload.feature);
      if (!feature) {
        clearDragState();
        return;
      }
      const sameTable = ownerId() && (payload.sourcePlanId === ownerId() || payload.sourceReactionId === ownerId()) && payload.sourceTable === targetTable;
      if (!copy && sameTable && payload.sourceIndex !== void 0 && payload.sourceIndex !== null && typeof payload.sourceIndex == "number") {
        onReorderFeature()?.(payload.sourceIndex, targetIndex), clearDragState();
        return;
      }
      if (hasDuplicateFeature(features(), feature)) {
        notifyDuplicateFeature(), clearDragState();
        return;
      }
      onFeatureDrop()?.({
        panelKind: panelKind(),
        table: targetTable,
        ownerId: ownerId(),
        targetIndex,
        copy,
        feature,
        source: payload
      }), clearDragState();
      return;
    }
    if (result.kind === "foundry-item") {
      onFeatureDrop()?.({
        panelKind: panelKind(),
        table: targetTable,
        ownerId: ownerId(),
        targetIndex,
        copy: !0,
        nativeItemUuid: result.uuid,
        source: null
      }), clearDragState();
      return;
    }
    clearDragState();
  }
  __name(handleDrop, "handleDrop");
  function handleRowContextMenu(feature, event2) {
    event2.preventDefault(), event2.stopPropagation(), openFeatureContextMenu(feature, { x: event2.clientX, y: event2.clientY }, event2.currentTarget);
  }
  __name(handleRowContextMenu, "handleRowContextMenu");
  function handleFeatureMenuButton(feature, event2) {
    event2.preventDefault(), event2.stopPropagation();
    const button = event2.currentTarget;
    if (button) {
      const rect = button.getBoundingClientRect();
      openFeatureContextMenu(feature, { x: rect.right, y: rect.bottom + 4 }, button);
      return;
    }
    openFeatureContextMenu(feature, { x: event2.clientX, y: event2.clientY });
  }
  __name(handleFeatureMenuButton, "handleFeatureMenuButton");
  async function handleFeatureRoll(feature, event2) {
    if (event2?.preventDefault(), event2?.stopPropagation(), !actor()) {
      notifyWarning2("TURN_PREP.TurnPlans.Messages.ActorUnavailable");
      return;
    }
    const item = getFeatureItem(feature);
    if (!item) {
      notifyWarning2("TURN_PREP.TurnPlans.Messages.ItemUnavailable");
      return;
    }
    try {
      await FoundryAdapter.useItemDocument(item, { event: event2 });
    } catch (error2) {
      console.error("[TurnPlanFeatureTable] Failed to roll feature", feature.itemName, error2), notifyWarning2("TURN_PREP.TurnPlans.Messages.RollFailed", { feature: feature.itemName });
    }
  }
  __name(handleFeatureRoll, "handleFeatureRoll");
  async function handleActivityRoll(feature, activity, event2) {
    if (event2?.preventDefault(), event2?.stopPropagation(), !actor()) {
      notifyWarning2("TURN_PREP.TurnPlans.Messages.ActorUnavailable");
      return;
    }
    const item = getFeatureItem(feature);
    if (!item) {
      notifyWarning2("TURN_PREP.TurnPlans.Messages.ItemUnavailable");
      return;
    }
    const activityDoc = FoundryAdapter.getActivityFromItem(item, activity.activityId);
    if (!activityDoc) {
      notifyWarning2("TURN_PREP.TurnPlans.Messages.ActivityUnavailable");
      return;
    }
    try {
      await FoundryAdapter.useActivityDocument(activityDoc, { event: event2 });
    } catch (error2) {
      console.error("[TurnPlanFeatureTable] Failed to roll activity", activity.name, error2), notifyWarning2("TURN_PREP.TurnPlans.Messages.RollFailed", { feature: activity.name });
    }
  }
  __name(handleActivityRoll, "handleActivityRoll");
  var fragment = root$4(), section = first_child(fragment), header = child(section);
  header.__click = toggleTable, header.__keydown = handleHeaderKey;
  var div = child(header), div_1 = sibling(div, 2), div_2 = child(div_1), h3 = sibling(div_2, 2), text = child(h3), span = sibling(h3, 2), text_1 = child(span), div_3 = sibling(div_1, 2), text_2 = child(div_3), div_4 = sibling(div_3, 2), text_3 = child(div_4), div_5 = sibling(div_4, 2), text_4 = child(div_5), div_6 = sibling(div_5, 2), text_5 = child(div_6), div_7 = sibling(div_6, 2), text_6 = child(div_7), div_8 = sibling(div_7, 2), div_9 = sibling(header, 2), div_10 = child(div_9), div_11 = child(div_10), node = child(div_11);
  {
    var consequent = /* @__PURE__ */ __name(($$anchor2) => {
      var div_12 = root_1$4(), div_13 = child(div_12), div_14 = child(div_13), text_7 = child(div_14);
      template_effect(() => {
        set_style(div_13, `--grid-template-columns: ${templateColumns ?? ""};`), set_text(text_7, emptyMessage());
      }), event("dragover", div_12, (event2) => handleDragOver(event2, null)), event("drop", div_12, (event2) => handleDrop(event2, null)), append($$anchor2, div_12);
    }, "consequent"), alternate_8 = /* @__PURE__ */ __name(($$anchor2) => {
      var fragment_1 = comment(), node_1 = first_child(fragment_1);
      each(node_1, 19, features, (feature) => feature.rowKey, ($$anchor3, feature, index2) => {
        var div_15 = root_3$4();
        div_15.__contextmenu = (event2) => handleRowContextMenu(get$1(feature), event2);
        var div_16 = child(div_15), button_1 = child(div_16);
        button_1.__click = (event2) => handleFeatureRoll(get$1(feature), event2);
        var img = child(button_1), div_17 = sibling(button_1, 2), button_2 = child(div_17);
        button_2.__click = () => toggleRow(get$1(feature).rowKey);
        var span_1 = child(button_2), span_2 = child(span_1), text_8 = child(span_2), span_3 = sibling(span_1, 2), i = child(span_3), div_18 = sibling(div_17, 2), node_2 = child(div_18);
        {
          var consequent_1 = /* @__PURE__ */ __name(($$anchor4) => {
            var fragment_2 = root_4$3(), input = first_child(fragment_2), span_4 = sibling(input, 4), text_9 = child(span_4);
            template_effect(
              ($0) => {
                set_value(input, get$1(feature).usesValue ?? ""), set_text(text_9, $0);
              },
              [() => formatValue(get$1(feature).usesMax)]
            ), append($$anchor4, fragment_2);
          }, "consequent_1"), alternate = /* @__PURE__ */ __name(($$anchor4) => {
            var span_5 = root_5$2();
            append($$anchor4, span_5);
          }, "alternate");
          if_block(node_2, ($$render) => {
            hasLimitedUses(get$1(feature)) ? $$render(consequent_1) : $$render(alternate, !1);
          });
        }
        var div_19 = sibling(div_18, 2), node_3 = child(div_19);
        {
          var consequent_4 = /* @__PURE__ */ __name(($$anchor4) => {
            var div_20 = root_6$1(), node_4 = child(div_20);
            {
              var consequent_2 = /* @__PURE__ */ __name(($$anchor5) => {
                var span_6 = root_7$3(), text_10 = child(span_6);
                template_effect(() => set_text(text_10, get$1(feature).rollDisplay.ability)), append($$anchor5, span_6);
              }, "consequent_2");
              if_block(node_4, ($$render) => {
                get$1(feature).rollDisplay.ability && $$render(consequent_2);
              });
            }
            var node_5 = sibling(node_4, 2);
            {
              var consequent_3 = /* @__PURE__ */ __name(($$anchor5) => {
                var span_7 = root_8$3(), text_11 = child(span_7);
                template_effect(() => set_text(text_11, get$1(feature).rollDisplay.value)), append($$anchor5, span_7);
              }, "consequent_3");
              if_block(node_5, ($$render) => {
                get$1(feature).rollDisplay.value && $$render(consequent_3);
              });
            }
            append($$anchor4, div_20);
          }, "consequent_4"), alternate_1 = /* @__PURE__ */ __name(($$anchor4) => {
            var span_8 = root_9$2(), text_12 = child(span_8);
            template_effect(($0) => set_text(text_12, $0), [() => formatValue(get$1(feature).rollLabel)]), append($$anchor4, span_8);
          }, "alternate_1");
          if_block(node_3, ($$render) => {
            get$1(feature).rollDisplay && (get$1(feature).rollDisplay.ability || get$1(feature).rollDisplay.value) ? $$render(consequent_4) : $$render(alternate_1, !1);
          });
        }
        var div_21 = sibling(div_19, 2), node_6 = child(div_21);
        {
          var consequent_7 = /* @__PURE__ */ __name(($$anchor4) => {
            var div_22 = root_10$3();
            each(div_22, 23, () => get$1(feature).damageEntries, (damageEntry, index3) => `${get$1(feature).rowKey}-damage-${index3}`, ($$anchor5, damageEntry, index3, $$array) => {
              var div_23 = root_11$3(), span_9 = child(div_23), text_13 = child(span_9), node_7 = sibling(span_9, 2);
              {
                var consequent_5 = /* @__PURE__ */ __name(($$anchor6) => {
                  var span_10 = root_12$3(), dnd5e_icon = child(span_10);
                  template_effect(() => set_custom_element_data(dnd5e_icon, "src", get$1(damageEntry).icon)), set_class(dnd5e_icon, 1, "svelte-tp-1nnogk2"), template_effect(() => set_attribute(span_10, "aria-label", get$1(damageEntry).ariaLabel ?? get$1(damageEntry).type)), append($$anchor6, span_10);
                }, "consequent_5"), alternate_2 = /* @__PURE__ */ __name(($$anchor6) => {
                  var fragment_3 = comment(), node_8 = first_child(fragment_3);
                  {
                    var consequent_6 = /* @__PURE__ */ __name(($$anchor7) => {
                      var span_11 = root_14$1(), text_14 = child(span_11);
                      template_effect(() => set_text(text_14, get$1(damageEntry).type)), append($$anchor7, span_11);
                    }, "consequent_6");
                    if_block(
                      node_8,
                      ($$render) => {
                        get$1(damageEntry).type && $$render(consequent_6);
                      },
                      !0
                    );
                  }
                  append($$anchor6, fragment_3);
                }, "alternate_2");
                if_block(node_7, ($$render) => {
                  get$1(damageEntry).icon ? $$render(consequent_5) : $$render(alternate_2, !1);
                });
              }
              template_effect(() => {
                set_attribute(div_23, "title", get$1(damageEntry).ariaLabel ?? `${get$1(damageEntry).formula}${get$1(damageEntry).type ? ` ${get$1(damageEntry).type}` : ""}`), set_text(text_13, get$1(damageEntry).formula);
              }), append($$anchor5, div_23);
            }), append($$anchor4, div_22);
          }, "consequent_7"), alternate_3 = /* @__PURE__ */ __name(($$anchor4) => {
            var span_12 = root_15(), text_15 = child(span_12);
            template_effect(($0) => set_text(text_15, $0), [() => formatValue(get$1(feature).formula)]), append($$anchor4, span_12);
          }, "alternate_3");
          if_block(node_6, ($$render) => {
            get$1(feature).damageEntries && get$1(feature).damageEntries.length ? $$render(consequent_7) : $$render(alternate_3, !1);
          });
        }
        var div_24 = sibling(div_21, 2), span_13 = child(div_24), text_16 = child(span_13), div_25 = sibling(div_24, 2), span_14 = child(div_25), text_17 = child(span_14), div_26 = sibling(div_25, 2), button_3 = child(div_26);
        button_3.__click = (event2) => handleFeatureMenuButton(get$1(feature), event2);
        var div_27 = sibling(div_16, 2), div_28 = child(div_27), div_29 = child(div_28), node_9 = child(div_29);
        {
          var consequent_12 = /* @__PURE__ */ __name(($$anchor4) => {
            var section_1 = root_16(), header_1 = child(section_1), div_30 = child(header_1), h3_1 = child(div_30), text_18 = child(h3_1), span_15 = sibling(h3_1, 2), text_19 = child(span_15), div_31 = sibling(div_30, 2), text_20 = child(div_31), div_32 = sibling(div_31, 2), text_21 = child(div_32), div_33 = sibling(div_32, 2), text_22 = child(div_33), div_34 = sibling(div_33, 2), div_35 = sibling(header_1, 2), div_36 = child(div_35), div_37 = child(div_36);
            each(div_37, 21, () => get$1(feature).activities, (activity) => activity.rowKey, ($$anchor5, activity) => {
              var div_38 = root_17(), div_39 = child(div_38), button_4 = child(div_39);
              button_4.__click = (event2) => handleActivityRoll(get$1(feature), get$1(activity), event2);
              var img_1 = child(button_4), div_40 = sibling(button_4, 2), span_16 = child(div_40), span_17 = child(span_16), span_18 = child(span_17), text_23 = child(span_18), div_41 = sibling(div_40, 2), node_10 = child(div_41);
              {
                var consequent_8 = /* @__PURE__ */ __name(($$anchor6) => {
                  var fragment_4 = root_18(), input_1 = first_child(fragment_4), span_19 = sibling(input_1, 4), text_24 = child(span_19);
                  template_effect(
                    ($0) => {
                      set_value(input_1, get$1(activity).usesValue ?? ""), set_text(text_24, $0);
                    },
                    [() => formatValue(get$1(activity).usesMax)]
                  ), append($$anchor6, fragment_4);
                }, "consequent_8"), alternate_4 = /* @__PURE__ */ __name(($$anchor6) => {
                  var span_20 = root_19();
                  append($$anchor6, span_20);
                }, "alternate_4");
                if_block(node_10, ($$render) => {
                  hasLimitedUses(get$1(activity)) ? $$render(consequent_8) : $$render(alternate_4, !1);
                });
              }
              var div_42 = sibling(div_41, 2), span_21 = child(div_42), text_25 = child(span_21), div_43 = sibling(div_42, 2), node_11 = child(div_43);
              {
                var consequent_11 = /* @__PURE__ */ __name(($$anchor6) => {
                  var div_44 = root_20();
                  each(div_44, 23, () => get$1(activity).damageEntries, (damageEntry, index3) => `${get$1(activity).rowKey}-damage-${index3}`, ($$anchor7, damageEntry, index3, $$array_1) => {
                    var div_45 = root_21(), span_22 = child(div_45), text_26 = child(span_22), node_12 = sibling(span_22, 2);
                    {
                      var consequent_9 = /* @__PURE__ */ __name(($$anchor8) => {
                        var span_23 = root_22(), dnd5e_icon_1 = child(span_23);
                        template_effect(() => set_custom_element_data(dnd5e_icon_1, "src", get$1(damageEntry).icon)), set_class(dnd5e_icon_1, 1, "svelte-tp-1nnogk2"), template_effect(() => set_attribute(span_23, "aria-label", get$1(damageEntry).ariaLabel ?? get$1(damageEntry).type)), append($$anchor8, span_23);
                      }, "consequent_9"), alternate_5 = /* @__PURE__ */ __name(($$anchor8) => {
                        var fragment_5 = comment(), node_13 = first_child(fragment_5);
                        {
                          var consequent_10 = /* @__PURE__ */ __name(($$anchor9) => {
                            var span_24 = root_24(), text_27 = child(span_24);
                            template_effect(() => set_text(text_27, get$1(damageEntry).type)), append($$anchor9, span_24);
                          }, "consequent_10");
                          if_block(
                            node_13,
                            ($$render) => {
                              get$1(damageEntry).type && $$render(consequent_10);
                            },
                            !0
                          );
                        }
                        append($$anchor8, fragment_5);
                      }, "alternate_5");
                      if_block(node_12, ($$render) => {
                        get$1(damageEntry).icon ? $$render(consequent_9) : $$render(alternate_5, !1);
                      });
                    }
                    template_effect(() => {
                      set_attribute(div_45, "title", get$1(damageEntry).ariaLabel ?? `${get$1(damageEntry).formula}${get$1(damageEntry).type ? ` ${get$1(damageEntry).type}` : ""}`), set_text(text_26, get$1(damageEntry).formula);
                    }), append($$anchor7, div_45);
                  }), append($$anchor6, div_44);
                }, "consequent_11"), alternate_6 = /* @__PURE__ */ __name(($$anchor6) => {
                  var span_25 = root_25(), text_28 = child(span_25);
                  template_effect(($0) => set_text(text_28, $0), [() => formatValue(get$1(activity).formula)]), append($$anchor6, span_25);
                }, "alternate_6");
                if_block(node_11, ($$render) => {
                  get$1(activity).damageEntries && get$1(activity).damageEntries.length ? $$render(consequent_11) : $$render(alternate_6, !1);
                });
              }
              var div_46 = sibling(div_43, 2), button_5 = child(div_46);
              button_5.__click = handlePendingActionsClick, template_effect(
                ($0, $1, $2) => {
                  set_attribute(div_38, "data-activity-id", get$1(activity).activityId), set_style(div_39, `--grid-template-columns: ${activityTemplateColumns ?? ""};`), set_attribute(button_4, "title", get$1(activity).name), set_attribute(img_1, "alt", get$1(activity).name), set_attribute(img_1, "src", get$1(activity).icon || get$1(feature).icon || defaultIcon), set_text(text_23, get$1(activity).name), set_style(div_41, `--tidy-table-column-width: ${activityColumnWidths.uses};`), set_style(div_42, `--tidy-table-column-width: ${activityColumnWidths.time};`), set_text(text_25, $0), set_style(div_43, `--tidy-table-column-width: ${activityColumnWidths.formula};`), set_style(div_46, `--tidy-table-column-width: ${activityColumnWidths.actions};`), set_attribute(button_5, "title", $1), set_attribute(button_5, "aria-label", $2);
                },
                [
                  () => formatValue(get$1(activity).timeLabel),
                  () => FoundryAdapter.localize("TURN_PREP.Messages.NotImplemented"),
                  () => FoundryAdapter.localize("TURN_PREP.Common.Actions")
                ]
              ), append($$anchor5, div_38);
            }), template_effect(
              ($0, $1, $2, $3, $4) => {
                set_attribute(section_1, "data-tidy-section-key", `activities-${get$1(feature).rowKey}`), set_style(section_1, `--grid-template-columns: ${activityTemplateColumns ?? ""}`), set_text(text_18, $0), set_text(text_19, get$1(feature).activities.length), set_style(div_31, `--tidy-table-column-width: ${activityColumnWidths.uses};`), set_text(text_20, $1), set_style(div_32, `--tidy-table-column-width: ${activityColumnWidths.time};`), set_text(text_21, $2), set_style(div_33, `--tidy-table-column-width: ${activityColumnWidths.formula};`), set_text(text_22, $3), set_style(div_34, `--tidy-table-column-width: ${activityColumnWidths.actions};`), set_attribute(div_34, "aria-label", $4);
              },
              [
                () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Activities"),
                () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Uses"),
                () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Time"),
                () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Formula"),
                () => FoundryAdapter.localize("TURN_PREP.Common.Actions")
              ]
            ), append($$anchor4, section_1);
          }, "consequent_12");
          if_block(node_9, ($$render) => {
            get$1(feature).activities && get$1(feature).activities.length && $$render(consequent_12);
          });
        }
        var div_47 = sibling(node_9, 2), node_14 = child(div_47);
        {
          var consequent_13 = /* @__PURE__ */ __name(($$anchor4) => {
            var div_48 = root_26(), node_15 = child(div_48);
            html(node_15, () => get$1(descriptionCache)[get$1(feature).rowKey]), template_effect(() => set_attribute(div_48, "aria-label", get$1(feature).itemName)), append($$anchor4, div_48);
          }, "consequent_13"), alternate_7 = /* @__PURE__ */ __name(($$anchor4) => {
            var p = root_27(), text_29 = child(p);
            template_effect(() => set_text(text_29, get$1(feature).summary || noDetails)), append($$anchor4, p);
          }, "alternate_7");
          if_block(node_14, ($$render) => {
            get$1(descriptionCache)[get$1(feature).rowKey] ? $$render(consequent_13) : $$render(alternate_7, !1);
          });
        }
        var div_49 = sibling(node_14, 2);
        each(div_49, 20, () => getTags(get$1(feature)), (tag) => tag, ($$anchor4, tag) => {
          var span_26 = root_28(), span_27 = child(span_26), text_30 = child(span_27);
          template_effect(() => set_text(text_30, tag)), append($$anchor4, span_26);
        });
        var div_50 = sibling(div_49, 2), button_6 = child(div_50), text_31 = sibling(child(button_6)), button_7 = sibling(button_6, 2), text_32 = sibling(child(button_7));
        template_effect(
          ($0, $1, $2, $3, $4, $5, $6) => {
            set_attribute(div_15, "data-item-id", get$1(feature).itemId), set_class(div_16, 1, `tidy-table-row tidy-table-row-v2 ${get$1(rowStates)[get$1(feature).rowKey] ? "expanded" : ""} ${get$1(feature).isMissing ? "missing" : ""} ${get$1(activeContextRowKey) === get$1(feature).rowKey ? "context-open" : ""} ${get$1(dragOverIndex) === get$1(index2) ? "drag-over" : ""}`, "svelte-tp-1nnogk2"), set_style(div_16, `--grid-template-columns: ${templateColumns ?? ""};`), set_attribute(button_1, "title", get$1(feature).itemName), set_attribute(img, "alt", get$1(feature).itemName), set_attribute(img, "src", get$1(feature).icon || defaultIcon), set_text(text_8, get$1(feature).itemName), set_class(i, 1, `fa-solid fa-angle-right expand-indicator ${get$1(rowStates)[get$1(feature).rowKey] ? "expanded" : ""}`, "svelte-tp-1nnogk2"), set_style(div_18, `--tidy-table-column-width: ${columnWidths.uses};`), set_style(div_19, `--tidy-table-column-width: ${columnWidths.roll};`), set_style(div_21, `--tidy-table-column-width: ${columnWidths.formula};`), set_style(div_24, `--tidy-table-column-width: ${columnWidths.range};`), set_text(text_16, $0), set_style(div_25, `--tidy-table-column-width: ${columnWidths.target};`), set_text(text_17, $1), set_style(div_26, `--tidy-table-column-width: ${columnWidths.actions};`), set_class(button_3, 1, `tidy-table-button ${get$1(activeContextRowKey) === get$1(feature).rowKey ? "is-active" : ""}`, "svelte-tp-1nnogk2"), set_attribute(button_3, "title", $2), set_attribute(button_3, "aria-expanded", get$1(activeContextRowKey) === get$1(feature).rowKey ? "true" : "false"), set_class(div_27, 1, `expandable ${get$1(rowStates)[get$1(feature).rowKey] ? "expanded" : ""}`, "svelte-tp-1nnogk2"), set_attribute(button_6, "title", $3), set_text(text_31, ` ${$4 ?? ""}`), set_attribute(button_7, "title", $5), set_text(text_32, ` ${$6 ?? ""}`);
          },
          [
            () => formatValue(get$1(feature).range),
            () => formatValue(get$1(feature).target),
            () => FoundryAdapter.localize("TURN_PREP.Common.Actions"),
            () => FoundryAdapter.localize("TURN_PREP.Common.ComingSoon"),
            () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.DisplayInChat"),
            () => FoundryAdapter.localize("TURN_PREP.Common.ComingSoon"),
            () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.RollAction")
          ]
        ), event("dragstart", div_15, (event2) => handleDragStart(get$1(feature), get$1(index2), event2)), event("dragover", div_15, (event2) => handleDragOver(event2, get$1(index2))), event("dragenter", div_15, (event2) => handleDragEnter(event2, get$1(index2))), event("dragleave", div_15, handleDragLeave), event("dragend", div_15, clearDragState), event("drop", div_15, (event2) => handleDrop(event2, get$1(index2))), append($$anchor3, div_15);
      }), append($$anchor2, fragment_1);
    }, "alternate_8");
    if_block(node, ($$render) => {
      features().length ? $$render(alternate_8, !1) : $$render(consequent);
    });
  }
  var node_16 = sibling(section, 2);
  ContextMenuHost(node_16, {
    get controller() {
      return featureContextMenu;
    }
  }), template_effect(
    ($0, $1, $2, $3, $4, $5) => {
      set_attribute(section, "data-tidy-section-key", $$props.tableKey), set_style(section, `--grid-template-columns: ${templateColumns ?? ""}`), set_style(div, `--tidy-table-column-width: ${columnWidths.icon};`), set_class(div_2, 1, `button expand-button ${get$1(expanded) ? "expanded" : ""}`), set_text(text, $$props.title), set_text(text_1, features().length), set_style(div_3, `--tidy-table-column-width: ${columnWidths.uses};`), set_text(text_2, $0), set_style(div_4, `--tidy-table-column-width: ${columnWidths.roll};`), set_text(text_3, $1), set_style(div_5, `--tidy-table-column-width: ${columnWidths.formula};`), set_text(text_4, $2), set_style(div_6, `--tidy-table-column-width: ${columnWidths.range};`), set_text(text_5, $3), set_style(div_7, `--tidy-table-column-width: ${columnWidths.target};`), set_text(text_6, $4), set_style(div_8, `--tidy-table-column-width: ${columnWidths.actions};`), set_attribute(div_8, "aria-label", $5), set_class(div_9, 1, `expandable ${get$1(expanded) ? "expanded" : ""}`, "svelte-tp-1nnogk2");
    },
    [
      () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Uses"),
      () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Roll"),
      () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Formula"),
      () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Range"),
      () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Table.Target"),
      () => FoundryAdapter.localize("TURN_PREP.Common.Actions")
    ]
  ), event("dragover", div_11, (event2) => handleDragOver(event2, null)), event("drop", div_11, (event2) => handleDrop(event2, null)), append($$anchor, fragment), pop();
}
__name(TurnPlanFeatureTable, "TurnPlanFeatureTable");
delegate(["click", "keydown", "contextmenu"]);
var root_1$3 = /* @__PURE__ */ from_html('<div class="turn-prep-panel-loading reaction-plans-loading"><p> </p></div>'), root_3$3 = /* @__PURE__ */ from_html('<button type="button" class="turn-prep-panel-toggle"><i></i></button>'), root_4$2 = /* @__PURE__ */ from_html('<div style="display: flex; gap: 0.5rem;"><button type="button" class="turn-prep-panel-action-btn"><i class="fas fa-save"></i> </button> <button type="button" class="turn-prep-panel-action-btn" style="background: rgba(200, 50, 50, 0.2);"><i class="fas fa-times"></i> </button></div>'), root_5$1 = /* @__PURE__ */ from_html('<button type="button" class="turn-prep-panel-action-btn"><i class="fas fa-plus"></i> </button>'), root_7$2 = /* @__PURE__ */ from_html('<div class="turn-prep-panel-empty reaction-plans-empty"><p> </p></div>'), root_11$2 = /* @__PURE__ */ from_html('<button type="button" class="reaction-collapse-button svelte-tp-a69jix"><i></i></button>'), root_12$2 = /* @__PURE__ */ from_html('<button type="button" class="reaction-menu-button svelte-tp-a69jix"><i class="fas fa-ellipsis-vertical"></i></button>'), root_14 = /* @__PURE__ */ from_html('<div class="turn-prep-collapsible__body"><textarea class="turn-prep-textarea notes-input" rows="3"></textarea></div>'), root_13$1 = /* @__PURE__ */ from_html('<div class="reaction-content svelte-tp-a69jix"><!> <!> <div><button type="button" class="turn-prep-collapsible__toggle notes-toggle"><i></i> <span> </span></button> <!></div></div>'), root_10$2 = /* @__PURE__ */ from_html('<div role="group"><div class="reaction-header svelte-tp-a69jix"><div class="turn-prep-inline-label-row reaction-name-row svelte-tp-a69jix"><!> <label> </label> <input type="text" class="turn-prep-input reaction-name svelte-tp-a69jix"/></div> <!></div> <!></div>'), root_8$2 = /* @__PURE__ */ from_html('<div class="turn-prep-panel-list reaction-plans-list"></div>'), root_2$3 = /* @__PURE__ */ from_html('<div class="turn-prep-panel reaction-plans-panel"><div class="turn-prep-panel-header"><!> <h3> </h3> <!></div> <!></div>'), root$3 = /* @__PURE__ */ from_html("<!> <!>", 1);
function ReactionPlansPanel($$anchor, $$props) {
  push($$props, !0);
  let isEditing = /* @__PURE__ */ state(!1), editSession = /* @__PURE__ */ state(null), reactions = /* @__PURE__ */ state(proxy([])), loading = /* @__PURE__ */ state(!0), initialized = /* @__PURE__ */ state(!1), collapsed = /* @__PURE__ */ state(!1), notesCollapsed = /* @__PURE__ */ state(proxy({})), reactionCollapseState = /* @__PURE__ */ state(proxy({}));
  const reactionContextMenuController = new ContextMenuController("reaction-plans-panel");
  let activeContextReactionId = /* @__PURE__ */ state(null), saveTimeout = null;
  const hookCleanups = [];
  function randomId() {
    const foundryRandom = globalThis.foundry?.utils?.randomID;
    return typeof foundryRandom == "function" ? foundryRandom() : typeof crypto?.randomUUID == "function" ? crypto.randomUUID() : Math.random().toString(36).slice(2);
  }
  __name(randomId, "randomId"), onMount(() => {
    loadReactions(!0), registerHook("updateActor", onActorUpdated), registerHook("updateItem", onItemChanged), registerHook("deleteItem", onItemChanged);
    const unsubscribeContextMenu = reactionContextMenuController.subscribe((state2) => {
      const contextReactionId = state2?.context?.reactionId;
      set(activeContextReactionId, typeof contextReactionId == "string" ? contextReactionId : null, !0);
    }), unsubscribeEditSession = editSessionStore.subscribe((session) => {
      if (session?.actorId === $$props.actor?.id && session?.kind === "reaction") {
        if (!get$1(isEditing)) {
          set(isEditing, !0), set(editSession, session, !0);
          const r2 = snapshotToReaction(session.snapshot);
          r2.id = session.originalId, set(reactions, [r2], !0), set(reactionCollapseState, { ...get$1(reactionCollapseState), [r2.id]: !1 }, !0), set(
            notesCollapsed,
            {
              ...get$1(
                notesCollapsed
                // In ReactionPlansPanel, notesCollapsed=true means collapsed (hidden), so false is open
              ),
              [r2.id]: !1
            },
            !0
          );
        }
        if (get$1(isEditing) && session.pendingFeatures.length > 0) {
          const updatedReactions = [...get$1(reactions)], reaction = updatedReactions[0];
          let changed = !1;
          session.pendingFeatures.forEach(({ feature, mode }) => {
            mode === "reaction" ? hasDuplicateFeature(reaction.reactionFeatures, feature) || (reaction.reactionFeatures = [...reaction.reactionFeatures ?? [], feature], changed = !0) : hasDuplicateFeature(reaction.additionalFeatures, feature) || (reaction.additionalFeatures = [...reaction.additionalFeatures ?? [], feature], changed = !0);
          }), changed && (set(reactions, updatedReactions, !0), editSessionStore.clearPendingFeatures());
        }
      } else
        get$1(isEditing) && (set(isEditing, !1), set(editSession, null), loadReactions(!1));
    });
    return () => {
      cleanupHooks(), cancelPendingSave(!0), unsubscribeContextMenu(), unsubscribeEditSession();
    };
  }), user_effect(() => {
    const nextState = {};
    let changed = !1;
    for (const reaction of get$1(reactions)) {
      const existing = get$1(notesCollapsed)[reaction.id], value = existing ?? !0;
      nextState[reaction.id] = value, existing === void 0 && (changed = !0);
    }
    Object.keys(get$1(notesCollapsed)).length !== Object.keys(nextState).length && (changed = !0), changed && set(notesCollapsed, nextState, !0);
  }), user_effect(() => {
    const nextState = {};
    let changed = !1;
    for (const reaction of get$1(reactions)) {
      const existing = get$1(reactionCollapseState)[reaction.id], value = existing ?? !1;
      nextState[reaction.id] = value, existing === void 0 && (changed = !0);
    }
    Object.keys(get$1(reactionCollapseState)).length !== Object.keys(nextState).length && (changed = !0), changed && set(reactionCollapseState, nextState, !0);
  });
  function registerHook(hookName, handler) {
    if (typeof Hooks > "u") return;
    const hookId = Hooks.on(hookName, handler);
    hookCleanups.push(() => Hooks.off(hookName, hookId));
  }
  __name(registerHook, "registerHook");
  function cleanupHooks() {
    for (; hookCleanups.length; )
      hookCleanups.pop()?.();
  }
  __name(cleanupHooks, "cleanupHooks");
  function hasTurnPrepFlagChange(changes) {
    const flagChanges = changes?.flags;
    if (!flagChanges) return !1;
    const scopeChanges = flagChanges[FLAG_SCOPE];
    return scopeChanges ? Object.prototype.hasOwnProperty.call(scopeChanges, FLAG_KEY_DATA) : !1;
  }
  __name(hasTurnPrepFlagChange, "hasTurnPrepFlagChange");
  function onActorUpdated(updatedActor, changes) {
    !$$props.actor || updatedActor?.id !== $$props.actor.id || hasTurnPrepFlagChange(changes) && loadReactions();
  }
  __name(onActorUpdated, "onActorUpdated");
  function onItemChanged(item) {
    !$$props.actor || !item?.actor || item.actor.id !== $$props.actor.id || touchReactions();
  }
  __name(onItemChanged, "onItemChanged");
  function touchReactions() {
    set(reactions, get$1(reactions).map((reaction) => ({ ...reaction })), !0);
  }
  __name(touchReactions, "touchReactions");
  function loadReactions(showSpinner = !1) {
    if (!$$props.actor) {
      set(reactions, [], !0), set(loading, !1), set(initialized, !0);
      return;
    }
    showSpinner && set(loading, !0);
    try {
      const turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor);
      set(reactions, hydrateReactions(turnPrepData?.reactions ?? []), !0);
    } catch (error2) {
      console.error("[ReactionPlansPanel] Failed to load reactions:", error2), set(reactions, [], !0), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.Reactions.SaveError"));
    } finally {
      set(loading, !1), set(initialized, !0);
    }
  }
  __name(loadReactions, "loadReactions");
  function hydrateReactions(rawReactions) {
    return rawReactions.map((reaction) => sanitizeReaction(reaction));
  }
  __name(hydrateReactions, "hydrateReactions");
  function sanitizeReaction(rawReaction) {
    const reactionsLabel = FoundryAdapter.localize("TURN_PREP.Reactions.ReactionLabel") || "Reaction", reactionFeatures = mergeSelectedFeatureArrays(rawReaction?.reactionFeatures, rawReaction?.feature), additionalFeatures = cloneSelectedFeatureArray(rawReaction?.additionalFeatures ?? []);
    return {
      id: rawReaction?.id ?? randomId(),
      name: typeof rawReaction?.name == "string" ? rawReaction.name : typeof rawReaction?.trigger == "string" && rawReaction.trigger ? rawReaction.trigger : reactionsLabel,
      trigger: typeof rawReaction?.trigger == "string" ? rawReaction.trigger : "",
      reactionFeatures,
      additionalFeatures,
      notes: typeof rawReaction?.notes == "string" ? rawReaction.notes : "",
      createdTime: typeof rawReaction?.createdTime == "number" ? rawReaction.createdTime : Date.now(),
      isFavorite: !!rawReaction?.isFavorite
    };
  }
  __name(sanitizeReaction, "sanitizeReaction");
  function cloneFeature(feature) {
    return cloneSelectedFeature(feature);
  }
  __name(cloneFeature, "cloneFeature");
  function getActivationsFromFeature(feature) {
    return feature?.actionType ? [normalizeActionType(feature.actionType)] : [];
  }
  __name(getActivationsFromFeature, "getActivationsFromFeature");
  function getActivationsFromItem(item) {
    if (!item) return [];
    const activations = [], itemActivation = normalizeActionType(item?.system?.activation?.type);
    itemActivation && activations.push(itemActivation);
    const activities = FeatureSelector.getActivitiesForItem(item) ?? [];
    for (const act of activities) {
      const type = normalizeActionType(act?.activation?.type ?? act?.system?.activation?.type);
      type && activations.push(type);
    }
    return activations;
  }
  __name(getActivationsFromItem, "getActivationsFromItem");
  function getActivationsForFeature(feature) {
    if (feature?.itemId) {
      const item = $$props.actor?.items?.get?.(feature.itemId), fromItem = getActivationsFromItem(item);
      if (fromItem.length) return fromItem;
    }
    return getActivationsFromFeature(feature);
  }
  __name(getActivationsForFeature, "getActivationsForFeature");
  async function buildFeatureFromUuid(uuid) {
    try {
      const doc = await globalThis.fromUuid?.(uuid);
      if (!doc)
        return ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.ItemUnavailable")), { feature: null, activations: [] };
      if (doc?.actor?.id && $$props.actor?.id && doc.actor.id !== $$props.actor.id)
        return ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.ActorMismatch")), { feature: null, activations: [] };
      const actionType = normalizeActionType(doc?.system?.activation?.type), feature = {
        itemId: doc.id,
        itemName: doc.name ?? doc.id,
        itemType: doc.type ?? "item",
        actionType
      }, activations = getActivationsFromItem(doc);
      return {
        feature,
        activations: activations.length ? activations : getActivationsFromFeature(feature)
      };
    } catch (error2) {
      return console.error("[ReactionPlansPanel] Failed to resolve UUID drop", uuid, error2), ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.ItemUnavailable")), { feature: null, activations: [] };
    }
  }
  __name(buildFeatureFromUuid, "buildFeatureFromUuid");
  function coerceReactionTable(table) {
    return table === "reactionFeatures" || table === "reactions" ? "reactionFeatures" : "additionalFeatures";
  }
  __name(coerceReactionTable, "coerceReactionTable");
  function pickReactionTableForDrop(requested, activations) {
    const desired = coerceReactionTable(requested);
    return desired === "additionalFeatures" ? desired : activations.some((act) => act && resolveReactionPlanTableForActivations([act]) === "reactionFeatures") ? "reactionFeatures" : "additionalFeatures";
  }
  __name(pickReactionTableForDrop, "pickReactionTableForDrop");
  function getReactionTable(reaction, table) {
    return table === "reactionFeatures" ? reaction.reactionFeatures ?? [] : reaction.additionalFeatures ?? [];
  }
  __name(getReactionTable, "getReactionTable");
  function setReactionTable(reaction, table, value) {
    return table === "reactionFeatures" ? { ...reaction, reactionFeatures: value } : { ...reaction, additionalFeatures: value };
  }
  __name(setReactionTable, "setReactionTable");
  function coerceTurnTable(table) {
    return table === "actions" || table === "bonusActions" || table === "reactions" ? table : "additionalFeatures";
  }
  __name(coerceTurnTable, "coerceTurnTable");
  function getTurnPlanTable(plan, table) {
    switch (table) {
      case "actions":
        return plan.actions ?? [];
      case "bonusActions":
        return plan.bonusActions ?? [];
      case "reactions":
        return plan.reactions ?? [];
      default:
        return plan.additionalFeatures ?? [];
    }
  }
  __name(getTurnPlanTable, "getTurnPlanTable");
  function setTurnPlanTable(plan, table, value) {
    switch (table) {
      case "actions":
        return { ...plan, actions: value };
      case "bonusActions":
        return { ...plan, bonusActions: value };
      case "reactions":
        return { ...plan, reactions: value };
      default:
        return { ...plan, additionalFeatures: value };
    }
  }
  __name(setTurnPlanTable, "setTurnPlanTable");
  function findTurnPlanTable(plan, featureId) {
    return (plan.actions ?? []).some((f) => f.itemId === featureId) ? "actions" : (plan.bonusActions ?? []).some((f) => f.itemId === featureId) ? "bonusActions" : (plan.reactions ?? []).some((f) => f.itemId === featureId) ? "reactions" : (plan.additionalFeatures ?? []).some((f) => f.itemId === featureId) ? "additionalFeatures" : null;
  }
  __name(findTurnPlanTable, "findTurnPlanTable");
  function findReaction(reactionId) {
    const index2 = reactionId ? get$1(reactions).findIndex((r2) => r2.id === reactionId) : -1;
    return { index: index2, reaction: index2 >= 0 ? get$1(reactions)[index2] : null };
  }
  __name(findReaction, "findReaction");
  function isNotesCollapsed(reactionId) {
    return get$1(notesCollapsed)[reactionId] ?? !0;
  }
  __name(isNotesCollapsed, "isNotesCollapsed");
  function toggleNotes(reactionId) {
    set(
      notesCollapsed,
      {
        ...get$1(notesCollapsed),
        [reactionId]: !isNotesCollapsed(reactionId)
      },
      !0
    );
  }
  __name(toggleNotes, "toggleNotes");
  function isReactionCollapsed(reactionId) {
    return !!get$1(reactionCollapseState)[reactionId];
  }
  __name(isReactionCollapsed, "isReactionCollapsed");
  function toggleReactionCollapsed(reactionId) {
    set(
      reactionCollapseState,
      {
        ...get$1(reactionCollapseState),
        [reactionId]: !isReactionCollapsed(reactionId)
      },
      !0
    );
  }
  __name(toggleReactionCollapsed, "toggleReactionCollapsed");
  function cancelPendingSave(flush = !1) {
    const pending = !!saveTimeout;
    saveTimeout && (window.clearTimeout(saveTimeout), saveTimeout = null), flush && pending && saveReactions();
  }
  __name(cancelPendingSave, "cancelPendingSave");
  function scheduleAutoSave() {
    get$1(initialized) && (saveTimeout && window.clearTimeout(saveTimeout), saveTimeout = window.setTimeout(
      () => {
        saveTimeout = null, saveReactions();
      },
      AUTO_SAVE_DEBOUNCE_MS
    ));
  }
  __name(scheduleAutoSave, "scheduleAutoSave");
  function reorderReactions(fromIndex, toIndex) {
    if (!get$1(reactions).length) return;
    const next = moveArrayItem(get$1(reactions), fromIndex, toIndex);
    set(reactions, next, !0), scheduleAutoSave();
  }
  __name(reorderReactions, "reorderReactions");
  function createNewReaction() {
    const newReaction = {
      id: randomId(),
      name: "",
      trigger: "",
      reactionFeatures: [],
      additionalFeatures: [],
      notes: "",
      createdTime: Date.now(),
      isFavorite: !1
    };
    set(reactions, [...get$1(reactions), newReaction], !0), set(notesCollapsed, { ...get$1(notesCollapsed), [newReaction.id]: !0 }, !0), saveReactions();
  }
  __name(createNewReaction, "createNewReaction");
  function duplicateReaction(reactionId) {
    const sourceIndex = get$1(reactions).findIndex((reaction) => reaction.id === reactionId);
    if (sourceIndex === -1) return;
    const source2 = get$1(reactions)[sourceIndex], copySuffix = FoundryAdapter.localize("TURN_PREP.Common.CopySuffix") ?? "(Copy)", clone = {
      ...source2,
      id: randomId(),
      name: `${source2.name || FoundryAdapter.localize("TURN_PREP.Reactions.ReactionLabel")} ${copySuffix}`.trim(),
      reactionFeatures: cloneSelectedFeatureArray(source2.reactionFeatures),
      additionalFeatures: cloneSelectedFeatureArray(source2.additionalFeatures),
      createdTime: Date.now()
    };
    set(
      reactions,
      [
        ...get$1(reactions).slice(0, sourceIndex + 1),
        clone,
        ...get$1(reactions).slice(sourceIndex + 1)
      ],
      !0
    ), set(
      notesCollapsed,
      {
        ...get$1(notesCollapsed),
        [clone.id]: get$1(notesCollapsed)[source2.id] ?? !0
      },
      !0
    ), saveReactions();
  }
  __name(duplicateReaction, "duplicateReaction");
  async function handleFavoriteReaction(reactionId) {
    const reaction = get$1(reactions).find((r2) => r2.id === reactionId);
    if (!reaction) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.Reactions.Messages.ReactionMissing") ?? "Reaction not found");
      return;
    }
    try {
      const snapshot = createReactionFavoriteSnapshot(reaction), data = await TurnPrepStorage.load($$props.actor);
      data.reactions = get$1(reactions).map((r2) => sanitizeReaction(r2)), data.favoritesReaction = [...data.favoritesReaction ?? [], snapshot], await TurnPrepStorage.save($$props.actor, data);
    } catch (error2) {
      console.error("[ReactionPlansPanel] Failed to favorite reaction", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.Reactions.SaveError"));
    }
  }
  __name(handleFavoriteReaction, "handleFavoriteReaction");
  function getReactionFeatures(reaction) {
    const features = Array.isArray(reaction.reactionFeatures) ? reaction.reactionFeatures : [];
    return buildDisplayFeatureList($$props.actor, reaction.id, features, "reaction-primary");
  }
  __name(getReactionFeatures, "getReactionFeatures");
  function getAdditionalFeatures(reaction) {
    const extras = Array.isArray(reaction.additionalFeatures) ? reaction.additionalFeatures : [];
    return buildDisplayFeatureList($$props.actor, reaction.id, extras, "reaction-additional");
  }
  __name(getAdditionalFeatures, "getAdditionalFeatures");
  function handleRemoveFeature(reactionId, target, featureId) {
    const index2 = get$1(reactions).findIndex((reaction2) => reaction2.id === reactionId);
    if (index2 === -1) return;
    const updated = [...get$1(reactions)], reaction = {
      ...updated[index2],
      reactionFeatures: [...updated[index2].reactionFeatures ?? []],
      additionalFeatures: [...updated[index2].additionalFeatures ?? []]
    };
    target === "reaction" ? reaction.reactionFeatures = reaction.reactionFeatures.filter((feature) => feature.itemId !== featureId) : reaction.additionalFeatures = reaction.additionalFeatures.filter((feature) => feature.itemId !== featureId), updated[index2] = reaction, set(reactions, updated, !0), saveReactions();
  }
  __name(handleRemoveFeature, "handleRemoveFeature");
  async function deleteReaction(id) {
    if (!await window.foundry.applications.api.DialogV2.confirm({
      window: {
        title: FoundryAdapter.localize("TURN_PREP.Reactions.DeleteConfirm")
      },
      content: `<p>${FoundryAdapter.localize("TURN_PREP.Reactions.DeleteConfirmMessage")}</p>`
    })) return;
    set(reactions, get$1(reactions).filter((reaction) => reaction.id !== id), !0);
    const { [id]: _removed, ...remaining } = get$1(notesCollapsed);
    set(notesCollapsed, remaining, !0), saveReactions();
  }
  __name(deleteReaction, "deleteReaction");
  async function saveReactions() {
    if (!(!$$props.actor || get$1(isEditing)))
      try {
        const turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor) ?? createEmptyTurnPrepData();
        turnPrepData.reactions = get$1(reactions).map((reaction) => sanitizeReaction(reaction)), await TurnPrepApiInstance.saveTurnPrepData($$props.actor, turnPrepData);
      } catch (error2) {
        console.error("[ReactionPlansPanel] Failed to save reactions:", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.Reactions.SaveError"));
      }
  }
  __name(saveReactions, "saveReactions");
  async function saveFavorite() {
    if (!(!get$1(isEditing) || !get$1(reactions)[0] || !get$1(editSession)))
      try {
        const updatedReaction = get$1(reactions)[0], updatedSnapshot = createReactionFavoriteSnapshot(updatedReaction);
        updatedSnapshot.id = get$1(editSession).originalId;
        const data = await TurnPrepStorage.load($$props.actor), favorites = data.favoritesReaction ?? [], index2 = favorites.findIndex((f) => f.id === get$1(editSession).originalId);
        index2 >= 0 ? favorites[index2] = updatedSnapshot : favorites.push(updatedSnapshot), data.favoritesReaction = favorites, await TurnPrepStorage.save($$props.actor, data), ui.notifications?.info(FoundryAdapter.localize("TURN_PREP.Reactions.Messages.FavoriteSaved") || "Favorite updated."), editSessionStore.clearSession();
      } catch (error2) {
        console.error("[ReactionPlansPanel] Failed to save favorite:", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.Reactions.SaveError"));
      }
  }
  __name(saveFavorite, "saveFavorite");
  function cancelEdit() {
    editSessionStore.clearSession();
  }
  __name(cancelEdit, "cancelEdit");
  async function saveTurnPrepState(nextReactions, nextTurnPlans) {
    if ($$props.actor)
      try {
        const turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor) ?? createEmptyTurnPrepData();
        turnPrepData.reactions = nextReactions.map((reaction) => sanitizeReaction(reaction)), nextTurnPlans && (turnPrepData.turnPlans = nextTurnPlans), set(reactions, hydrateReactions(turnPrepData.reactions ?? []), !0), await TurnPrepApiInstance.saveTurnPrepData($$props.actor, turnPrepData, { render: !1 });
      } catch (error2) {
        console.error("[ReactionPlansPanel] Failed to save reactions:", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.Reactions.SaveError"));
      }
  }
  __name(saveTurnPrepState, "saveTurnPrepState");
  function handleFeatureReorder(reactionId, table, fromIndex, toIndex) {
    const { reaction, index: index2 } = findReaction(reactionId);
    if (!reaction || index2 === -1) return;
    const current = getReactionTable(reaction, table);
    if (!current.length) return;
    const next = moveArrayItem(current, fromIndex, toIndex), nextReactions = [...get$1(reactions)];
    nextReactions[index2] = setReactionTable(reaction, table, next), set(reactions, nextReactions, !0), scheduleAutoSave();
  }
  __name(handleFeatureReorder, "handleFeatureReorder");
  function removeFeatureFromReactionSource(reactionsList, sourceReactionId, featureId, tableGuess) {
    const sourceIndex = reactionsList.findIndex((r2) => r2.id === sourceReactionId);
    if (sourceIndex === -1) return reactionsList;
    const sourceReaction = reactionsList[sourceIndex], sourceTable = coerceReactionTable(tableGuess ?? "additionalFeatures"), filtered = getReactionTable(sourceReaction, sourceTable).filter((f) => f.itemId !== featureId), next = [...reactionsList];
    return next[sourceIndex] = setReactionTable(sourceReaction, sourceTable, filtered), next;
  }
  __name(removeFeatureFromReactionSource, "removeFeatureFromReactionSource");
  function removeFeatureFromTurnPlanSource(turnPlans, sourcePlanId, featureId, tableGuess) {
    const sourceIndex = turnPlans.findIndex((p) => p.id === sourcePlanId);
    if (sourceIndex === -1) return turnPlans;
    const sourcePlan = turnPlans[sourceIndex], sourceTable = coerceTurnTable(tableGuess ?? findTurnPlanTable(sourcePlan, featureId) ?? "additionalFeatures"), filtered = getTurnPlanTable(sourcePlan, sourceTable).filter((f) => f.itemId !== featureId), next = [...turnPlans];
    return next[sourceIndex] = setTurnPlanTable(sourcePlan, sourceTable, filtered), next;
  }
  __name(removeFeatureFromTurnPlanSource, "removeFeatureFromTurnPlanSource");
  async function handleFeatureDrop(event2) {
    if (event2.panelKind !== "reaction") return;
    const targetReactionId = event2.ownerId;
    if (!targetReactionId) return;
    let feature = event2.feature ?? null, activations = feature ? getActivationsForFeature(feature) : [];
    if (!feature && event2.nativeItemUuid) {
      const resolved = await buildFeatureFromUuid(event2.nativeItemUuid);
      feature = resolved.feature, activations = resolved.activations;
    }
    if (!feature) return;
    activations.length || (activations = getActivationsForFeature(feature));
    const targetTable = pickReactionTableForDrop(event2.table, activations), turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor) ?? createEmptyTurnPrepData();
    let nextReactions = Array.isArray(turnPrepData.reactions) ? [...turnPrepData.reactions] : [], nextTurnPlans = Array.isArray(turnPrepData.turnPlans) ? [...turnPrepData.turnPlans] : [];
    const reactionIndex = nextReactions.findIndex((r2) => r2.id === targetReactionId);
    if (reactionIndex === -1) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.Reactions.Messages.ReactionMissing") || "Reaction not found.");
      return;
    }
    !event2.copy && event2.source?.feature?.itemId && (event2.source.sourceReactionId ? nextReactions = removeFeatureFromReactionSource(nextReactions, event2.source.sourceReactionId, event2.source.feature.itemId, event2.source.sourceTable ?? null) : event2.source.sourcePlanId && (nextTurnPlans = removeFeatureFromTurnPlanSource(nextTurnPlans, event2.source.sourcePlanId, event2.source.feature.itemId, event2.source.sourceTable ?? null)));
    const targetReaction = nextReactions[reactionIndex], targetList = getReactionTable(targetReaction, targetTable);
    if (hasDuplicateFeature(targetList, feature)) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.DuplicateFeature"));
      return;
    }
    const insertAt = Math.max(0, Math.min(targetList.length, event2.targetIndex ?? targetList.length)), updatedList = [...targetList];
    updatedList.splice(insertAt, 0, cloneFeature(feature)), nextReactions[reactionIndex] = setReactionTable(targetReaction, targetTable, updatedList), await saveTurnPrepState(nextReactions, nextTurnPlans);
  }
  __name(handleFeatureDrop, "handleFeatureDrop");
  async function handleMoveCopyWithinReactions(fromReactionId, toReactionId, table, feature, copy) {
    const turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor) ?? createEmptyTurnPrepData();
    let nextReactions = Array.isArray(turnPrepData.reactions) ? [...turnPrepData.reactions] : [];
    const targetIndex = nextReactions.findIndex((r2) => r2.id === toReactionId);
    if (targetIndex === -1) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.Reactions.Messages.ReactionMissing") || "Reaction not found.");
      return;
    }
    const targetReaction = nextReactions[targetIndex], targetList = getReactionTable(targetReaction, table);
    if (hasDuplicateFeature(targetList, feature)) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.DuplicateFeature"));
      return;
    }
    !copy && fromReactionId && (nextReactions = removeFeatureFromReactionSource(nextReactions, fromReactionId, feature.itemId, table));
    const updated = [
      ...getReactionTable(nextReactions[targetIndex], table),
      cloneFeature(feature)
    ];
    nextReactions[targetIndex] = setReactionTable(nextReactions[targetIndex], table, updated), await saveTurnPrepState(nextReactions);
  }
  __name(handleMoveCopyWithinReactions, "handleMoveCopyWithinReactions");
  async function handleMoveCopyToTurnPlan(fromReactionId, planId, table, feature, copy) {
    const turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor) ?? createEmptyTurnPrepData();
    let nextReactions = Array.isArray(turnPrepData.reactions) ? [...turnPrepData.reactions] : [];
    const nextTurnPlans = Array.isArray(turnPrepData.turnPlans) ? [...turnPrepData.turnPlans] : [], planIndex = nextTurnPlans.findIndex((p) => p.id === planId);
    if (planIndex === -1) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.PlanMissing") || "Plan not found.");
      return;
    }
    const targetPlan = nextTurnPlans[planIndex], targetList = getTurnPlanTable(targetPlan, table);
    if (hasDuplicateFeature(targetList, feature)) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.DuplicateFeature"));
      return;
    }
    !copy && fromReactionId && (nextReactions = removeFeatureFromReactionSource(nextReactions, fromReactionId, feature.itemId, "reactionFeatures"));
    const updatedPlanList = [...targetList, cloneFeature(feature)];
    nextTurnPlans[planIndex] = setTurnPlanTable(targetPlan, table, updatedPlanList), await saveTurnPrepState(nextReactions, nextTurnPlans);
  }
  __name(handleMoveCopyToTurnPlan, "handleMoveCopyToTurnPlan");
  function buildReactionMoveCopyMenu(currentReactionId, feature, copy) {
    const sections = [], activations = getActivationsForFeature(feature), activationSet = new Set(activations.map((a) => normalizeActionType(a))), allowReaction = activationSet.has("reaction"), allowAction = activationSet.has("action"), allowBonus = activationSet.has("bonus"), reactionActions = [];
    for (const reaction of get$1(reactions))
      reaction.id !== currentReactionId && (allowReaction && reactionActions.push({
        id: `${reaction.id}-reaction-${copy ? "copy" : "move"}`,
        label: `${reaction.name || FoundryAdapter.localize("TURN_PREP.Reactions.ReactionLabel")} - ${FoundryAdapter.localize("TURN_PREP.Reactions.ReactionFeatures")}`,
        icon: "fa-solid fa-bolt",
        onSelect: /* @__PURE__ */ __name(() => handleMoveCopyWithinReactions(currentReactionId, reaction.id, "reactionFeatures", feature, copy), "onSelect")
      }), reactionActions.push({
        id: `${reaction.id}-additional-${copy ? "copy" : "move"}`,
        label: `${reaction.name || FoundryAdapter.localize("TURN_PREP.Reactions.ReactionLabel")} - ${FoundryAdapter.localize("TURN_PREP.Reactions.AdditionalFeatures")}`,
        icon: "fa-regular fa-circle-dot",
        onSelect: /* @__PURE__ */ __name(() => handleMoveCopyWithinReactions(currentReactionId, reaction.id, "additionalFeatures", feature, copy), "onSelect")
      }));
    reactionActions.length && sections.push({
      id: `reaction-destinations-${copy ? "copy" : "move"}`,
      label: FoundryAdapter.localize("TURN_PREP.Reactions.Title") || "Reactions",
      actions: reactionActions
    });
    try {
      const plans = TurnPrepApiInstance.getTurnPrepData($$props.actor)?.turnPlans ?? [], turnActions = [];
      for (const plan of plans)
        allowAction && turnActions.push({
          id: `${plan.id}-action-${copy ? "copy" : "move"}`,
          label: `${plan.name} - ${FoundryAdapter.localize("TURN_PREP.TurnPlans.Actions")}`,
          icon: "fa-solid fa-person-running",
          onSelect: /* @__PURE__ */ __name(() => handleMoveCopyToTurnPlan(currentReactionId, plan.id, "actions", feature, copy), "onSelect")
        }), allowBonus && turnActions.push({
          id: `${plan.id}-bonus-${copy ? "copy" : "move"}`,
          label: `${plan.name} - ${FoundryAdapter.localize("TURN_PREP.TurnPlans.BonusActions")}`,
          icon: "fa-solid fa-plus",
          onSelect: /* @__PURE__ */ __name(() => handleMoveCopyToTurnPlan(currentReactionId, plan.id, "bonusActions", feature, copy), "onSelect")
        }), turnActions.push({
          id: `${plan.id}-additional-${copy ? "copy" : "move"}`,
          label: `${plan.name} - ${FoundryAdapter.localize("TURN_PREP.TurnPlans.AdditionalFeatures")}`,
          icon: "fa-regular fa-circle-dot",
          onSelect: /* @__PURE__ */ __name(() => handleMoveCopyToTurnPlan(currentReactionId, plan.id, "additionalFeatures", feature, copy), "onSelect")
        });
      turnActions.length && sections.push({
        id: `turn-destinations-${copy ? "copy" : "move"}`,
        label: FoundryAdapter.localize("TURN_PREP.TurnPlans.Title") || "Turns",
        actions: turnActions
      });
    } catch (error2) {
      console.warn("[ReactionPlansPanel] Failed to build turn destination menu", error2);
    }
    return sections;
  }
  __name(buildReactionMoveCopyMenu, "buildReactionMoveCopyMenu");
  function getReactionContextMenuActions(reaction) {
    const index2 = get$1(reactions).findIndex((r2) => r2.id === reaction.id), total = get$1(reactions).length, arrangeActions = index2 === -1 ? [] : [
      {
        id: "move-up",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveUp") || "Move Up",
        icon: "fa-solid fa-angle-up",
        onSelect: /* @__PURE__ */ __name(() => reorderReactions(index2, Math.max(0, index2 - 1)), "onSelect")
      },
      {
        id: "move-down",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveDown") || "Move Down",
        icon: "fa-solid fa-angle-down",
        onSelect: /* @__PURE__ */ __name(() => reorderReactions(index2, Math.min(total - 1, index2 + 1)), "onSelect")
      },
      {
        id: "move-top",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveTop") || "Move to Top",
        icon: "fa-solid fa-angles-up",
        onSelect: /* @__PURE__ */ __name(() => reorderReactions(index2, 0), "onSelect")
      },
      {
        id: "move-bottom",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveBottom") || "Move to Bottom",
        icon: "fa-solid fa-angles-down",
        onSelect: /* @__PURE__ */ __name(() => reorderReactions(index2, total - 1), "onSelect")
      }
    ], arrangeSubmenu = arrangeActions.length ? [{ id: `${reaction.id}-reorder`, actions: arrangeActions }] : [], favoriteLabel = resolveFavoriteReactionLabel();
    return [
      {
        id: "duplicate",
        label: FoundryAdapter.localize("TURN_PREP.Reactions.ContextMenu.Duplicate"),
        icon: "fa-regular fa-copy",
        onSelect: /* @__PURE__ */ __name(() => duplicateReaction(reaction.id), "onSelect")
      },
      {
        id: "delete",
        label: FoundryAdapter.localize("TURN_PREP.Reactions.ContextMenu.Delete"),
        icon: "fa-regular fa-trash-can",
        variant: "destructive",
        onSelect: /* @__PURE__ */ __name(() => {
          deleteReaction(reaction.id);
        }, "onSelect")
      },
      {
        id: "favorite",
        label: favoriteLabel,
        icon: "fa-regular fa-star",
        onSelect: /* @__PURE__ */ __name(() => {
          handleFavoriteReaction(reaction.id);
        }, "onSelect")
      },
      ...arrangeSubmenu.length ? [
        {
          id: "arrange",
          label: FoundryAdapter.localize("TURN_PREP.ContextMenu.Arrange") || "Arrange",
          icon: "fa-solid fa-arrow-up-wide-short",
          submenu: arrangeSubmenu,
          onSelect: /* @__PURE__ */ __name(() => {
          }, "onSelect")
        }
      ] : []
    ];
  }
  __name(getReactionContextMenuActions, "getReactionContextMenuActions");
  function resolveFavoriteReactionLabel() {
    const primary = FoundryAdapter.localize("TURN_PREP.Reactions.ContextMenu.AddToFavorites");
    if (primary && primary !== "TURN_PREP.Reactions.ContextMenu.AddToFavorites") return primary;
    const common = FoundryAdapter.localize("TURN_PREP.Common.AddToFavorites");
    return common && common !== "TURN_PREP.Common.AddToFavorites" ? common : "Add to Favorites";
  }
  __name(resolveFavoriteReactionLabel, "resolveFavoriteReactionLabel");
  function buildReactionContextMenuSections(reaction) {
    return [
      {
        id: `reaction-menu-${reaction.id}`,
        actions: getReactionContextMenuActions(reaction)
      }
    ];
  }
  __name(buildReactionContextMenuSections, "buildReactionContextMenuSections");
  function openReactionContextMenu(reaction, position, anchor) {
    reactionContextMenuController.open({
      sections: buildReactionContextMenuSections(reaction),
      position,
      anchorElement: anchor ?? null,
      context: {
        reactionId: reaction.id,
        ariaLabel: `${reaction.name || FoundryAdapter.localize("TURN_PREP.Reactions.ReactionLabel")} ${FoundryAdapter.localize("TURN_PREP.Reactions.ContextMenuLabel")}`
      }
    });
  }
  __name(openReactionContextMenu, "openReactionContextMenu");
  function handleReactionContextMenu(reaction, event2) {
    event2.preventDefault(), event2.stopPropagation(), openReactionContextMenu(reaction, { x: event2.clientX, y: event2.clientY }, event2.currentTarget);
  }
  __name(handleReactionContextMenu, "handleReactionContextMenu");
  function handleReactionMenuButton(reaction, event2) {
    event2.preventDefault(), event2.stopPropagation();
    const button = event2.currentTarget;
    if (button) {
      const rect = button.getBoundingClientRect();
      openReactionContextMenu(reaction, { x: rect.right, y: rect.bottom + 4 }, button);
      return;
    }
    openReactionContextMenu(reaction, { x: event2.clientX, y: event2.clientY });
  }
  __name(handleReactionMenuButton, "handleReactionMenuButton");
  var fragment = root$3(), node = first_child(fragment);
  {
    var consequent = /* @__PURE__ */ __name(($$anchor2) => {
      var div = root_1$3(), p_1 = child(div), text = child(p_1);
      template_effect(($0) => set_text(text, $0), [() => FoundryAdapter.localize("TURN_PREP.Common.Loading")]), append($$anchor2, div);
    }, "consequent"), alternate_2 = /* @__PURE__ */ __name(($$anchor2) => {
      var div_1 = root_2$3(), div_2 = child(div_1), node_1 = child(div_2);
      {
        var consequent_1 = /* @__PURE__ */ __name(($$anchor3) => {
          var button_1 = root_3$3();
          button_1.__click = () => set(collapsed, !get$1(collapsed));
          var i = child(button_1);
          template_effect(() => {
            set_attribute(button_1, "title", get$1(collapsed) ? "Expand" : "Collapse"), set_class(i, 1, `fas fa-chevron-${get$1(collapsed) ? "right" : "down"}`);
          }), append($$anchor3, button_1);
        }, "consequent_1");
        if_block(node_1, ($$render) => {
          get$1(isEditing) || $$render(consequent_1);
        });
      }
      var h3 = sibling(node_1, 2), text_1 = child(h3), node_2 = sibling(h3, 2);
      {
        var consequent_2 = /* @__PURE__ */ __name(($$anchor3) => {
          var div_3 = root_4$2(), button_2 = child(div_3);
          button_2.__click = saveFavorite;
          var text_2 = sibling(child(button_2)), button_3 = sibling(button_2, 2);
          button_3.__click = cancelEdit;
          var text_3 = sibling(child(button_3));
          template_effect(
            ($0, $1) => {
              set_text(text_2, ` ${$0 ?? ""}`), set_text(text_3, ` ${$1 ?? ""}`);
            },
            [
              () => FoundryAdapter.localize("TURN_PREP.Common.Save") || "Save",
              () => FoundryAdapter.localize("TURN_PREP.Common.Cancel") || "Cancel"
            ]
          ), append($$anchor3, div_3);
        }, "consequent_2"), alternate = /* @__PURE__ */ __name(($$anchor3) => {
          var button_4 = root_5$1();
          button_4.__click = createNewReaction;
          var text_4 = sibling(child(button_4));
          template_effect(($0) => set_text(text_4, ` ${$0 ?? ""}`), [
            () => FoundryAdapter.localize("TURN_PREP.Reactions.NewReaction")
          ]), append($$anchor3, button_4);
        }, "alternate");
        if_block(node_2, ($$render) => {
          get$1(isEditing) ? $$render(consequent_2) : $$render(alternate, !1);
        });
      }
      var node_3 = sibling(div_2, 2);
      {
        var consequent_9 = /* @__PURE__ */ __name(($$anchor3) => {
          var fragment_1 = comment(), node_4 = first_child(fragment_1);
          {
            var consequent_3 = /* @__PURE__ */ __name(($$anchor4) => {
              var div_4 = root_7$2(), p_2 = child(div_4), text_5 = child(p_2);
              template_effect(($0) => set_text(text_5, $0), [
                () => FoundryAdapter.localize("TURN_PREP.Reactions.NoReactions")
              ]), append($$anchor4, div_4);
            }, "consequent_3"), alternate_1 = /* @__PURE__ */ __name(($$anchor4) => {
              var div_5 = root_8$2();
              each(div_5, 21, () => get$1(reactions), (reaction) => reaction.id, ($$anchor5, reaction, $$index) => {
                var fragment_2 = comment(), node_5 = first_child(fragment_2);
                {
                  var consequent_8 = /* @__PURE__ */ __name(($$anchor6) => {
                    var div_6 = root_10$2();
                    div_6.__contextmenu = (event2) => handleReactionContextMenu(get$1(reaction), event2);
                    var div_7 = child(div_6), div_8 = child(div_7), node_6 = child(div_8);
                    {
                      var consequent_4 = /* @__PURE__ */ __name(($$anchor7) => {
                        var button_5 = root_11$2();
                        button_5.__click = () => toggleReactionCollapsed(get$1(reaction).id);
                        var i_1 = child(button_5);
                        template_effect(
                          ($0, $1) => {
                            set_attribute(button_5, "aria-label", $0), set_class(i_1, 1, $1, "svelte-tp-a69jix");
                          },
                          [
                            () => FoundryAdapter.localize("TURN_PREP.Reactions.ToggleBody"),
                            () => `fas fa-chevron-${isReactionCollapsed(get$1(reaction).id) ? "right" : "down"}`
                          ]
                        ), append($$anchor7, button_5);
                      }, "consequent_4");
                      if_block(node_6, ($$render) => {
                        get$1(isEditing) || $$render(consequent_4);
                      });
                    }
                    var label = sibling(node_6, 2), text_6 = child(label), input = sibling(label, 2);
                    input.__input = (e) => {
                      const val = e.currentTarget.value;
                      get$1(reaction).name = val, get$1(reaction).trigger = val, scheduleAutoSave();
                    };
                    var node_7 = sibling(div_8, 2);
                    {
                      var consequent_5 = /* @__PURE__ */ __name(($$anchor7) => {
                        var button_6 = root_12$2();
                        button_6.__click = (event2) => handleReactionMenuButton(get$1(reaction), event2), template_effect(
                          ($0, $1) => {
                            set_attribute(button_6, "aria-label", $0), set_attribute(button_6, "title", $1);
                          },
                          [
                            () => FoundryAdapter.localize("TURN_PREP.ContextMenu.OpenLabel"),
                            () => FoundryAdapter.localize("TURN_PREP.ContextMenu.OpenLabel")
                          ]
                        ), append($$anchor7, button_6);
                      }, "consequent_5");
                      if_block(node_7, ($$render) => {
                        get$1(isEditing) || $$render(consequent_5);
                      });
                    }
                    var node_8 = sibling(div_7, 2);
                    {
                      var consequent_7 = /* @__PURE__ */ __name(($$anchor7) => {
                        var div_9 = root_13$1(), node_9 = child(div_9);
                        {
                          let $0 = /* @__PURE__ */ user_derived(() => `reaction-${get$1(reaction).id}`), $1 = /* @__PURE__ */ user_derived(() => FoundryAdapter.localize("TURN_PREP.Reactions.ReactionFeatures")), $2 = /* @__PURE__ */ user_derived(() => getReactionFeatures(get$1(reaction)));
                          TurnPlanFeatureTable(node_9, {
                            get tableKey() {
                              return get$1($0);
                            },
                            get ownerId() {
                              return get$1(reaction).id;
                            },
                            panelKind: "reaction",
                            tableType: "reactionFeatures",
                            get title() {
                              return get$1($1);
                            },
                            get actor() {
                              return $$props.actor;
                            },
                            get features() {
                              return get$1($2);
                            },
                            onFeatureDrop: /* @__PURE__ */ __name((payload) => {
                              handleFeatureDrop(payload);
                            }, "onFeatureDrop"),
                            onReorderFeature: /* @__PURE__ */ __name((from, to) => handleFeatureReorder(get$1(reaction).id, "reactionFeatures", from, to), "onReorderFeature"),
                            buildMoveToMenu: /* @__PURE__ */ __name((feature) => buildReactionMoveCopyMenu(get$1(reaction).id, feature, !1), "buildMoveToMenu"),
                            buildCopyToMenu: /* @__PURE__ */ __name((feature) => buildReactionMoveCopyMenu(get$1(reaction).id, feature, !0), "buildCopyToMenu"),
                            onRemoveFeature: /* @__PURE__ */ __name((featureId) => handleRemoveFeature(get$1(reaction).id, "reaction", featureId), "onRemoveFeature")
                          });
                        }
                        var node_10 = sibling(node_9, 2);
                        {
                          let $0 = /* @__PURE__ */ user_derived(() => `reaction-additional-${get$1(reaction).id}`), $1 = /* @__PURE__ */ user_derived(() => FoundryAdapter.localize("TURN_PREP.Reactions.AdditionalFeatures")), $2 = /* @__PURE__ */ user_derived(() => getAdditionalFeatures(get$1(reaction)));
                          TurnPlanFeatureTable(node_10, {
                            get tableKey() {
                              return get$1($0);
                            },
                            get ownerId() {
                              return get$1(reaction).id;
                            },
                            panelKind: "reaction",
                            tableType: "additionalFeatures",
                            get title() {
                              return get$1($1);
                            },
                            get actor() {
                              return $$props.actor;
                            },
                            get features() {
                              return get$1($2);
                            },
                            onFeatureDrop: /* @__PURE__ */ __name((payload) => {
                              handleFeatureDrop(payload);
                            }, "onFeatureDrop"),
                            onReorderFeature: /* @__PURE__ */ __name((from, to) => handleFeatureReorder(get$1(reaction).id, "additionalFeatures", from, to), "onReorderFeature"),
                            buildMoveToMenu: /* @__PURE__ */ __name((feature) => buildReactionMoveCopyMenu(get$1(reaction).id, feature, !1), "buildMoveToMenu"),
                            buildCopyToMenu: /* @__PURE__ */ __name((feature) => buildReactionMoveCopyMenu(get$1(reaction).id, feature, !0), "buildCopyToMenu"),
                            onRemoveFeature: /* @__PURE__ */ __name((featureId) => handleRemoveFeature(get$1(reaction).id, "additional", featureId), "onRemoveFeature")
                          });
                        }
                        var div_10 = sibling(node_10, 2), button_7 = child(div_10);
                        button_7.__click = () => toggleNotes(get$1(reaction).id);
                        var i_2 = child(button_7), span = sibling(i_2, 2), text_7 = child(span), node_11 = sibling(button_7, 2);
                        {
                          var consequent_6 = /* @__PURE__ */ __name(($$anchor8) => {
                            var div_11 = root_14(), textarea = child(div_11);
                            textarea.__input = scheduleAutoSave, template_effect(($0) => set_attribute(textarea, "placeholder", $0), [
                              () => FoundryAdapter.localize("TURN_PREP.Reactions.NotesPlaceholder")
                            ]), bind_value(textarea, () => get$1(reaction).notes, ($$value) => get$1(reaction).notes = $$value), append($$anchor8, div_11);
                          }, "consequent_6");
                          if_block(node_11, ($$render) => {
                            isNotesCollapsed(get$1(reaction).id) || $$render(consequent_6);
                          });
                        }
                        template_effect(
                          ($0, $1, $2) => {
                            set_class(div_10, 1, $0, "svelte-tp-a69jix"), set_class(i_2, 1, `fas fa-chevron-${$1 ?? ""}`), set_text(text_7, $2);
                          },
                          [
                            () => `turn-prep-collapsible reaction-notes ${isNotesCollapsed(get$1(reaction).id) ? "" : "is-open"}`,
                            () => isNotesCollapsed(get$1(reaction).id) ? "right" : "down",
                            () => FoundryAdapter.localize("TURN_PREP.Reactions.Notes")
                          ]
                        ), append($$anchor7, div_9);
                      }, "consequent_7");
                      if_block(node_8, ($$render) => {
                        isReactionCollapsed(get$1(reaction).id) || $$render(consequent_7);
                      });
                    }
                    template_effect(
                      ($0, $1, $2) => {
                        set_class(div_6, 1, $0, "svelte-tp-a69jix"), set_attribute(label, "for", "reaction-name-" + get$1(reaction).id), set_text(text_6, $1), set_attribute(input, "id", "reaction-name-" + get$1(reaction).id), set_value(input, get$1(reaction).name), set_attribute(input, "placeholder", $2);
                      },
                      [
                        () => `turn-prep-panel-card reaction-card ${isReactionCollapsed(get$1(reaction).id) ? "is-collapsed" : ""} ${get$1(activeContextReactionId) === get$1(reaction).id ? "is-context-open" : ""}`,
                        () => FoundryAdapter.localize("TURN_PREP.Reactions.Trigger"),
                        () => FoundryAdapter.localize("TURN_PREP.Reactions.TriggerPlaceholder")
                      ]
                    ), append($$anchor6, div_6);
                  }, "consequent_8");
                  if_block(node_5, ($$render) => {
                    (!get$1(isEditing) || get$1(editSession)?.originalId === get$1(reaction).id) && $$render(consequent_8);
                  });
                }
                append($$anchor5, fragment_2);
              }), append($$anchor4, div_5);
            }, "alternate_1");
            if_block(node_4, ($$render) => {
              get$1(reactions).length === 0 ? $$render(consequent_3) : $$render(alternate_1, !1);
            });
          }
          append($$anchor3, fragment_1);
        }, "consequent_9");
        if_block(node_3, ($$render) => {
          get$1(collapsed) || $$render(consequent_9);
        });
      }
      template_effect(($0) => set_text(text_1, $0), [
        () => get$1(isEditing) ? FoundryAdapter.localize("TURN_PREP.Reactions.EditTitle") || "Editing Favorite Reaction" : FoundryAdapter.localize("TURN_PREP.Reactions.Title")
      ]), append($$anchor2, div_1);
    }, "alternate_2");
    if_block(node, ($$render) => {
      get$1(loading) ? $$render(consequent) : $$render(alternate_2, !1);
    });
  }
  var node_12 = sibling(node, 2);
  ContextMenuHost(node_12, {
    get controller() {
      return reactionContextMenuController;
    }
  }), append($$anchor, fragment), pop();
}
__name(ReactionPlansPanel, "ReactionPlansPanel");
delegate(["click", "contextmenu", "input"]);
var root_1$2 = /* @__PURE__ */ from_html('<div class="turn-prep-panel-loading turn-plans-loading"><p> </p></div>'), root_3$2 = /* @__PURE__ */ from_html('<button type="button" class="turn-prep-panel-toggle"><i></i></button>'), root_4$1 = /* @__PURE__ */ from_html('<div style="display: flex; gap: 0.5rem;"><button type="button" class="turn-prep-panel-action-btn"><i class="fas fa-save"></i> </button> <button type="button" class="turn-prep-panel-action-btn" style="background: rgba(200, 50, 50, 0.2);"><i class="fas fa-times"></i> </button></div>'), root_5 = /* @__PURE__ */ from_html('<button type="button" class="turn-prep-panel-action-btn"><i class="fas fa-plus"></i> </button>'), root_7$1 = /* @__PURE__ */ from_html('<div class="turn-prep-panel-empty turn-plans-empty"><p> </p></div>'), root_10$1 = /* @__PURE__ */ from_html('<button type="button" class="plan-collapse-button svelte-tp-jbd3d"><i></i></button>'), root_11$1 = /* @__PURE__ */ from_html('<button type="button" class="plan-menu-button svelte-tp-jbd3d"><i class="fas fa-ellipsis-vertical"></i></button>'), root_13 = /* @__PURE__ */ from_html('<div class="turn-prep-collapsible__body"><div class="turn-plan-notes__table" role="table"><label class="turn-plan-notes__label"> </label> <textarea class="turn-prep-textarea turn-plan-notes__input turn-plan-notes__input--single" rows="1"></textarea> <label class="turn-plan-notes__label"> </label> <textarea class="turn-prep-textarea turn-plan-notes__input turn-plan-notes__input--single" rows="1"></textarea> <label class="turn-plan-notes__label"> </label> <textarea class="turn-prep-textarea turn-plan-notes__input turn-plan-notes__input--double" rows="2"></textarea></div></div>'), root_12$1 = /* @__PURE__ */ from_html('<div class="plan-content svelte-tp-jbd3d"><div class="plan-feature-sections svelte-tp-jbd3d"><!> <!> <!></div> <div class="turn-plan-notes"><div class="turn-prep-collapsible"><button type="button" class="turn-prep-collapsible__toggle"><i></i> </button> <!></div></div></div>'), root_9$1 = /* @__PURE__ */ from_html('<div role="group"><div class="plan-header svelte-tp-jbd3d"><!> <input type="text" class="turn-prep-input plan-name svelte-tp-jbd3d"/> <!></div> <!></div>'), root_8$1 = /* @__PURE__ */ from_html('<div class="turn-prep-panel-list turn-plans-list is-tight"></div>'), root_2$2 = /* @__PURE__ */ from_html('<div class="turn-prep-panel turn-plans-panel"><div class="turn-prep-panel-header"><!> <h3> </h3> <!></div> <!></div>'), root$2 = /* @__PURE__ */ from_html("<!> <!>", 1);
function TurnPlansPanel($$anchor, $$props) {
  push($$props, !0);
  const PANEL_UI_CACHE_KEY = "__turnPrepPlanUiState", panelUiStateCache = globalThis[PANEL_UI_CACHE_KEY] ?? (globalThis[PANEL_UI_CACHE_KEY] = /* @__PURE__ */ new Map());
  let isEditing = /* @__PURE__ */ state(!1), editSession = /* @__PURE__ */ state(null), plans = /* @__PURE__ */ state(proxy([])), loading = /* @__PURE__ */ state(!0), initialized = /* @__PURE__ */ state(!1), collapsed = /* @__PURE__ */ state(!1), notesSectionState = /* @__PURE__ */ state(proxy({})), planCardCollapseState = /* @__PURE__ */ state(proxy({}));
  const planContextMenuController = new ContextMenuController("turn-plans-panel");
  let activeContextPlanId = /* @__PURE__ */ state(null), lastSavedTurnPlansSignature = null, panelRootElement = /* @__PURE__ */ state(null), panelScrollContainer = null, pendingScrollTop = null, currentScrollTop = 0, detachScrollListener = null, saveTimeout = null;
  const hookCleanups = [];
  function randomId() {
    const foundryRandom = globalThis.foundry?.utils?.randomID;
    return typeof foundryRandom == "function" ? foundryRandom() : typeof crypto?.randomUUID == "function" ? crypto.randomUUID() : Math.random().toString(36).slice(2);
  }
  __name(randomId, "randomId"), onMount(() => {
    restoreUiStateFromCache(), loadPlans(!0), applyPendingScrollPosition(), registerHook("updateActor", onActorUpdated), registerHook("updateItem", onItemChanged), registerHook("deleteItem", onItemChanged);
    const unsubscribeContextMenu = planContextMenuController.subscribe((state2) => {
      const contextPlanId = state2?.context?.planId;
      set(activeContextPlanId, typeof contextPlanId == "string" ? contextPlanId : null, !0);
    }), unsubscribeEditSession = editSessionStore.subscribe((session) => {
      if (session?.actorId === $$props.actor?.id && session?.kind === "turn") {
        if (!get$1(isEditing)) {
          set(isEditing, !0), set(editSession, session, !0);
          const p = snapshotToPlan(session.snapshot);
          p.id = session.originalId, set(plans, [p], !0);
          const nextCollapseState = { ...get$1(planCardCollapseState), [p.id]: !1 };
          set(planCardCollapseState, nextCollapseState, !0);
          const nextNotesState = { ...get$1(notesSectionState), [p.id]: !0 };
          set(notesSectionState, nextNotesState, !0);
        }
        if (get$1(isEditing) && session.pendingFeatures.length > 0) {
          const updatedPlans = [...get$1(plans)], plan = updatedPlans[0];
          let changed = !1;
          session.pendingFeatures.forEach(({ feature, mode }) => {
            mode === "action" ? hasDuplicateFeature(plan.actions, feature) || (plan.actions = [...plan.actions ?? [], feature], changed = !0) : mode === "bonus" ? hasDuplicateFeature(plan.bonusActions, feature) || (plan.bonusActions = [...plan.bonusActions ?? [], feature], changed = !0) : mode === "reaction" ? hasDuplicateFeature(plan.reactions, feature) || (plan.reactions = [...plan.reactions ?? [], feature], changed = !0) : hasDuplicateFeature(plan.additionalFeatures, feature) || (plan.additionalFeatures = [...plan.additionalFeatures ?? [], feature], changed = !0);
          }), changed && (set(plans, updatedPlans, !0), editSessionStore.clearPendingFeatures());
        }
      } else
        get$1(isEditing) && (set(isEditing, !1), set(editSession, null), loadPlans(!1));
    });
    return () => {
      persistUiStateToCache(), cleanupHooks(), cancelPendingSave(!0), unsubscribeContextMenu(), unsubscribeEditSession(), detachScrollListener?.(), detachScrollListener = null;
    };
  });
  function registerHook(hookName, handler) {
    if (typeof Hooks > "u") return;
    const hookId = Hooks.on(hookName, handler);
    hookCleanups.push(() => Hooks.off(hookName, hookId));
  }
  __name(registerHook, "registerHook");
  function cleanupHooks() {
    for (; hookCleanups.length; )
      hookCleanups.pop()?.();
  }
  __name(cleanupHooks, "cleanupHooks");
  function onActorUpdated(updatedActor, changes) {
    !$$props.actor || updatedActor?.id !== $$props.actor.id || shouldIgnoreActorUpdate(changes) || hasTurnPrepFlagChange(changes) && loadPlans();
  }
  __name(onActorUpdated, "onActorUpdated");
  function getTurnPrepFlagChangePayload(changes) {
    return changes?.flags?.[FLAG_SCOPE]?.[FLAG_KEY_DATA];
  }
  __name(getTurnPrepFlagChangePayload, "getTurnPrepFlagChangePayload");
  function hasTurnPrepFlagChange(changes) {
    return !!getTurnPrepFlagChangePayload(changes);
  }
  __name(hasTurnPrepFlagChange, "hasTurnPrepFlagChange");
  function shouldIgnoreActorUpdate(changes) {
    if (!lastSavedTurnPlansSignature) return !1;
    const payload = getTurnPrepFlagChangePayload(changes);
    return payload ? JSON.stringify(payload.turnPlans ?? []) === lastSavedTurnPlansSignature : !1;
  }
  __name(shouldIgnoreActorUpdate, "shouldIgnoreActorUpdate");
  function onItemChanged(item) {
    !$$props.actor || !item?.actor || item.actor.id !== $$props.actor.id || touchPlans();
  }
  __name(onItemChanged, "onItemChanged");
  function touchPlans() {
    set(plans, get$1(plans).map((plan) => ({ ...plan })), !0);
  }
  __name(touchPlans, "touchPlans");
  function getUiCacheKey() {
    return $$props.actor?.id ?? null;
  }
  __name(getUiCacheKey, "getUiCacheKey");
  function restoreUiStateFromCache() {
    const key = getUiCacheKey();
    if (!key) return;
    const cached = panelUiStateCache.get(key);
    cached && (set(notesSectionState, { ...cached.notesState }, !0), set(planCardCollapseState, { ...cached.collapseState }, !0), pendingScrollTop = typeof cached.scrollTop == "number" ? cached.scrollTop : null, typeof cached.scrollTop == "number" && (currentScrollTop = cached.scrollTop));
  }
  __name(restoreUiStateFromCache, "restoreUiStateFromCache");
  function persistUiStateToCache() {
    const key = getUiCacheKey();
    key && panelUiStateCache.set(key, {
      notesState: { ...get$1(notesSectionState) },
      collapseState: { ...get$1(planCardCollapseState) },
      scrollTop: panelScrollContainer?.scrollTop ?? currentScrollTop ?? 0
    });
  }
  __name(persistUiStateToCache, "persistUiStateToCache");
  function handlePanelScroll() {
    panelScrollContainer && (currentScrollTop = panelScrollContainer.scrollTop);
  }
  __name(handlePanelScroll, "handlePanelScroll");
  function resolveScrollContainer() {
    if (!get$1(panelRootElement)) return null;
    const tabParent = get$1(panelRootElement).closest(".tab");
    if (tabParent instanceof HTMLElement)
      return tabParent;
    const sheetBody = get$1(panelRootElement).closest(".sheet-body");
    return sheetBody instanceof HTMLElement ? sheetBody : get$1(panelRootElement);
  }
  __name(resolveScrollContainer, "resolveScrollContainer");
  function updateScrollContainerBinding() {
    if (detachScrollListener?.(), panelScrollContainer = resolveScrollContainer(), !panelScrollContainer) {
      detachScrollListener = null;
      return;
    }
    const handler = /* @__PURE__ */ __name(() => handlePanelScroll(), "handler");
    panelScrollContainer.addEventListener("scroll", handler, { passive: !0 }), detachScrollListener = /* @__PURE__ */ __name(() => {
      panelScrollContainer?.removeEventListener("scroll", handler);
    }, "detachScrollListener"), currentScrollTop = panelScrollContainer.scrollTop;
  }
  __name(updateScrollContainerBinding, "updateScrollContainerBinding");
  async function applyPendingScrollPosition() {
    if (pendingScrollTop === null) return;
    const target = pendingScrollTop;
    pendingScrollTop = null, await tick(), panelScrollContainer && (panelScrollContainer.scrollTop = target, currentScrollTop = target);
  }
  __name(applyPendingScrollPosition, "applyPendingScrollPosition"), user_effect(() => {
    if (!get$1(panelRootElement)) {
      detachScrollListener?.(), detachScrollListener = null, panelScrollContainer = null;
      return;
    }
    return updateScrollContainerBinding(), () => {
      detachScrollListener?.(), detachScrollListener = null, panelScrollContainer = null;
    };
  });
  function duplicatePlan(planId) {
    const sourceIndex = get$1(plans).findIndex((plan) => plan.id === planId);
    if (sourceIndex === -1) return;
    const source2 = get$1(plans)[sourceIndex], clone = {
      ...source2,
      id: randomId(),
      name: `${source2.name} ${FoundryAdapter.localize("TURN_PREP.Common.CopySuffix") ?? "(Copy)"}`,
      actions: cloneSelectedFeatureArray(source2.actions),
      bonusActions: cloneSelectedFeatureArray(source2.bonusActions),
      reactions: cloneSelectedFeatureArray(source2.reactions),
      additionalFeatures: cloneSelectedFeatureArray(source2.additionalFeatures),
      categories: Array.isArray(source2.categories) ? [...source2.categories] : []
    };
    set(
      plans,
      [
        ...get$1(plans).slice(0, sourceIndex + 1),
        clone,
        ...get$1(plans).slice(sourceIndex + 1)
      ],
      !0
    ), syncNotesSectionState(get$1(plans)), syncPlanCardCollapseState(get$1(plans)), savePlans();
  }
  __name(duplicatePlan, "duplicatePlan");
  function loadPlans(showSpinner = !1) {
    if (!$$props.actor) {
      set(plans, [], !0), set(loading, !1), set(initialized, !0), set(notesSectionState, {}, !0), set(planCardCollapseState, {}, !0), lastSavedTurnPlansSignature = null;
      return;
    }
    showSpinner && set(loading, !0);
    try {
      const turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor);
      set(plans, hydratePlans(turnPrepData?.turnPlans ?? []), !0), lastSavedTurnPlansSignature = JSON.stringify(turnPrepData?.turnPlans ?? []);
    } catch (error2) {
      console.error("[TurnPlansPanel] Failed to load turn plans:", error2), set(plans, [], !0), lastSavedTurnPlansSignature = null, ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.TurnPlans.SaveError"));
    } finally {
      syncNotesSectionState(get$1(plans)), syncPlanCardCollapseState(get$1(plans)), applyPendingScrollPosition(), set(loading, !1), set(initialized, !0);
    }
  }
  __name(loadPlans, "loadPlans");
  function hydratePlans(rawPlans) {
    return rawPlans.map((plan) => sanitizePlan(plan));
  }
  __name(hydratePlans, "hydratePlans");
  function sanitizePlan(rawPlan) {
    const actions = mergeSelectedFeatureArrays(rawPlan.actions, rawPlan.action), bonusActions = mergeSelectedFeatureArrays(rawPlan.bonusActions, rawPlan.bonusAction), reactions = mergeSelectedFeatureArrays(rawPlan.reactions), additional = cloneSelectedFeatureArray(rawPlan.additionalFeatures ?? []);
    return {
      id: rawPlan.id ?? randomId(),
      name: rawPlan.name ?? FoundryAdapter.localize("TURN_PREP.TurnPlans.PlanLabel"),
      trigger: rawPlan.trigger ?? "",
      actions,
      bonusActions,
      reactions,
      movement: rawPlan.movement ?? "",
      roleplay: rawPlan.roleplay ?? "",
      additionalFeatures: additional,
      categories: Array.isArray(rawPlan.categories) ? [...rawPlan.categories] : []
    };
  }
  __name(sanitizePlan, "sanitizePlan");
  function findPlan(planId) {
    const index2 = planId ? get$1(plans).findIndex((p) => p.id === planId) : -1;
    return { index: index2, plan: index2 >= 0 ? get$1(plans)[index2] : null };
  }
  __name(findPlan, "findPlan");
  function cloneFeature(feature) {
    return feature ? {
      itemId: feature.itemId,
      itemName: feature.itemName,
      itemType: feature.itemType,
      actionType: feature.actionType
    } : null;
  }
  __name(cloneFeature, "cloneFeature");
  function coerceTurnTable(table) {
    return table === "actions" || table === "bonusActions" || table === "additionalFeatures" ? table : "additionalFeatures";
  }
  __name(coerceTurnTable, "coerceTurnTable");
  function getPlanTable(plan, table) {
    switch (table) {
      case "actions":
        return plan.actions ?? [];
      case "bonusActions":
        return plan.bonusActions ?? [];
      case "reactions":
        return plan.reactions ?? [];
      default:
        return plan.additionalFeatures ?? [];
    }
  }
  __name(getPlanTable, "getPlanTable");
  function findFeatureTable(plan, featureId) {
    return (plan.actions ?? []).some((f) => f.itemId === featureId) ? "actions" : (plan.bonusActions ?? []).some((f) => f.itemId === featureId) ? "bonusActions" : (plan.reactions ?? []).some((f) => f.itemId === featureId) ? "reactions" : (plan.additionalFeatures ?? []).some((f) => f.itemId === featureId) ? "additionalFeatures" : null;
  }
  __name(findFeatureTable, "findFeatureTable");
  function setPlanTable(plan, table, value) {
    switch (table) {
      case "actions":
        return { ...plan, actions: value };
      case "bonusActions":
        return { ...plan, bonusActions: value };
      case "reactions":
        return { ...plan, reactions: value };
      default:
        return { ...plan, additionalFeatures: value };
    }
  }
  __name(setPlanTable, "setPlanTable");
  function getActivationsFromFeature(feature) {
    return feature?.actionType ? [normalizeActionType(feature.actionType)] : [];
  }
  __name(getActivationsFromFeature, "getActivationsFromFeature");
  function getActivationsFromItem(item) {
    if (!item) return [];
    const activations = [], itemActivation = normalizeActionType(item?.system?.activation?.type);
    itemActivation && activations.push(itemActivation);
    const activities = FeatureSelector.getActivitiesForItem(item) ?? [];
    for (const act of activities) {
      const type = normalizeActionType(act?.activation?.type ?? act?.system?.activation?.type);
      type && activations.push(type);
    }
    return activations;
  }
  __name(getActivationsFromItem, "getActivationsFromItem");
  function getActivationsForFeature(feature) {
    if (feature?.itemId) {
      const item = $$props.actor?.items?.get?.(feature.itemId), fromItem = getActivationsFromItem(item);
      if (fromItem.length) return fromItem;
    }
    return getActivationsFromFeature(feature);
  }
  __name(getActivationsForFeature, "getActivationsForFeature");
  async function buildFeatureFromUuid(uuid) {
    try {
      const doc = await globalThis.fromUuid?.(uuid);
      if (!doc)
        return ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.ItemUnavailable")), { feature: null, activations: [] };
      if (doc?.actor?.id && $$props.actor?.id && doc.actor.id !== $$props.actor.id)
        return ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.ActorMismatch")), { feature: null, activations: [] };
      const actionType = normalizeActionType(doc?.system?.activation?.type), feature = {
        itemId: doc.id,
        itemName: doc.name ?? doc.id,
        itemType: doc.type ?? "item",
        actionType
      }, activations = getActivationsFromItem(doc);
      return {
        feature,
        activations: activations.length ? activations : getActivationsFromFeature(feature)
      };
    } catch (error2) {
      return console.error("[TurnPlansPanel] Failed to resolve UUID drop", uuid, error2), ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.ItemUnavailable")), { feature: null, activations: [] };
    }
  }
  __name(buildFeatureFromUuid, "buildFeatureFromUuid");
  function pickTurnTableForDrop(requested, activations) {
    const desired = coerceTurnTable(requested);
    if (desired === "additionalFeatures" || activations.some((act) => isActivationCompatibleWithTable(act, desired)))
      return desired;
    const routed = coerceTurnTable(resolveTurnPlanTableForActivations(activations));
    return routed === "reactions" ? "additionalFeatures" : routed;
  }
  __name(pickTurnTableForDrop, "pickTurnTableForDrop");
  function removeFeatureFromSource(source2) {
    if (!source2?.feature?.itemId) return;
    const { plan, index: index2 } = findPlan(source2.sourcePlanId ?? null);
    if (!plan || index2 === -1) return;
    const table = coerceTurnTable(source2.sourceTable ?? "additionalFeatures"), next = getPlanTable(plan, table).filter((f) => f.itemId !== source2.feature?.itemId), nextPlans = [...get$1(plans)];
    nextPlans[index2] = setPlanTable(plan, table, next), set(plans, nextPlans, !0);
  }
  __name(removeFeatureFromSource, "removeFeatureFromSource");
  function upsertFeatureToPlan(planId, table, feature, targetIndex) {
    const { plan, index: index2 } = findPlan(planId);
    if (!plan || index2 === -1) return;
    const current = getPlanTable(plan, table);
    if (hasDuplicateFeature(current, feature)) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.DuplicateFeature"));
      return;
    }
    const insertAt = Math.max(0, Math.min(current.length, targetIndex ?? current.length)), next = [...current];
    next.splice(insertAt, 0, feature);
    const nextPlans = [...get$1(plans)];
    nextPlans[index2] = setPlanTable(plan, table, next), set(plans, nextPlans, !0), scheduleAutoSave();
  }
  __name(upsertFeatureToPlan, "upsertFeatureToPlan");
  function reorderPlanTable(planId, table, fromIndex, toIndex) {
    const { plan, index: index2 } = findPlan(planId);
    if (!plan || index2 === -1) return;
    const current = getPlanTable(plan, table);
    if (!current.length) return;
    const next = moveArrayItem(current, fromIndex, toIndex), nextPlans = [...get$1(plans)];
    nextPlans[index2] = setPlanTable(plan, table, next), set(plans, nextPlans, !0), scheduleAutoSave();
  }
  __name(reorderPlanTable, "reorderPlanTable");
  async function handleFeatureDrop(event2) {
    if (event2.panelKind !== "turn") return;
    const targetPlanId = event2.ownerId;
    if (!targetPlanId) return;
    let feature = event2.feature ?? null, activations = feature ? getActivationsForFeature(feature) : [];
    if (!feature && event2.nativeItemUuid) {
      const resolved = await buildFeatureFromUuid(event2.nativeItemUuid);
      feature = resolved.feature, activations = resolved.activations;
    }
    if (!feature) return;
    activations.length || (activations = getActivationsForFeature(feature));
    const targetTable = pickTurnTableForDrop(event2.table, activations);
    !event2.copy && event2.source?.sourcePlanId && removeFeatureFromSource(event2.source), upsertFeatureToPlan(targetPlanId, targetTable, cloneFeature(feature), event2.targetIndex);
  }
  __name(handleFeatureDrop, "handleFeatureDrop");
  function handleFeatureReorder(planId, table, fromIndex, toIndex) {
    reorderPlanTable(planId, table, fromIndex, toIndex);
  }
  __name(handleFeatureReorder, "handleFeatureReorder");
  function buildTurnMoveCopyMenu(currentPlanId, feature, copy) {
    const turnActions = [], reactionActions = [], activations = getActivationsForFeature(feature), activationSet = new Set(activations.map((a) => normalizeActionType(a))), allowAction = activationSet.has("action"), allowBonus = activationSet.has("bonus"), allowReaction = activationSet.has("reaction");
    for (const plan of get$1(plans)) {
      const planActions = [];
      allowAction && planActions.push({
        id: `${plan.id}-action-${copy ? "copy" : "move"}`,
        label: `${plan.name} - ${FoundryAdapter.localize("TURN_PREP.TurnPlans.Actions")}`,
        icon: "fa-solid fa-person-running",
        onSelect: /* @__PURE__ */ __name(() => handleMoveCopyFeature(currentPlanId, plan.id, "actions", feature, copy), "onSelect")
      }), allowBonus && planActions.push({
        id: `${plan.id}-bonus-${copy ? "copy" : "move"}`,
        label: `${plan.name} - ${FoundryAdapter.localize("TURN_PREP.TurnPlans.BonusActions")}`,
        icon: "fa-solid fa-plus",
        onSelect: /* @__PURE__ */ __name(() => handleMoveCopyFeature(currentPlanId, plan.id, "bonusActions", feature, copy), "onSelect")
      }), planActions.push({
        id: `${plan.id}-additional-${copy ? "copy" : "move"}`,
        label: `${plan.name} - ${FoundryAdapter.localize("TURN_PREP.TurnPlans.AdditionalFeatures")}`,
        icon: "fa-regular fa-circle-dot",
        onSelect: /* @__PURE__ */ __name(() => handleMoveCopyFeature(currentPlanId, plan.id, "additionalFeatures", feature, copy), "onSelect")
      }), planActions.length && turnActions.push(...planActions);
    }
    try {
      const reactions = TurnPrepApiInstance.getTurnPrepData($$props.actor)?.reactions ?? [];
      for (const reaction of reactions) {
        const reactionMenuActions = [];
        allowReaction && reactionMenuActions.push({
          id: `${reaction.id}-reaction-${copy ? "copy" : "move"}`,
          label: `${reaction.name || FoundryAdapter.localize("TURN_PREP.Reactions.ReactionLabel")} - ${FoundryAdapter.localize("TURN_PREP.Reactions.ReactionFeatures")}`,
          icon: "fa-solid fa-bolt",
          onSelect: /* @__PURE__ */ __name(() => handleMoveCopyFeatureToReaction(currentPlanId, reaction.id, "reactionFeatures", feature, copy), "onSelect")
        }), reactionMenuActions.push({
          id: `${reaction.id}-additional-${copy ? "copy" : "move"}`,
          label: `${reaction.name || FoundryAdapter.localize("TURN_PREP.Reactions.ReactionLabel")} - ${FoundryAdapter.localize("TURN_PREP.Reactions.AdditionalFeatures")}`,
          icon: "fa-regular fa-circle-dot",
          onSelect: /* @__PURE__ */ __name(() => handleMoveCopyFeatureToReaction(currentPlanId, reaction.id, "additionalFeatures", feature, copy), "onSelect")
        }), reactionMenuActions.length && reactionActions.push(...reactionMenuActions);
      }
    } catch (error2) {
      console.warn("[TurnPlansPanel] Failed to build reaction move/copy menu", error2);
    }
    const sections = [];
    return turnActions.length && sections.push({
      id: `turns-${copy ? "copy" : "move"}`,
      label: FoundryAdapter.localize("TURN_PREP.TurnPlans.Title") ?? "Turns",
      actions: turnActions
    }), reactionActions.length && sections.push({
      id: `reactions-${copy ? "copy" : "move"}`,
      label: FoundryAdapter.localize("TURN_PREP.Reactions.Title") ?? "Reactions",
      actions: reactionActions
    }), sections;
  }
  __name(buildTurnMoveCopyMenu, "buildTurnMoveCopyMenu");
  function handleMoveCopyFeature(fromPlanId, toPlanId, table, feature, copy) {
    const { plan: targetPlan } = findPlan(toPlanId);
    if (!targetPlan) return;
    if (hasDuplicateFeature(getPlanTable(targetPlan, table), feature)) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.DuplicateFeature"));
      return;
    }
    if (!copy) {
      const { plan: sourcePlan, index: sourceIndex } = findPlan(fromPlanId);
      if (sourcePlan && sourceIndex >= 0) {
        const sourceTable = findFeatureTable(sourcePlan, feature.itemId) ?? table, cleaned = getPlanTable(sourcePlan, sourceTable).filter((f) => f.itemId !== feature.itemId), nextPlans2 = [...get$1(plans)];
        nextPlans2[sourceIndex] = setPlanTable(sourcePlan, sourceTable, cleaned), set(plans, nextPlans2, !0);
      }
    }
    const { plan: updatedTarget, index: targetIndex } = findPlan(toPlanId);
    if (!updatedTarget || targetIndex < 0) return;
    const next = [...getPlanTable(updatedTarget, table), cloneFeature(feature)], nextPlans = [...get$1(plans)];
    nextPlans[targetIndex] = setPlanTable(updatedTarget, table, next), set(plans, nextPlans, !0), scheduleAutoSave();
  }
  __name(handleMoveCopyFeature, "handleMoveCopyFeature");
  async function handleMoveCopyFeatureToReaction(fromPlanId, reactionId, table, feature, copy) {
    const turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor) ?? createEmptyTurnPrepData(), reactions = Array.isArray(turnPrepData.reactions) ? [...turnPrepData.reactions] : [], reactionIndex = reactions.findIndex((r2) => r2.id === reactionId);
    if (reactionIndex === -1) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.Reactions.Messages.ReactionMissing") ?? "Reaction not found");
      return;
    }
    const targetReaction = reactions[reactionIndex], currentTargets = table === "reactionFeatures" ? Array.isArray(targetReaction.reactionFeatures) ? targetReaction.reactionFeatures : [] : Array.isArray(targetReaction.additionalFeatures) ? targetReaction.additionalFeatures : [];
    if (hasDuplicateFeature(currentTargets, feature)) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.DuplicateFeature"));
      return;
    }
    let nextPlans = get$1(plans);
    if (!copy) {
      const { plan: sourcePlan, index: sourceIndex } = findPlan(fromPlanId);
      if (sourcePlan && sourceIndex >= 0) {
        const sourceTable = findFeatureTable(sourcePlan, feature.itemId) ?? "additionalFeatures", cleaned = getPlanTable(sourcePlan, sourceTable).filter((f) => f.itemId !== feature.itemId);
        nextPlans = [...get$1(plans)], nextPlans[sourceIndex] = setPlanTable(sourcePlan, sourceTable, cleaned), set(plans, nextPlans, !0);
      }
    }
    const updatedTargets = [...currentTargets, cloneFeature(feature)], updatedReaction = table === "reactionFeatures" ? { ...targetReaction, reactionFeatures: updatedTargets } : { ...targetReaction, additionalFeatures: updatedTargets };
    reactions[reactionIndex] = updatedReaction;
    const nextData = {
      ...turnPrepData,
      turnPlans: (nextPlans ?? get$1(plans)).map((plan) => sanitizePlan(plan)),
      reactions
    };
    try {
      await TurnPrepApiInstance.saveTurnPrepData($$props.actor, nextData, { render: !1 }), lastSavedTurnPlansSignature = JSON.stringify(nextData.turnPlans ?? []);
    } catch (error2) {
      console.error("[TurnPlansPanel] Failed to move/copy feature to reaction", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.Reactions.SaveError"));
    }
  }
  __name(handleMoveCopyFeatureToReaction, "handleMoveCopyFeatureToReaction");
  function cancelPendingSave(flush = !1) {
    const pending = !!saveTimeout;
    saveTimeout && (window.clearTimeout(saveTimeout), saveTimeout = null), flush && pending && savePlans();
  }
  __name(cancelPendingSave, "cancelPendingSave");
  function scheduleAutoSave() {
    get$1(initialized) && (saveTimeout && window.clearTimeout(saveTimeout), saveTimeout = window.setTimeout(
      () => {
        saveTimeout = null, savePlans();
      },
      AUTO_SAVE_DEBOUNCE_MS
    ));
  }
  __name(scheduleAutoSave, "scheduleAutoSave");
  function createNewPlan() {
    const newPlan = {
      id: randomId(),
      name: `${FoundryAdapter.localize("TURN_PREP.TurnPlans.PlanLabel")} ${get$1(plans).length + 1}`,
      trigger: "",
      actions: [],
      bonusActions: [],
      reactions: [],
      movement: "",
      roleplay: "",
      additionalFeatures: [],
      categories: []
    };
    set(plans, [...get$1(plans), newPlan], !0), syncNotesSectionState(get$1(plans)), syncPlanCardCollapseState(get$1(plans)), savePlans();
  }
  __name(createNewPlan, "createNewPlan");
  function getActionFeatures(plan) {
    const features = Array.isArray(plan.actions) ? plan.actions : [];
    return buildDisplayFeatureList($$props.actor, plan.id, features, "action-primary");
  }
  __name(getActionFeatures, "getActionFeatures");
  function getBonusActionFeatures(plan) {
    const features = Array.isArray(plan.bonusActions) ? plan.bonusActions : [];
    return buildDisplayFeatureList($$props.actor, plan.id, features, "bonus-primary");
  }
  __name(getBonusActionFeatures, "getBonusActionFeatures");
  function getAdditionalFeatures(plan) {
    const extras = plan.additionalFeatures ?? [];
    return buildDisplayFeatureList($$props.actor, plan.id, extras, "additional");
  }
  __name(getAdditionalFeatures, "getAdditionalFeatures");
  function handleRemoveFeature(planId, target, featureId) {
    const index2 = get$1(plans).findIndex((plan2) => plan2.id === planId);
    if (index2 === -1) return;
    const updated = [...get$1(plans)], plan = {
      ...updated[index2],
      actions: [...updated[index2].actions ?? []],
      bonusActions: [...updated[index2].bonusActions ?? []],
      reactions: [...updated[index2].reactions ?? []],
      additionalFeatures: [...updated[index2].additionalFeatures ?? []]
    };
    target === "action" ? plan.actions = plan.actions.filter((feature) => feature.itemId !== featureId) : target === "bonusAction" ? plan.bonusActions = plan.bonusActions.filter((feature) => feature.itemId !== featureId) : plan.additionalFeatures = plan.additionalFeatures.filter((feature) => feature.itemId !== featureId), updated[index2] = plan, set(plans, updated, !0), savePlans();
  }
  __name(handleRemoveFeature, "handleRemoveFeature");
  async function saveFavorite() {
    if (!(!get$1(isEditing) || !get$1(plans)[0] || !get$1(editSession)))
      try {
        const updatedPlan = get$1(plans)[0], updatedSnapshot = createTurnSnapshot(updatedPlan);
        updatedSnapshot.id = get$1(editSession).originalId;
        const data = await TurnPrepStorage.load($$props.actor), favorites = data.favoritesTurn ?? data.favorites ?? [], index2 = favorites.findIndex((f) => f.id === get$1(editSession).originalId);
        index2 >= 0 ? favorites[index2] = updatedSnapshot : favorites.push(updatedSnapshot), data.favoritesTurn = favorites, await TurnPrepStorage.save($$props.actor, data), ui.notifications?.info(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.FavoriteSaved")), editSessionStore.clearSession();
      } catch (error2) {
        console.error("[TurnPlansPanel] Failed to save favorite:", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.TurnPlans.SaveError"));
      }
  }
  __name(saveFavorite, "saveFavorite");
  function cancelEdit() {
    editSessionStore.clearSession();
  }
  __name(cancelEdit, "cancelEdit");
  async function deletePlan(id) {
    await window.foundry.applications.api.DialogV2.confirm({
      window: {
        title: FoundryAdapter.localize("TURN_PREP.TurnPlans.DeleteConfirm")
      },
      content: `<p>${FoundryAdapter.localize("TURN_PREP.TurnPlans.DeleteConfirmMessage")}</p>`
    }) && (set(plans, get$1(plans).filter((p) => p.id !== id), !0), syncNotesSectionState(get$1(plans)), syncPlanCardCollapseState(get$1(plans)), savePlans());
  }
  __name(deletePlan, "deletePlan");
  async function savePlans() {
    if (!(!$$props.actor || get$1(isEditing)))
      try {
        const turnPrepData = TurnPrepApiInstance.getTurnPrepData($$props.actor) ?? createEmptyTurnPrepData();
        turnPrepData.turnPlans = get$1(plans).map((plan) => sanitizePlan(plan)), lastSavedTurnPlansSignature = JSON.stringify(turnPrepData.turnPlans ?? []), await TurnPrepApiInstance.saveTurnPrepData($$props.actor, turnPrepData, { render: !1 });
      } catch (error2) {
        console.error("[TurnPlansPanel] Failed to save plans:", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.TurnPlans.SaveError"));
      }
  }
  __name(savePlans, "savePlans");
  function syncNotesSectionState(nextPlans) {
    const nextState = { ...get$1(notesSectionState) };
    let changed = !1;
    const planIds = new Set(nextPlans.map((plan) => plan.id));
    nextPlans.forEach((plan) => {
      nextState[plan.id] === void 0 && (nextState[plan.id] = !1, changed = !0);
    }), Object.keys(nextState).forEach((planId) => {
      planIds.has(planId) || (delete nextState[planId], changed = !0);
    }), changed && set(notesSectionState, nextState, !0);
  }
  __name(syncNotesSectionState, "syncNotesSectionState");
  function ensureNotesSectionState(planId) {
    get$1(notesSectionState)[planId] === void 0 && set(notesSectionState, { ...get$1(notesSectionState), [planId]: !1 }, !0);
  }
  __name(ensureNotesSectionState, "ensureNotesSectionState");
  function isNotesSectionOpen(planId) {
    return get$1(notesSectionState)[planId] === void 0 && ensureNotesSectionState(planId), !!get$1(notesSectionState)[planId];
  }
  __name(isNotesSectionOpen, "isNotesSectionOpen");
  function toggleNotesSection(planId) {
    const nextValue = !isNotesSectionOpen(planId);
    set(notesSectionState, { ...get$1(notesSectionState), [planId]: nextValue }, !0);
  }
  __name(toggleNotesSection, "toggleNotesSection");
  function syncPlanCardCollapseState(nextPlans) {
    const nextState = { ...get$1(planCardCollapseState) };
    let changed = !1;
    const planIds = new Set(nextPlans.map((plan) => plan.id));
    nextPlans.forEach((plan) => {
      nextState[plan.id] === void 0 && (nextState[plan.id] = !1, changed = !0);
    }), Object.keys(nextState).forEach((planId) => {
      planIds.has(planId) || (delete nextState[planId], changed = !0);
    }), changed && set(planCardCollapseState, nextState, !0);
  }
  __name(syncPlanCardCollapseState, "syncPlanCardCollapseState");
  function isPlanCollapsed(planId) {
    return !!get$1(planCardCollapseState)[planId];
  }
  __name(isPlanCollapsed, "isPlanCollapsed");
  function togglePlanCollapsed(planId) {
    set(
      planCardCollapseState,
      {
        ...get$1(planCardCollapseState),
        [planId]: !isPlanCollapsed(planId)
      },
      !0
    );
  }
  __name(togglePlanCollapsed, "togglePlanCollapsed");
  async function handleSubmitPlan(planId) {
    const plan = get$1(plans).find((p) => p.id === planId);
    if (!plan) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.PlanMissing"));
      return;
    }
    try {
      const snapshot = createTurnSnapshot(plan), data = await TurnPrepStorage.load($$props.actor);
      data.turnPlans = get$1(plans).map((p) => sanitizePlan(p));
      const limit = getHistoryLimitForActor($$props.actor);
      data.history = limitHistory([...data.history ?? [], snapshot], limit), await TurnPrepStorage.save($$props.actor, data);
    } catch (error2) {
      console.error("[TurnPlansPanel] Failed to submit plan", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.TurnPlans.SaveError"));
    }
  }
  __name(handleSubmitPlan, "handleSubmitPlan");
  async function handleFavoritePlan(planId) {
    const plan = get$1(plans).find((p) => p.id === planId);
    if (!plan) {
      ui.notifications?.warn(FoundryAdapter.localize("TURN_PREP.TurnPlans.Messages.PlanMissing"));
      return;
    }
    try {
      const snapshot = createTurnSnapshot(plan), data = await TurnPrepStorage.load($$props.actor);
      data.turnPlans = get$1(plans).map((p) => sanitizePlan(p)), data.favoritesTurn = [...data.favoritesTurn ?? data.favorites ?? [], snapshot], await TurnPrepStorage.save($$props.actor, data);
    } catch (error2) {
      console.error("[TurnPlansPanel] Failed to favorite plan", error2), ui.notifications?.error(FoundryAdapter.localize("TURN_PREP.TurnPlans.SaveError"));
    }
  }
  __name(handleFavoritePlan, "handleFavoritePlan");
  function reorderPlans(fromIndex, toIndex) {
    const boundedFrom = Math.max(0, Math.min(get$1(plans).length - 1, fromIndex)), boundedTo = Math.max(0, Math.min(get$1(plans).length - 1, toIndex));
    boundedFrom !== boundedTo && (set(plans, moveArrayItem(get$1(plans), boundedFrom, boundedTo), !0), scheduleAutoSave());
  }
  __name(reorderPlans, "reorderPlans");
  function buildPlanReorderActions(planId) {
    const index2 = get$1(plans).findIndex((p) => p.id === planId);
    if (index2 === -1) return [];
    const total = get$1(plans).length;
    return [
      {
        id: "move-up",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveUp") || "Move Up",
        icon: "fa-solid fa-angle-up",
        onSelect: /* @__PURE__ */ __name(() => reorderPlans(index2, Math.max(0, index2 - 1)), "onSelect")
      },
      {
        id: "move-down",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveDown") || "Move Down",
        icon: "fa-solid fa-angle-down",
        onSelect: /* @__PURE__ */ __name(() => reorderPlans(index2, Math.min(total - 1, index2 + 1)), "onSelect")
      },
      {
        id: "move-top",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveTop") || "Move to Top",
        icon: "fa-solid fa-angles-up",
        onSelect: /* @__PURE__ */ __name(() => reorderPlans(index2, 0), "onSelect")
      },
      {
        id: "move-bottom",
        label: FoundryAdapter.localize("TURN_PREP.ContextMenu.MoveBottom") || "Move to Bottom",
        icon: "fa-solid fa-angles-down",
        onSelect: /* @__PURE__ */ __name(() => reorderPlans(index2, total - 1), "onSelect")
      }
    ];
  }
  __name(buildPlanReorderActions, "buildPlanReorderActions");
  function buildPlanArrangeSubmenu(planId) {
    const actions = buildPlanReorderActions(planId);
    return actions.length ? [{ id: `${planId}-reorder`, actions }] : [];
  }
  __name(buildPlanArrangeSubmenu, "buildPlanArrangeSubmenu");
  function getPlanContextMenuActions(plan) {
    const arrangeSubmenu = buildPlanArrangeSubmenu(plan.id);
    return [
      {
        id: "duplicate",
        label: FoundryAdapter.localize("TURN_PREP.TurnPlans.ContextMenu.Duplicate"),
        icon: "fa-regular fa-copy",
        onSelect: /* @__PURE__ */ __name(() => duplicatePlan(plan.id), "onSelect")
      },
      {
        id: "delete",
        label: FoundryAdapter.localize("TURN_PREP.TurnPlans.ContextMenu.Delete"),
        icon: "fa-regular fa-trash-can",
        variant: "destructive",
        onSelect: /* @__PURE__ */ __name(() => {
          deletePlan(plan.id);
        }, "onSelect")
      },
      {
        id: "submit",
        label: FoundryAdapter.localize("TURN_PREP.TurnPlans.ContextMenu.Submit"),
        icon: "fa-regular fa-paper-plane",
        onSelect: /* @__PURE__ */ __name(() => handleSubmitPlan(plan.id), "onSelect")
      },
      {
        id: "favorite",
        label: FoundryAdapter.localize("TURN_PREP.TurnPlans.ContextMenu.AddToFavorites"),
        icon: "fa-regular fa-star",
        onSelect: /* @__PURE__ */ __name(() => handleFavoritePlan(plan.id), "onSelect")
      },
      ...arrangeSubmenu.length ? [
        {
          id: "arrange",
          label: FoundryAdapter.localize("TURN_PREP.ContextMenu.Arrange") || "Arrange",
          icon: "fa-solid fa-arrow-up-wide-short",
          submenu: arrangeSubmenu,
          onSelect: /* @__PURE__ */ __name(() => {
          }, "onSelect")
        }
      ] : []
    ];
  }
  __name(getPlanContextMenuActions, "getPlanContextMenuActions");
  function buildPlanContextMenuSections(plan) {
    return [
      {
        id: `plan-menu-${plan.id}`,
        actions: getPlanContextMenuActions(plan)
      }
    ];
  }
  __name(buildPlanContextMenuSections, "buildPlanContextMenuSections");
  function openPlanContextMenu(plan, position, anchor) {
    planContextMenuController.open({
      sections: buildPlanContextMenuSections(plan),
      position,
      anchorElement: anchor ?? null,
      context: {
        planId: plan.id,
        ariaLabel: `${plan.name} ${FoundryAdapter.localize("TURN_PREP.TurnPlans.ContextMenuLabel")}`
      }
    });
  }
  __name(openPlanContextMenu, "openPlanContextMenu");
  function handlePlanContextMenu(plan, event2) {
    event2.preventDefault(), event2.stopPropagation(), openPlanContextMenu(plan, { x: event2.clientX, y: event2.clientY }, event2.currentTarget);
  }
  __name(handlePlanContextMenu, "handlePlanContextMenu");
  function handlePlanMenuButton(plan, event2) {
    event2.preventDefault(), event2.stopPropagation();
    const button = event2.currentTarget;
    if (button) {
      const rect = button.getBoundingClientRect();
      openPlanContextMenu(plan, { x: rect.right, y: rect.bottom + 4 }, button);
      return;
    }
    openPlanContextMenu(plan, { x: event2.clientX, y: event2.clientY });
  }
  __name(handlePlanMenuButton, "handlePlanMenuButton");
  var fragment = root$2(), node = first_child(fragment);
  {
    var consequent = /* @__PURE__ */ __name(($$anchor2) => {
      var div = root_1$2(), p_1 = child(div), text = child(p_1);
      template_effect(($0) => set_text(text, $0), [() => FoundryAdapter.localize("TURN_PREP.Common.Loading")]), append($$anchor2, div);
    }, "consequent"), alternate_2 = /* @__PURE__ */ __name(($$anchor2) => {
      var div_1 = root_2$2(), div_2 = child(div_1), node_1 = child(div_2);
      {
        var consequent_1 = /* @__PURE__ */ __name(($$anchor3) => {
          var button_1 = root_3$2();
          button_1.__click = () => set(collapsed, !get$1(collapsed));
          var i = child(button_1);
          template_effect(() => {
            set_attribute(button_1, "title", get$1(collapsed) ? "Expand" : "Collapse"), set_class(i, 1, `fas fa-chevron-${get$1(collapsed) ? "right" : "down"}`);
          }), append($$anchor3, button_1);
        }, "consequent_1");
        if_block(node_1, ($$render) => {
          get$1(isEditing) || $$render(consequent_1);
        });
      }
      var h3 = sibling(node_1, 2), text_1 = child(h3), node_2 = sibling(h3, 2);
      {
        var consequent_2 = /* @__PURE__ */ __name(($$anchor3) => {
          var div_3 = root_4$1(), button_2 = child(div_3);
          button_2.__click = saveFavorite;
          var text_2 = sibling(child(button_2)), button_3 = sibling(button_2, 2);
          button_3.__click = cancelEdit;
          var text_3 = sibling(child(button_3));
          template_effect(
            ($0, $1) => {
              set_text(text_2, ` ${$0 ?? ""}`), set_text(text_3, ` ${$1 ?? ""}`);
            },
            [
              () => FoundryAdapter.localize("TURN_PREP.Common.Save") || "Save",
              () => FoundryAdapter.localize("TURN_PREP.Common.Cancel") || "Cancel"
            ]
          ), append($$anchor3, div_3);
        }, "consequent_2"), alternate = /* @__PURE__ */ __name(($$anchor3) => {
          var button_4 = root_5();
          button_4.__click = createNewPlan;
          var text_4 = sibling(child(button_4));
          template_effect(($0) => set_text(text_4, ` ${$0 ?? ""}`), [() => FoundryAdapter.localize("TURN_PREP.TurnPlans.NewPlan")]), append($$anchor3, button_4);
        }, "alternate");
        if_block(node_2, ($$render) => {
          get$1(isEditing) ? $$render(consequent_2) : $$render(alternate, !1);
        });
      }
      var node_3 = sibling(div_2, 2);
      {
        var consequent_8 = /* @__PURE__ */ __name(($$anchor3) => {
          var fragment_1 = comment(), node_4 = first_child(fragment_1);
          {
            var consequent_3 = /* @__PURE__ */ __name(($$anchor4) => {
              var div_4 = root_7$1(), p_2 = child(div_4), text_5 = child(p_2);
              template_effect(($0) => set_text(text_5, $0), [() => FoundryAdapter.localize("TURN_PREP.TurnPlans.NoPlans")]), append($$anchor4, div_4);
            }, "consequent_3"), alternate_1 = /* @__PURE__ */ __name(($$anchor4) => {
              var div_5 = root_8$1();
              each(div_5, 21, () => get$1(plans), (plan) => plan.id, ($$anchor5, plan, $$index) => {
                var div_6 = root_9$1();
                div_6.__contextmenu = (event2) => handlePlanContextMenu(get$1(plan), event2);
                var div_7 = child(div_6), node_5 = child(div_7);
                {
                  var consequent_4 = /* @__PURE__ */ __name(($$anchor6) => {
                    var button_5 = root_10$1();
                    button_5.__click = () => togglePlanCollapsed(get$1(plan).id);
                    var i_1 = child(button_5);
                    template_effect(
                      ($0, $1) => {
                        set_attribute(button_5, "aria-label", $0), set_class(i_1, 1, $1, "svelte-tp-jbd3d");
                      },
                      [
                        () => FoundryAdapter.localize("TURN_PREP.TurnPlans.TogglePlanBody"),
                        () => `fas fa-chevron-${isPlanCollapsed(get$1(plan).id) ? "right" : "down"}`
                      ]
                    ), append($$anchor6, button_5);
                  }, "consequent_4");
                  if_block(node_5, ($$render) => {
                    get$1(isEditing) || $$render(consequent_4);
                  });
                }
                var input = sibling(node_5, 2);
                input.__change = scheduleAutoSave;
                var node_6 = sibling(input, 2);
                {
                  var consequent_5 = /* @__PURE__ */ __name(($$anchor6) => {
                    var button_6 = root_11$1();
                    button_6.__click = (event2) => handlePlanMenuButton(get$1(plan), event2), template_effect(($0) => set_attribute(button_6, "aria-label", $0), [
                      () => FoundryAdapter.localize("TURN_PREP.ContextMenu.OpenLabel")
                    ]), append($$anchor6, button_6);
                  }, "consequent_5");
                  if_block(node_6, ($$render) => {
                    get$1(isEditing) || $$render(consequent_5);
                  });
                }
                var node_7 = sibling(div_7, 2);
                {
                  var consequent_7 = /* @__PURE__ */ __name(($$anchor6) => {
                    var div_8 = root_12$1(), div_9 = child(div_8), node_8 = child(div_9);
                    {
                      let $0 = /* @__PURE__ */ user_derived(() => `action-${get$1(plan).id}`), $1 = /* @__PURE__ */ user_derived(() => FoundryAdapter.localize("TURN_PREP.TurnPlans.Actions")), $2 = /* @__PURE__ */ user_derived(() => getActionFeatures(get$1(plan)));
                      TurnPlanFeatureTable(node_8, {
                        get tableKey() {
                          return get$1($0);
                        },
                        get title() {
                          return get$1($1);
                        },
                        get actor() {
                          return $$props.actor;
                        },
                        get features() {
                          return get$1($2);
                        },
                        get ownerId() {
                          return get$1(plan).id;
                        },
                        panelKind: "turn",
                        tableType: "actions",
                        onFeatureDrop: /* @__PURE__ */ __name((payload) => {
                          handleFeatureDrop(payload);
                        }, "onFeatureDrop"),
                        onReorderFeature: /* @__PURE__ */ __name((from, to) => handleFeatureReorder(get$1(plan).id, "actions", from, to), "onReorderFeature"),
                        buildMoveToMenu: /* @__PURE__ */ __name((feature) => buildTurnMoveCopyMenu(get$1(plan).id, feature, !1), "buildMoveToMenu"),
                        buildCopyToMenu: /* @__PURE__ */ __name((feature) => buildTurnMoveCopyMenu(get$1(plan).id, feature, !0), "buildCopyToMenu"),
                        onRemoveFeature: /* @__PURE__ */ __name((featureId) => handleRemoveFeature(get$1(plan).id, "action", featureId), "onRemoveFeature")
                      });
                    }
                    var node_9 = sibling(node_8, 2);
                    {
                      let $0 = /* @__PURE__ */ user_derived(() => `bonus-${get$1(plan).id}`), $1 = /* @__PURE__ */ user_derived(() => FoundryAdapter.localize("TURN_PREP.TurnPlans.BonusActions")), $2 = /* @__PURE__ */ user_derived(() => getBonusActionFeatures(get$1(plan)));
                      TurnPlanFeatureTable(node_9, {
                        get tableKey() {
                          return get$1($0);
                        },
                        get title() {
                          return get$1($1);
                        },
                        get actor() {
                          return $$props.actor;
                        },
                        get features() {
                          return get$1($2);
                        },
                        get ownerId() {
                          return get$1(plan).id;
                        },
                        panelKind: "turn",
                        tableType: "bonusActions",
                        onFeatureDrop: /* @__PURE__ */ __name((payload) => {
                          handleFeatureDrop(payload);
                        }, "onFeatureDrop"),
                        onReorderFeature: /* @__PURE__ */ __name((from, to) => handleFeatureReorder(get$1(plan).id, "bonusActions", from, to), "onReorderFeature"),
                        buildMoveToMenu: /* @__PURE__ */ __name((feature) => buildTurnMoveCopyMenu(get$1(plan).id, feature, !1), "buildMoveToMenu"),
                        buildCopyToMenu: /* @__PURE__ */ __name((feature) => buildTurnMoveCopyMenu(get$1(plan).id, feature, !0), "buildCopyToMenu"),
                        onRemoveFeature: /* @__PURE__ */ __name((featureId) => handleRemoveFeature(get$1(plan).id, "bonusAction", featureId), "onRemoveFeature")
                      });
                    }
                    var node_10 = sibling(node_9, 2);
                    {
                      let $0 = /* @__PURE__ */ user_derived(() => `additional-${get$1(plan).id}`), $1 = /* @__PURE__ */ user_derived(() => FoundryAdapter.localize("TURN_PREP.TurnPlans.AdditionalFeatures")), $2 = /* @__PURE__ */ user_derived(() => getAdditionalFeatures(get$1(plan)));
                      TurnPlanFeatureTable(node_10, {
                        get tableKey() {
                          return get$1($0);
                        },
                        get title() {
                          return get$1($1);
                        },
                        get actor() {
                          return $$props.actor;
                        },
                        get features() {
                          return get$1($2);
                        },
                        get ownerId() {
                          return get$1(plan).id;
                        },
                        panelKind: "turn",
                        tableType: "additionalFeatures",
                        onFeatureDrop: /* @__PURE__ */ __name((payload) => {
                          handleFeatureDrop(payload);
                        }, "onFeatureDrop"),
                        onReorderFeature: /* @__PURE__ */ __name((from, to) => handleFeatureReorder(get$1(plan).id, "additionalFeatures", from, to), "onReorderFeature"),
                        buildMoveToMenu: /* @__PURE__ */ __name((feature) => buildTurnMoveCopyMenu(get$1(plan).id, feature, !1), "buildMoveToMenu"),
                        buildCopyToMenu: /* @__PURE__ */ __name((feature) => buildTurnMoveCopyMenu(get$1(plan).id, feature, !0), "buildCopyToMenu"),
                        onRemoveFeature: /* @__PURE__ */ __name((featureId) => handleRemoveFeature(get$1(plan).id, "additional", featureId), "onRemoveFeature")
                      });
                    }
                    var div_10 = sibling(div_9, 2), div_11 = child(div_10), button_7 = child(div_11);
                    button_7.__click = () => toggleNotesSection(get$1(plan).id);
                    var i_2 = child(button_7), text_6 = sibling(i_2), node_11 = sibling(button_7, 2);
                    {
                      var consequent_6 = /* @__PURE__ */ __name(($$anchor7) => {
                        var div_12 = root_13(), div_13 = child(div_12), label = child(div_13), text_7 = child(label), textarea = sibling(label, 2);
                        textarea.__change = scheduleAutoSave;
                        var label_1 = sibling(textarea, 2), text_8 = child(label_1), textarea_1 = sibling(label_1, 2);
                        textarea_1.__change = scheduleAutoSave;
                        var label_2 = sibling(textarea_1, 2), text_9 = child(label_2), textarea_2 = sibling(label_2, 2);
                        textarea_2.__change = scheduleAutoSave, template_effect(
                          ($0, $1, $2, $3, $4) => {
                            set_attribute(label, "for", "tp-situation-" + get$1(plan).id), set_text(text_7, $0), set_attribute(textarea, "id", "tp-situation-" + get$1(plan).id), set_attribute(textarea, "placeholder", $1), set_attribute(label_1, "for", "tp-movement-" + get$1(plan).id), set_text(text_8, $2), set_attribute(textarea_1, "id", "tp-movement-" + get$1(plan).id), set_attribute(label_2, "for", "tp-notes-" + get$1(plan).id), set_text(text_9, $3), set_attribute(textarea_2, "id", "tp-notes-" + get$1(plan).id), set_attribute(textarea_2, "placeholder", $4);
                          },
                          [
                            () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Situation"),
                            () => FoundryAdapter.localize("TURN_PREP.TurnPlans.TriggerPlaceholder"),
                            () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Movement"),
                            () => FoundryAdapter.localize("TURN_PREP.TurnPlans.Notes"),
                            () => FoundryAdapter.localize("TURN_PREP.TurnPlans.NotesPlaceholder")
                          ]
                        ), bind_value(textarea, () => get$1(plan).trigger, ($$value) => get$1(plan).trigger = $$value), bind_value(textarea_1, () => get$1(plan).movement, ($$value) => get$1(plan).movement = $$value), bind_value(textarea_2, () => get$1(plan).roleplay, ($$value) => get$1(plan).roleplay = $$value), append($$anchor7, div_12);
                      }, "consequent_6");
                      if_block(node_11, ($$render) => {
                        isNotesSectionOpen(get$1(plan).id) && $$render(consequent_6);
                      });
                    }
                    template_effect(
                      ($0, $1) => {
                        set_class(i_2, 1, $0, "svelte-tp-jbd3d"), set_text(text_6, ` ${$1 ?? ""}`);
                      },
                      [
                        () => `fas fa-chevron-${isNotesSectionOpen(get$1(plan).id) ? "down" : "right"}`,
                        () => FoundryAdapter.localize("TURN_PREP.TurnPlans.AdditionalNotes")
                      ]
                    ), append($$anchor6, div_8);
                  }, "consequent_7");
                  if_block(node_7, ($$render) => {
                    isPlanCollapsed(get$1(plan).id) || $$render(consequent_7);
                  });
                }
                template_effect(
                  ($0, $1) => {
                    set_class(div_6, 1, $0, "svelte-tp-jbd3d"), set_attribute(input, "placeholder", $1);
                  },
                  [
                    () => `turn-prep-panel-card turn-plan-card ${isPlanCollapsed(get$1(plan).id) ? "is-collapsed" : ""} ${get$1(activeContextPlanId) === get$1(plan).id ? "is-context-open" : ""}`,
                    () => FoundryAdapter.localize("TURN_PREP.TurnPlans.PlanName")
                  ]
                ), bind_value(input, () => get$1(plan).name, ($$value) => get$1(plan).name = $$value), append($$anchor5, div_6);
              }), append($$anchor4, div_5);
            }, "alternate_1");
            if_block(node_4, ($$render) => {
              get$1(plans).length === 0 ? $$render(consequent_3) : $$render(alternate_1, !1);
            });
          }
          append($$anchor3, fragment_1);
        }, "consequent_8");
        if_block(node_3, ($$render) => {
          get$1(collapsed) || $$render(consequent_8);
        });
      }
      bind_this(div_1, ($$value) => set(panelRootElement, $$value), () => get$1(panelRootElement)), template_effect(($0) => set_text(text_1, $0), [
        () => get$1(isEditing) ? FoundryAdapter.localize("TURN_PREP.TurnPlans.EditTitle") || "Editing Favorite" : FoundryAdapter.localize("TURN_PREP.TurnPlans.Title")
      ]), append($$anchor2, div_1);
    }, "alternate_2");
    if_block(node, ($$render) => {
      get$1(loading) ? $$render(consequent) : $$render(alternate_2, !1);
    });
  }
  var node_12 = sibling(node, 2);
  ContextMenuHost(node_12, {
    get controller() {
      return planContextMenuController;
    }
  }), append($$anchor, fragment), pop();
}
__name(TurnPlansPanel, "TurnPlansPanel");
delegate(["click", "contextmenu", "change"]);
var root_1$1 = /* @__PURE__ */ from_html('<div class="panel-section svelte-tp-eyend4"><!></div>'), root_2$1 = /* @__PURE__ */ from_html('<div class="panel-section svelte-tp-eyend4"><!></div>'), root_3$1 = /* @__PURE__ */ from_html('<div class="panel-section svelte-tp-eyend4"><!></div>'), root$1 = /* @__PURE__ */ from_html('<div class="turn-prep-tab svelte-tp-eyend4"><div class="turn-prep-panels svelte-tp-eyend4"><!> <!> <!></div></div>');
function TidyTurnPrepTab($$anchor, $$props) {
  push($$props, !0);
  let activeEditKind = /* @__PURE__ */ state(null);
  onMount(() => editSessionStore.subscribe((session) => {
    session && session.actorId === $$props.actor.id ? set(activeEditKind, session.kind, !0) : set(activeEditKind, null);
  }));
  var div = root$1(), div_1 = child(div), node = child(div_1);
  {
    var consequent = /* @__PURE__ */ __name(($$anchor2) => {
      var div_2 = root_1$1(), node_1 = child(div_2);
      DmQuestionsPanel(node_1, {
        get actor() {
          return $$props.actor;
        }
      }), append($$anchor2, div_2);
    }, "consequent");
    if_block(node, ($$render) => {
      get$1(activeEditKind) || $$render(consequent);
    });
  }
  var node_2 = sibling(node, 2);
  {
    var consequent_1 = /* @__PURE__ */ __name(($$anchor2) => {
      var div_3 = root_2$1(), node_3 = child(div_3);
      TurnPlansPanel(node_3, {
        get actor() {
          return $$props.actor;
        }
      }), append($$anchor2, div_3);
    }, "consequent_1");
    if_block(node_2, ($$render) => {
      get$1(activeEditKind) !== "reaction" && $$render(consequent_1);
    });
  }
  var node_4 = sibling(node_2, 2);
  {
    var consequent_2 = /* @__PURE__ */ __name(($$anchor2) => {
      var div_4 = root_3$1(), node_5 = child(div_4);
      ReactionPlansPanel(node_5, {
        get actor() {
          return $$props.actor;
        }
      }), append($$anchor2, div_4);
    }, "consequent_2");
    if_block(node_4, ($$render) => {
      get$1(activeEditKind) !== "turn" && $$render(consequent_2);
    });
  }
  append($$anchor, div), pop();
}
__name(TidyTurnPrepTab, "TidyTurnPrepTab");
var root_1 = /* @__PURE__ */ from_html('<div class="sidebar-loading svelte-tp-1gq8q25"> </div>'), root_4 = /* @__PURE__ */ from_html('<div class="empty-space svelte-tp-1gq8q25"></div>'), root_8 = /* @__PURE__ */ from_html('<button class="menu-item svelte-tp-1gq8q25"><i class="fa-solid fa-copy"></i> </button>'), root_9 = /* @__PURE__ */ from_html('<button class="menu-item svelte-tp-1gq8q25"><i class="fa-solid fa-pen"></i> </button>'), root_10 = /* @__PURE__ */ from_html('<button class="menu-item svelte-tp-1gq8q25"><i class="fa-solid fa-star"></i> </button>'), root_7 = /* @__PURE__ */ from_html('<div class="menu svelte-tp-1gq8q25" role="menu"><button class="menu-item svelte-tp-1gq8q25"><i class="fa-solid fa-share"></i> </button> <!> <!> <!> <button class="menu-item danger svelte-tp-1gq8q25"><i class="fa-solid fa-trash"></i> </button></div>'), root_11 = /* @__PURE__ */ from_html('<div class="row svelte-tp-1gq8q25"><span class="row-label svelte-tp-1gq8q25"></span> <span class="row-content svelte-tp-1gq8q25"><!></span></div> <div class="row svelte-tp-1gq8q25"><span class="row-label svelte-tp-1gq8q25"></span> <span class="row-content svelte-tp-1gq8q25"><!></span></div>', 1), root_12 = /* @__PURE__ */ from_html('<div class="row svelte-tp-1gq8q25"><span class="row-label svelte-tp-1gq8q25"></span> <span class="row-content svelte-tp-1gq8q25"><!></span></div> <div class="row svelte-tp-1gq8q25"><span class="row-label svelte-tp-1gq8q25"></span> <span class="row-content svelte-tp-1gq8q25"><!></span></div> <div class="row svelte-tp-1gq8q25"><span class="row-label svelte-tp-1gq8q25"></span> <span class="row-content svelte-tp-1gq8q25"><!></span></div>', 1), root_6 = /* @__PURE__ */ from_html('<div role="group"><div class="card-header svelte-tp-1gq8q25"><div class="card-title svelte-tp-1gq8q25"> </div> <div class="card-menu svelte-tp-1gq8q25"><button class="icon-button svelte-tp-1gq8q25"><i class="fa-solid fa-ellipsis-vertical"></i></button> <!></div></div> <div class="card-rows svelte-tp-1gq8q25"><!></div></div>'), root_3 = /* @__PURE__ */ from_html('<div class="section-body svelte-tp-1gq8q25"><!></div>'), root_2 = /* @__PURE__ */ from_html('<section><header class="section-header svelte-tp-1gq8q25" role="button" tabindex="0"><div class="section-left svelte-tp-1gq8q25"><i></i> <span class="section-title svelte-tp-1gq8q25"> </span></div> <button class="collapse-button svelte-tp-1gq8q25"><i></i></button></header> <!></section>'), root = /* @__PURE__ */ from_html('<div class="turn-prep-sidebar svelte-tp-1gq8q25"><!> <!></div>');
function TidyTurnsSidebarTab($$anchor, $$props) {
  push($$props, !0);
  let favoriteTurns = /* @__PURE__ */ state(proxy([])), favoriteReactions = /* @__PURE__ */ state(proxy([])), recentTurns = /* @__PURE__ */ state(proxy([])), loading = /* @__PURE__ */ state(!1), openMenuId = /* @__PURE__ */ state(null);
  const hookCleanups = [], collapseKeys = ["favoritesTurn", "favoritesReaction", "recent"];
  let collapsed = /* @__PURE__ */ state(proxy({
    favoritesTurn: !1,
    favoritesReaction: !1,
    recent: !1
  }));
  const sectionIcons = {
    favoritesTurn: "fa-solid fa-hourglass",
    favoritesReaction: "fa-solid fa-retweet",
    recent: "fa-solid fa-history"
  }, sectionTitles = {
    favoritesTurn: "TURN_PREP.Sidebar.FavoritesTurn",
    favoritesReaction: "TURN_PREP.Sidebar.FavoritesReaction",
    recent: "TURN_PREP.Sidebar.Recent"
  };
  onMount(() => (restoreCollapseState(), registerHook("updateActor", onActorUpdated), refreshData(), () => {
    cleanupHooks();
  })), user_effect(() => (window.addEventListener("click", handleGlobalClick, !0), () => {
    window.removeEventListener("click", handleGlobalClick, !0);
  }));
  function registerHook(hookName, handler) {
    if (typeof Hooks > "u") return;
    const hookId = Hooks.on(hookName, handler);
    hookCleanups.push(() => Hooks.off(hookName, hookId));
  }
  __name(registerHook, "registerHook");
  function cleanupHooks() {
    for (; hookCleanups.length; )
      hookCleanups.pop()?.();
  }
  __name(cleanupHooks, "cleanupHooks");
  function hasTurnPrepFlagChange(changes) {
    return !!changes?.flags?.[FLAG_SCOPE]?.[FLAG_KEY_DATA];
  }
  __name(hasTurnPrepFlagChange, "hasTurnPrepFlagChange");
  function onActorUpdated(updatedActor, changes) {
    !$$props.actor || updatedActor?.id !== $$props.actor.id || hasTurnPrepFlagChange(changes) && refreshData();
  }
  __name(onActorUpdated, "onActorUpdated");
  function collapseStorageKey(section) {
    return `turn-prep-sidebar-${$$props.actor?.id ?? "unknown"}-${section}`;
  }
  __name(collapseStorageKey, "collapseStorageKey");
  function restoreCollapseState() {
    if (!(typeof sessionStorage > "u"))
      for (const key of collapseKeys)
        sessionStorage.getItem(collapseStorageKey(key)) === "collapsed" && set(collapsed, { ...get$1(collapsed), [key]: !0 }, !0);
  }
  __name(restoreCollapseState, "restoreCollapseState");
  function persistCollapseState(section, value) {
    typeof sessionStorage > "u" || sessionStorage.setItem(collapseStorageKey(section), value ? "collapsed" : "expanded");
  }
  __name(persistCollapseState, "persistCollapseState");
  function toggleSection(section) {
    set(collapsed, { ...get$1(collapsed), [section]: !get$1(collapsed)[section] }, !0), persistCollapseState(section, get$1(collapsed)[section]);
  }
  __name(toggleSection, "toggleSection");
  function snapshotToPlan2(snapshot) {
    const mapFeature = /* @__PURE__ */ __name((f) => ({
      itemId: f.itemId,
      itemName: f.itemName,
      itemType: f.itemType,
      actionType: f.actionType
    }), "mapFeature");
    return {
      id: generateId(),
      name: snapshot.planName || FoundryAdapter.localize("TURN_PREP.Sidebar.UntitledPlan"),
      trigger: snapshot.trigger || "",
      actions: (snapshot.actions ?? []).map(mapFeature),
      bonusActions: (snapshot.bonusActions ?? []).map(mapFeature),
      reactions: (snapshot.reactions ?? []).map(mapFeature),
      movement: snapshot.movement ?? "",
      roleplay: snapshot.roleplay ?? "",
      additionalFeatures: (snapshot.additionalFeatures ?? []).map(mapFeature),
      categories: snapshot.categories ?? []
    };
  }
  __name(snapshotToPlan2, "snapshotToPlan");
  async function enrichFeatures(features) {
    if (!features || features.length === 0)
      return FoundryAdapter.localize("TURN_PREP.Sidebar.None");
    const actorId = $$props.actor?.id ?? "unknown", raw = features.map((f) => `@UUID[Actor.${actorId}.Item.${f.itemId}]{${f.itemName || FoundryAdapter.localize("TURN_PREP.Sidebar.MissingFeature")}}`).join(", ");
    return await FoundryAdapter.enrichHtml(raw, { async: !0 }) ?? raw;
  }
  __name(enrichFeatures, "enrichFeatures");
  async function toCard(snapshot, section) {
    const [actionsHtml, bonusHtml, additionalHtml] = await Promise.all([
      enrichFeatures(snapshot.actions ?? []),
      enrichFeatures(snapshot.bonusActions ?? []),
      enrichFeatures(snapshot.additionalFeatures ?? [])
    ]), title = section === "favorites-reaction" ? snapshot.planName || snapshot.trigger || FoundryAdapter.localize("TURN_PREP.Sidebar.UntitledPlan") : snapshot.planName || FoundryAdapter.localize("TURN_PREP.Sidebar.UntitledPlan");
    return {
      id: snapshot.id,
      title,
      actionsHtml,
      bonusHtml,
      additionalHtml,
      source: snapshot,
      section,
      variant: section === "recent" ? "recent" : "turn"
    };
  }
  __name(toCard, "toCard");
  function snapshotToReactionPlan(snapshot) {
    const toSelected = /* @__PURE__ */ __name((f) => ({
      itemId: f.itemId,
      itemName: f.itemName,
      itemType: f.itemType,
      actionType: f.actionType
    }), "toSelected");
    return {
      id: generateId(),
      name: snapshot.trigger || FoundryAdapter.localize("TURN_PREP.Sidebar.UntitledPlan"),
      trigger: snapshot.trigger || "",
      reactionFeatures: (snapshot.reactionFeatures ?? []).map(toSelected),
      additionalFeatures: (snapshot.additionalFeatures ?? []).map(toSelected),
      notes: snapshot.notes ?? "",
      createdTime: Date.now(),
      isFavorite: !0
    };
  }
  __name(snapshotToReactionPlan, "snapshotToReactionPlan");
  async function toReactionCard(snapshot) {
    const [reactionsHtml, additionalHtml] = await Promise.all([
      enrichFeatures(snapshot.reactionFeatures ?? []),
      enrichFeatures(snapshot.additionalFeatures ?? [])
    ]), title = snapshot.trigger || FoundryAdapter.localize("TURN_PREP.Sidebar.UntitledPlan");
    return {
      id: snapshot.id,
      title,
      reactionsHtml,
      additionalHtml,
      source: snapshot,
      section: "favorites-reaction",
      variant: "reaction"
    };
  }
  __name(toReactionCard, "toReactionCard");
  async function refreshData() {
    if ($$props.actor) {
      set(loading, !0);
      try {
        const data = await TurnPrepStorage.load($$props.actor), limit = getHistoryLimitForActor($$props.actor), recentSnapshots = limitHistory(data.history ?? [], limit).slice().reverse(), favTurns = [], favReactions = [], legacyFavorites = data?.favorites ?? [];
        for (const snap of data.favoritesTurn ?? legacyFavorites)
          favTurns.push(await toCard(snap, "favorites-turn"));
        for (const snap of data.favoritesReaction ?? [])
          favReactions.push(await toReactionCard(snap));
        const recentCards = [];
        for (const snap of recentSnapshots)
          recentCards.push(await toCard(snap, "recent"));
        set(favoriteTurns, favTurns, !0), set(favoriteReactions, favReactions, !0), set(recentTurns, recentCards, !0);
      } catch (err) {
        logError("Failed to load sidebar data", err);
      } finally {
        set(loading, !1);
      }
    }
  }
  __name(refreshData, "refreshData");
  async function updateData(mutator) {
    if (!$$props.actor) return;
    const data = await TurnPrepStorage.load($$props.actor);
    mutator(data), await TurnPrepStorage.save($$props.actor, data), await refreshData();
  }
  __name(updateData, "updateData");
  async function handleLoad(card) {
    await updateData((data) => {
      if (card.variant === "reaction") {
        const snapshot2 = card.source, reactionPlan = snapshotToReactionPlan(snapshot2);
        data.reactions = [...data.reactions ?? [], reactionPlan];
        return;
      }
      const snapshot = card.source, plan = snapshotToPlan2(snapshot);
      data.turnPlans = [...data.turnPlans ?? [], plan];
    });
  }
  __name(handleLoad, "handleLoad");
  async function handleDelete(section, snapshotId) {
    const confirmLabel = FoundryAdapter.localize("TURN_PREP.Sidebar.DeleteConfirm"), DialogCls = globalThis.Dialog;
    (typeof DialogCls < "u" ? await DialogCls.confirm({ title: confirmLabel, content: `<p>${confirmLabel}</p>` }) : window.confirm(confirmLabel)) && await updateData((data) => {
      section === "recent" ? data.history = (data.history ?? []).filter((s) => s.id !== snapshotId) : section === "favorites-reaction" ? data.favoritesReaction = (data.favoritesReaction ?? []).filter((s) => s.id !== snapshotId) : data.favoritesTurn = (data.favoritesTurn ?? data.favorites ?? []).filter((s) => s.id !== snapshotId);
    });
  }
  __name(handleDelete, "handleDelete");
  async function handleDuplicate(card) {
    await updateData((data) => {
      if (card.variant === "reaction") {
        const snapshot2 = card.source, copy2 = {
          ...snapshot2,
          id: generateId(),
          createdTime: Date.now(),
          trigger: snapshot2.trigger
        };
        data.favoritesReaction = [...data.favoritesReaction ?? [], copy2];
        return;
      }
      const snapshot = card.source, copy = {
        ...snapshot,
        id: generateId(),
        createdTime: Date.now(),
        planName: `${snapshot.planName || FoundryAdapter.localize("TURN_PREP.Sidebar.UntitledPlan")} ${FoundryAdapter.localize("TURN_PREP.Common.CopySuffix")}`
      };
      data.favoritesTurn = [...data.favoritesTurn ?? data.favorites ?? [], copy];
    });
  }
  __name(handleDuplicate, "handleDuplicate");
  async function handleEdit(card) {
    if (!$$props.actor) return;
    const session = {
      actorId: $$props.actor.id,
      kind: card.section === "favorites-reaction" ? "reaction" : "turn",
      originalId: card.source.id,
      snapshot: card.source
    };
    editSessionStore.startSession(session);
    const sheet = $$props.actor.sheet;
    sheet && typeof sheet.activateTab == "function" && sheet.activateTab(TAB_ID_MAIN);
  }
  __name(handleEdit, "handleEdit");
  async function handleFavoriteFromRecent(card) {
    if (card.variant !== "recent") return;
    const snapshot = card.source;
    await updateData((data) => {
      (data.favoritesTurn ?? data.favorites ?? []).some((s) => s.id === snapshot.id) || (data.favoritesTurn = [...data.favoritesTurn ?? data.favorites ?? [], snapshot]);
    });
  }
  __name(handleFavoriteFromRecent, "handleFavoriteFromRecent");
  function closeMenu() {
    set(openMenuId, null);
  }
  __name(closeMenu, "closeMenu");
  function handleGlobalClick(event2) {
    const target = event2.target;
    if (!target) return;
    const menu = target.closest(".menu"), toggle = target.closest(".card-menu");
    !menu && !toggle && closeMenu();
  }
  __name(handleGlobalClick, "handleGlobalClick");
  function menuId(card) {
    return `${card.section}-${card.id}`;
  }
  __name(menuId, "menuId");
  function getCardsForSection(section) {
    return get$1(section === "favoritesTurn" ? favoriteTurns : section === "favoritesReaction" ? favoriteReactions : recentTurns);
  }
  __name(getCardsForSection, "getCardsForSection");
  function sectionClass(section) {
    return section === "favorites-turn" ? "card favorite-turn" : section === "favorites-reaction" ? "card favorite-reaction" : "card recent-turn";
  }
  __name(sectionClass, "sectionClass");
  function label(key) {
    return FoundryAdapter.localize(key);
  }
  __name(label, "label");
  const actionLabel = "TURN_PREP.Sidebar.Action", bonusLabel = "TURN_PREP.Sidebar.BonusActions", additionalLabel = "TURN_PREP.Sidebar.AdditionalFeatures";
  var div = root(), node = child(div);
  {
    var consequent = /* @__PURE__ */ __name(($$anchor2) => {
      var div_1 = root_1(), text = child(div_1);
      template_effect(($0) => set_text(text, $0), [() => FoundryAdapter.localize("TURN_PREP.Loading")]), append($$anchor2, div_1);
    }, "consequent");
    if_block(node, ($$render) => {
      get$1(loading) && $$render(consequent);
    });
  }
  var node_1 = sibling(node, 2);
  each(node_1, 17, () => collapseKeys, index, ($$anchor2, section) => {
    var section_1 = root_2(), header = child(section_1);
    header.__click = () => toggleSection(get$1(section)), header.__keydown = (event2) => {
      (event2.key === "Enter" || event2.key === " ") && (event2.preventDefault(), toggleSection(get$1(section)));
    };
    var div_2 = child(header), i = child(div_2), span = sibling(i, 2), text_1 = child(span), button = sibling(div_2, 2), i_1 = child(button), node_2 = sibling(header, 2);
    {
      var consequent_7 = /* @__PURE__ */ __name(($$anchor3) => {
        var div_3 = root_3(), node_3 = child(div_3);
        {
          var consequent_1 = /* @__PURE__ */ __name(($$anchor4) => {
            var div_4 = root_4();
            append($$anchor4, div_4);
          }, "consequent_1"), alternate_1 = /* @__PURE__ */ __name(($$anchor4) => {
            var fragment = comment(), node_4 = first_child(fragment);
            each(node_4, 17, () => getCardsForSection(get$1(section)), (card) => card.id, ($$anchor5, card) => {
              var div_5 = root_6();
              div_5.__contextmenu = (event2) => {
                event2.preventDefault(), set(openMenuId, menuId(get$1(card)), !0);
              };
              var div_6 = child(div_5), div_7 = child(div_6), text_2 = child(div_7), div_8 = sibling(div_7, 2), button_1 = child(div_8);
              button_1.__click = () => set(openMenuId, menuId(get$1(card)), !0);
              var node_5 = sibling(button_1, 2);
              {
                var consequent_5 = /* @__PURE__ */ __name(($$anchor6) => {
                  var div_9 = root_7(), button_2 = child(div_9);
                  button_2.__click = () => {
                    closeMenu(), handleLoad(get$1(card));
                  };
                  var text_3 = sibling(child(button_2)), node_6 = sibling(button_2, 2);
                  {
                    var consequent_2 = /* @__PURE__ */ __name(($$anchor7) => {
                      var button_3 = root_8();
                      button_3.__click = () => {
                        closeMenu(), handleDuplicate(get$1(card));
                      };
                      var text_4 = sibling(child(button_3));
                      template_effect(($0) => set_text(text_4, ` ${$0 ?? ""}`), [() => label("TURN_PREP.Sidebar.Duplicate")]), append($$anchor7, button_3);
                    }, "consequent_2");
                    if_block(node_6, ($$render) => {
                      get$1(card).section !== "recent" && $$render(consequent_2);
                    });
                  }
                  var node_7 = sibling(node_6, 2);
                  {
                    var consequent_3 = /* @__PURE__ */ __name(($$anchor7) => {
                      var button_4 = root_9();
                      button_4.__click = () => {
                        closeMenu(), handleEdit(get$1(card));
                      };
                      var text_5 = sibling(child(button_4));
                      template_effect(($0) => set_text(text_5, ` ${$0 ?? ""}`), [() => label("TURN_PREP.Sidebar.Edit")]), append($$anchor7, button_4);
                    }, "consequent_3");
                    if_block(node_7, ($$render) => {
                      get$1(card).section !== "recent" && $$render(consequent_3);
                    });
                  }
                  var node_8 = sibling(node_7, 2);
                  {
                    var consequent_4 = /* @__PURE__ */ __name(($$anchor7) => {
                      var button_5 = root_10();
                      button_5.__click = () => {
                        closeMenu(), handleFavoriteFromRecent(get$1(card));
                      };
                      var text_6 = sibling(child(button_5));
                      template_effect(($0) => set_text(text_6, ` ${$0 ?? ""}`), [() => label("TURN_PREP.Sidebar.Favorite")]), append($$anchor7, button_5);
                    }, "consequent_4");
                    if_block(node_8, ($$render) => {
                      get$1(card).section === "recent" && $$render(consequent_4);
                    });
                  }
                  var button_6 = sibling(node_8, 2);
                  button_6.__click = () => {
                    closeMenu(), handleDelete(get$1(card).section, get$1(card).id);
                  };
                  var text_7 = sibling(child(button_6));
                  template_effect(
                    ($0, $1) => {
                      set_text(text_3, ` ${$0 ?? ""}`), set_text(text_7, ` ${$1 ?? ""}`);
                    },
                    [
                      () => label("TURN_PREP.Sidebar.Load"),
                      () => label("TURN_PREP.Sidebar.Delete")
                    ]
                  ), append($$anchor6, div_9);
                }, "consequent_5");
                if_block(node_5, ($$render) => {
                  get$1(openMenuId) === menuId(get$1(card)) && $$render(consequent_5);
                });
              }
              var div_10 = sibling(div_6, 2), node_9 = child(div_10);
              {
                var consequent_6 = /* @__PURE__ */ __name(($$anchor6) => {
                  var fragment_1 = root_11(), div_11 = first_child(fragment_1), span_1 = child(div_11);
                  span_1.textContent = "R:";
                  var span_2 = sibling(span_1, 2), node_10 = child(span_2);
                  html(node_10, () => get$1(card).reactionsHtml ?? get$1(card).actionsHtml);
                  var div_12 = sibling(div_11, 2), span_3 = child(div_12);
                  span_3.textContent = "AF:";
                  var span_4 = sibling(span_3, 2), node_11 = child(span_4);
                  html(node_11, () => get$1(card).additionalHtml), template_effect(
                    ($0, $1) => {
                      set_attribute(span_1, "title", $0), set_attribute(span_3, "title", $1);
                    },
                    [
                      () => label("TURN_PREP.Reactions.ReactionFeatures"),
                      () => label(additionalLabel)
                    ]
                  ), append($$anchor6, fragment_1);
                }, "consequent_6"), alternate = /* @__PURE__ */ __name(($$anchor6) => {
                  var fragment_2 = root_12(), div_13 = first_child(fragment_2), span_5 = child(div_13);
                  span_5.textContent = "A:";
                  var span_6 = sibling(span_5, 2), node_12 = child(span_6);
                  html(node_12, () => get$1(card).actionsHtml);
                  var div_14 = sibling(div_13, 2), span_7 = child(div_14);
                  span_7.textContent = "BA:";
                  var span_8 = sibling(span_7, 2), node_13 = child(span_8);
                  html(node_13, () => get$1(card).bonusHtml);
                  var div_15 = sibling(div_14, 2), span_9 = child(div_15);
                  span_9.textContent = "AF:";
                  var span_10 = sibling(span_9, 2), node_14 = child(span_10);
                  html(node_14, () => get$1(card).additionalHtml), template_effect(
                    ($0, $1, $2) => {
                      set_attribute(span_5, "title", $0), set_attribute(span_7, "title", $1), set_attribute(span_9, "title", $2);
                    },
                    [
                      () => label(actionLabel),
                      () => label(bonusLabel),
                      () => label(additionalLabel)
                    ]
                  ), append($$anchor6, fragment_2);
                }, "alternate");
                if_block(node_9, ($$render) => {
                  get$1(card).variant === "reaction" ? $$render(consequent_6) : $$render(alternate, !1);
                });
              }
              template_effect(
                ($0, $1) => {
                  set_class(div_5, 1, $0, "svelte-tp-1gq8q25"), set_text(text_2, get$1(card).title), set_attribute(button_1, "aria-label", $1);
                },
                [
                  () => clsx(sectionClass(get$1(card).section)),
                  () => label("TURN_PREP.ContextMenu.OpenLabel")
                ]
              ), append($$anchor5, div_5);
            }), append($$anchor4, fragment);
          }, "alternate_1");
          if_block(node_3, ($$render) => {
            getCardsForSection(get$1(section)).length === 0 ? $$render(consequent_1) : $$render(alternate_1, !1);
          });
        }
        append($$anchor3, div_3);
      }, "consequent_7");
      if_block(node_2, ($$render) => {
        get$1(collapsed)[get$1(section)] || $$render(consequent_7);
      });
    }
    template_effect(
      ($0, $1) => {
        set_class(section_1, 1, `sidebar-section ${get$1(collapsed)[get$1(section)] ? "is-collapsed" : ""}`, "svelte-tp-1gq8q25"), set_class(i, 1, `${sectionIcons[get$1(section)]} section-icon`, "svelte-tp-1gq8q25"), set_text(text_1, $0), set_attribute(button, "aria-label", $1), set_class(i_1, 1, `fas fa-chevron-${get$1(collapsed)[get$1(section)] ? "right" : "down"}`, "svelte-tp-1gq8q25");
      },
      [
        () => label(sectionTitles[get$1(section)]),
        () => label("TURN_PREP.Sidebar.ToggleSection")
      ]
    ), append($$anchor2, section_1);
  }), append($$anchor, div), pop();
}
__name(TidyTurnsSidebarTab, "TidyTurnsSidebarTab");
delegate(["click", "keydown", "contextmenu"]);
function registerTidy5eHooks() {
  Hooks.on("tidy5e-sheet.ready", (api) => {
    try {
      registerTidyTabs(api), setupTabHooks(api), info("Tidy5e tabs registered successfully");
    } catch (err) {
      error("Failed to register Tidy5e tabs", err);
    }
  }), info("Tidy5e hook listener registered - waiting for tidy5e-sheet.ready");
}
__name(registerTidy5eHooks, "registerTidy5eHooks");
function registerTidyTabs(api) {
  try {
    api.registerCharacterTab(
      new api.models.HtmlTab({
        title: "Turn Prep",
        tabId: TAB_ID_MAIN,
        iconClass: "fa-solid fa-hourglass",
        html: '<div data-turn-prep-root style="height: 100%"></div>',
        // Prevent Tidy from nuking our tab markup on every actor update so the Svelte
        // component stays mounted and keeps focus/scroll state intact.
        renderScheme: "force",
        enabled: /* @__PURE__ */ __name((data) => !0, "enabled"),
        onRender: /* @__PURE__ */ __name((params) => {
          const { element, data } = params, container = element.querySelector("[data-turn-prep-root]");
          if (!container || !data?.actor) {
            error("Turn Prep container or actor not found");
            return;
          }
          try {
            const mapKey = element;
            api.__turnPrepComponentMap = api.__turnPrepComponentMap || /* @__PURE__ */ new WeakMap();
            const componentMap = api.__turnPrepComponentMap, existingComponent = componentMap.get(mapKey);
            if (existingComponent) {
              if (container.childElementCount > 0)
                return;
              try {
                unmount(existingComponent);
              } catch (unmountErr) {
                error("Failed to unmount stale Turn Prep tab", unmountErr);
              } finally {
                componentMap.delete(mapKey);
              }
            }
            const component = mount(TidyTurnPrepTab, {
              target: container,
              props: { actor: data.actor }
            });
            componentMap.set(mapKey, component), info("Turn Prep main tab mounted successfully");
          } catch (err) {
            error("Failed to mount Turn Prep main tab", err);
          }
        }, "onRender")
      })
    ), info(`✓ Registered main Turn Prep tab (ID: ${TAB_ID_MAIN})`);
  } catch (err) {
    error("Failed to register main Turn Prep tab", err);
  }
  try {
    api.registerCharacterSidebarTab(
      new api.models.HtmlTab({
        title: "Turns",
        tabId: TAB_ID_SIDEBAR_TURNS,
        iconClass: "fa-solid fa-hourglass",
        html: '<div data-turn-prep-sidebar-root style="height: 100%"></div>',
        renderScheme: "force",
        enabled: /* @__PURE__ */ __name((data) => !0, "enabled"),
        onRender: /* @__PURE__ */ __name((params) => {
          const { element, data } = params, container = element.querySelector("[data-turn-prep-sidebar-root]");
          if (!container || !data?.actor) {
            error("Turn Prep sidebar container or actor not found");
            return;
          }
          try {
            api.__turnPrepSidebarMap = api.__turnPrepSidebarMap || /* @__PURE__ */ new WeakMap();
            const componentMap = api.__turnPrepSidebarMap, mapKey = element, existingComponent = componentMap.get(mapKey);
            if (existingComponent) {
              if (container.childElementCount > 0)
                return;
              try {
                unmount(existingComponent);
              } catch (unmountErr) {
                error("Failed to unmount stale Turn Prep sidebar", unmountErr);
              } finally {
                componentMap.delete(mapKey);
              }
            }
            const component = mount(TidyTurnsSidebarTab, {
              target: container,
              props: { actor: data.actor }
            });
            componentMap.set(mapKey, component), info("Turn Prep sidebar tab mounted successfully");
          } catch (err) {
            error("Failed to mount Turn Prep sidebar tab", err);
          }
        }, "onRender")
      })
    ), info(`✓ Registered sidebar Turns tab (ID: ${TAB_ID_SIDEBAR_TURNS})`);
  } catch (err) {
    error("Failed to register sidebar Turns tab", err);
  }
}
__name(registerTidyTabs, "registerTidyTabs");
function setupTabHooks(api) {
  api.hooks?.on?.("tidy5e-sheet.tabActivated", (data) => {
    data.tabId === TAB_ID_MAIN && (data.sheet?.toggleSidebar && data.sheet.toggleSidebar(!0), data.sheet?.activateSidebarTab && data.sheet.activateSidebarTab(TAB_ID_SIDEBAR_TURNS));
  });
}
__name(setupTabHooks, "setupTabHooks");
registerTidy5eHooks();
Hooks.on("init", async () => {
  try {
    await initializeModule();
  } catch (err) {
    error("Module initialization failed", err), console.error(`${MODULE_ID}: Initialization error`, err);
  }
});
Hooks.on("ready", async () => {
  try {
    await readyModule();
  } catch (err) {
    error("Module ready setup failed", err), console.error(`${MODULE_ID}: Ready error`, err);
  }
});
info(`${MODULE_ID} module loaded. Awaiting Foundry initialization...`);
//# sourceMappingURL=turn-prep.js.map
